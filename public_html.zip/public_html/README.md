Rovicc Virtual Card Platform
The Rovicc platform is a web application that allows users to create and manage virtual credit cards. It provides a secure and flexible way to make online payments without exposing real credit card details. The platform has a user-facing dashboard and an admin panel for managing users and system settings.

Core Features
User Registration and Authentication: Users can create an account, log in, and reset their password.

KYC (Know Your Customer) Verification: Users must submit documents for verification before they can use the platform's full features.

Virtual Card Creation: Users can create virtual Visa and Mastercard cards.

Admin Dashboard: Administrators can manage users, review KYC documents, and configure system settings.

Email Notifications: The platform sends email notifications for events like user registration, KYC status updates, and password resets.

Referral System: Users can refer friends to the platform and earn rewards.

Directory Structure
The project has the following directory structure:

database/: Contains the database schema and connection logic.

public_html/: This is the web root. It contains all the publicly accessible files, including:

admin/: The admin panel.

css/: CSS stylesheets for the user-facing pages.

js/: JavaScript files for the user-facing pages.

user/: The user dashboard and related functionalities.

vendor/: Contains third-party libraries, such as PHPMailer.

Technologies Used
Backend: PHP

Frontend: HTML, CSS, JavaScript

Database: MySQL

Email: PHPMailer

Setup Instructions
Database Setup:

Create a MySQL database named roviccco_card.

Import the database.sql file to create the necessary tables.

Configure the database credentials in database/db.php.

Web Server Configuration:

Set the document root to the public_html directory.

API Keys and SMTP Configuration:

Configure your Sudo API keys and other settings in the admin panel.

Configure your SMTP settings in public_html/config/smtp_config.php.

Dependencies:

Install the required PHP extensions, including pdo_mysql, intl, and mbstring.

If you're using Composer, run composer install to install the project's dependencies.

Key Files and their Functions
Backend
database/db.php: Establishes the connection to the MySQL database.

public_html/admin/: Contains the admin panel files for managing users and system settings.

public_html/user/: Contains the user dashboard files, including registration, login, card creation, and referral functionalities.

public_html/config/smtp_config.php: Configures the SMTP settings for sending emails.

vendor/: Contains the PHPMailer library for sending emails.

Frontend
public_html/css/: Contains the CSS stylesheets for the user-facing pages.

public_html/js/: Contains the JavaScript files for the user-facing pages.

public_html/index.php: The main landing page of the Rovicc platform.

public_html/user/dashboard.php: The main dashboard for logged-in users.

public_html/admin/dashboard.php: The main dashboard for administrators.

How it Works
User Registration: Users sign up for an account by providing their personal details and uploading KYC documents.

Email Verification: The user receives a verification email to activate their account.

KYC Review: The administrator reviews the user's KYC documents and approves or rejects them.

Virtual Card Creation: Once their account is approved, the user can create virtual credit cards.

Online Payments: The user can use their virtual cards for online payments.

Admin Management: The administrator can manage users, view their details, and configure system settings through the admin panel.

Security
Password Hashing: User passwords are securely hashed using password_hash().

Prepared Statements: The code uses prepared statements to prevent SQL injection attacks.

Input Sanitization: User input is sanitized to prevent XSS attacks.

Secure File Uploads: The platform handles file uploads securely to prevent malicious files from being uploaded.

CSRF Protection: It's recommended to implement CSRF protection to prevent cross-site request forgery attacks.

Contributing
We welcome contributions to the Rovicc platform! Please read our contributing guidelines before submitting a pull request.

License
The Rovicc Virtual Card Platform is open-source software licensed under the MIT License.