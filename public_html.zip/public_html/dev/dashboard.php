<?php
session_start();

require_once __DIR__ . '/../../database/db.php';



if (!isset($_SESSION['developer_id'])) {
    header("Location: login.php");
    exit();
}

$developer_id = $_SESSION['developer_id'];
$developer_first_name = $_SESSION['developer_first_name'];

// Fetch additional details if needed
$stmt = $pdo->prepare("SELECT company_name, website_url FROM developers WHERE id = ?");
$stmt->execute([$developer_id]);
$developer = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch API key count
$stmt_keys = $pdo->prepare("SELECT COUNT(*) FROM developer_api_keys WHERE developer_id = ? AND status = 'active'");
$stmt_keys->execute([$developer_id]);
$active_key_count = $stmt_keys->fetchColumn();

?>
<?php include 'templates/header.php'; ?>

<!-- Page-specific styles to ensure responsiveness -->
<style>
    .dashboard-grid {
        display: grid;
        /* Creates a grid layout for the cards */
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        /* * This is the key for responsiveness:
         * - Each column will be at least 300px.
         * - It will automatically fit as many columns as possible.
         * - On small screens (less than ~630px), columns will stack automatically.
        */
        gap: 30px;
        /* Adds space between the cards */
    }

    .info-card p {
        /* Prevents long text (like company names or URLs) from overflowing */
        word-wrap: break-word;
    }

    @media (max-width: 576px) {
        .btn {
            /* Makes buttons full-width on very small screens for better touch access */
            width: 100%;
            text-align: center;
        }
    }
</style>

<main class="main-content">
    <h1>Welcome, <?php echo htmlspecialchars($developer_first_name); ?>!</h1>
    <p>This is your developer dashboard. Manage your API keys, view documentation, and track your integration.</p>

    <!-- The new responsive grid container -->
    <div class="dashboard-grid">

        <div class="info-card">
            <h3>Quick Overview</h3>
            <p><strong>Company:</strong> <?php echo htmlspecialchars($developer['company_name'] ?? 'N/A'); ?></p>
            <p><strong>Active API Keys:</strong> <?php echo $active_key_count; ?></p>
            <a href="api_keys.php" class="btn">Manage API Keys</a>
        </div>

        <div class="info-card">
            <h3>Get Started</h3>
            <p>Ready to integrate? Our documentation provides all the details you need to connect with our services.</p>
            <a href="documentation.php" class="btn">View API Docs</a>
        </div>

    </div> <!-- end .dashboard-grid -->

</main>

<?php include 'templates/footer.php'; ?>