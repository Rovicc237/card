<?php
session_start();
require_once __DIR__ . '/../../database/db.php'; // Correct path to db.php

$message = '';
$is_success = false;

// Check if a token is provided in the URL
if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];

    try {
        // Find a developer with the matching token that has not expired yet
        $stmt = $pdo->prepare("SELECT id, token_expiry FROM developers WHERE verification_token = ? AND is_verified = 0");
        $stmt->execute([$token]);
        $developer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($developer) {
            // Check if the token has expired
            $current_time = new DateTime();
            $token_expiry_time = new DateTime($developer['token_expiry']);

            if ($current_time > $token_expiry_time) {
                $message = '<div class="alert alert-danger">This verification link has expired. Please request a new one.</div>';
            } else {
                // Token is valid and not expired, update the developer's status
                $update_stmt = $pdo->prepare("UPDATE developers SET is_verified = 1, verification_token = NULL, token_expiry = NULL WHERE id = ?");
                
                if ($update_stmt->execute([$developer['id']])) {
                    $message = '<div class="alert alert-success">Your account has been successfully verified! You will be redirected to the login page shortly.</div>';
                    $is_success = true;
                    // Redirect to login after a few seconds
                    header("refresh:5;url=login.php");
                } else {
                    $message = '<div class="alert alert-danger">An unexpected error occurred. Please try again.</div>';
                }
            }
        } else {
            // No developer found with this token, or they are already verified
            $message = '<div class="alert alert-danger">Invalid verification link. It may have already been used or is incorrect.</div>';
        }
    } catch (PDOException $e) {
        error_log("Verification Error: " . $e->getMessage());
        $message = '<div class="alert alert-danger">A server error occurred. Please contact support.</div>';
    }
} else {
    $message = '<div class="alert alert-danger">No verification token provided.</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Verification - Rovicc</title>
    <link rel="stylesheet" href="css/dev-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
        }
        .alert {
            width: 100%;
            max-width: 600px; /* Constrain width for better readability */
            margin: 0 auto 20px auto;
            padding: 20px;
            border-radius: var(--radius);
            text-align: center;
            font-weight: 500;
            font-size: 1.1rem;
        }
        .alert-danger {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        .login-link a {
            color: var(--primary);
            font-weight: 600;
            text-decoration: none;
            font-size: 1.2rem;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="auth-page">

    <div class="auth-container">
        <div class="auth-card" style="text-align: center;">
            <h2>Account Verification</h2>
            
            <?php echo $message; ?>

            <?php if ($is_success): ?>
                <p class="login-link">Click here to <a href="login.php">Login Now</a> if you are not redirected.</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>