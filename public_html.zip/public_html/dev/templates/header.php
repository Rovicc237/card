<?php
// This header includes the opening HTML, meta tags, and the top navigation bar.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Dashboard - Rovicc</title>
    <link rel="stylesheet" href="css/dev-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <?php include 'sidebar.php'; // The sidebar is now included here ?>
        
        <div class="main-wrapper">
            <header class="header">
                <button class="menu-toggle" id="menu-toggle">☰</button>
                <nav class="header-nav">
                    <ul class="nav-links">
                        <li><a href="documentation.php">API Docs</a></li>
                        <li><a href="settings.php">Settings</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </nav>
            </header>