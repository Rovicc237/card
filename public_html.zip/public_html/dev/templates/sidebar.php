<?php
// This is the developer dashboard sidebar.
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <a href="dashboard.php" class="logo">Rovicc Dev</a>
        <!-- ADD THIS BUTTON -->
        <button class="sidebar-close" id="sidebar-close">&times;</button>
    </div>
    <nav class="sidebar-nav">
        <ul>
            <li><a href="dashboard.php" class="<?php if($current_page == 'dashboard.php') echo 'active'; ?>">Dashboard</a></li>
            <li><a href="api_keys.php" class="<?php if($current_page == 'api_keys.php' || $current_page == 'generate_api_key.php') echo 'active'; ?>">API Keys</a></li>
            <li><a href="documentation.php" class="<?php if($current_page == 'documentation.php') echo 'active'; ?>">Documentation</a></li>
            <li><a href="settings.php" class="<?php if($current_page == 'settings.php') echo 'active'; ?>">Settings</a></li>
        </ul>
    </nav>
    <div class="sidebar-footer">
        <a href="logout.php">Logout</a>
    </div>
</aside>