<?php
// This footer closes the main layout containers and includes the final navigation script.
?>
        </main> <footer class="main-footer">
            <p>&copy; <?php echo date("Y"); ?> Rovicc Dev. All rights reserved.</p>
        </footer>

    </div> </div> <div class="sidebar-overlay"></div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebarClose = document.getElementById('sidebar-close');
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');

        // A single, reliable function to open or close the sidebar
        const toggleSidebar = () => {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        };

        // --- Event Listeners ---

        // 1. Click hamburger icon to open/close
        if (menuToggle) {
            menuToggle.addEventListener('click', toggleSidebar);
        }

        // 2. Click the 'X' button inside the sidebar to close
        if (sidebarClose) {
            sidebarClose.addEventListener('click', toggleSidebar);
        }

        // 3. Click the dark overlay to close
        if (overlay) {
            overlay.addEventListener('click', toggleSidebar);
        }
    });
</script>

</body>
</html>