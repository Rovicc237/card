<?php
session_start();
// Get user's first name if available to personalize the message
$firstName = isset($_SESSION['first_name']) ? htmlspecialchars($_SESSION['first_name']) : 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Access Pending - Rovicc</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/dev-style.css">
    <style>
        /* Styles for the pending access page */
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f0f2f5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            text-align: center;
            background-color: #fff;
            padding: 40px 50px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 90%;
        }
        .icon {
            font-size: 5rem;
            color: #ffc107; /* A warning color */
            margin-bottom: 20px;
        }
        h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 15px;
        }
        p {
            color: #666;
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: #5a54d8;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #433d99;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">
            <i class="fas fa-hourglass-half"></i>
        </div>
        <h1>Sandbox Access Pending</h1>
        <p>
            Hello <?php echo $firstName; ?>, your account does not currently have developer privileges. Access to the sandbox environment must be granted by an administrator.
        </p>
        <a href="/dev/login.php" class="btn">Proceed to Developer Login</a>
    </div>
</body>
</html>
