<?php
require_once 'auth_check.php';
require_once '../config/database.php';

$developer_id = $_SESSION['developer_id'];
$key_id = isset($_GET['key_id']) ? (int)$_GET['key_id'] : 0;

if ($key_id > 0) {
    try {
        // Prepare a statement to update the key status to 'revoked'
        // IMPORTANT: We also check if the key belongs to the currently logged-in developer
        // to prevent one developer from revoking another's key.
        $stmt = $pdo->prepare(
            "UPDATE developer_api_keys SET status = 'revoked' WHERE id = ? AND developer_id = ?"
        );
        
        $stmt->execute([$key_id, $developer_id]);

        // Check if any row was actually updated
        if ($stmt->rowCount() > 0) {
            // Success
            $_SESSION['success_message'] = "API key has been successfully revoked.";
        } else {
            // Either the key doesn't exist or doesn't belong to the developer
            $_SESSION['error_message'] = "Could not revoke key. It may not exist or you may not have permission.";
        }

    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Database error: " . $e->getMessage();
    }
} else {
    $_SESSION['error_message'] = "Invalid key ID provided.";
}

// Redirect back to the API keys page
header("Location: api_keys.php");
exit();
?>
