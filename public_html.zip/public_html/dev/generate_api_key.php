<?php
session_start(); // Ensure session is started for auth_check
require_once 'auth_check.php';
require_once __DIR__ . '/../../database/db.php';

$developer_id = $_SESSION['developer_id'];
$new_api_key = null;
$error = null;

// Handle the form submission to generate a new key
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // 1. Generate a new, secure API key
        $prefix = "rv_sandbox_"; // Sandbox prefix
        $random_part = bin2hex(random_bytes(24)); // Generate a secure random part
        $new_api_key = $prefix . $random_part;

        // 2. Create a hash of the API key for secure storage in the database
        $hashed_key = password_hash($new_api_key, PASSWORD_DEFAULT);
        
        // 3. Get the key prefix for display and identification purposes
        $key_prefix = substr($new_api_key, 0, 12); // e.g., rv_sandbox_xxxx

        // 4. Insert the new key details into the database
        $stmt = $pdo->prepare(
            "INSERT INTO developer_api_keys (developer_id, key_prefix, api_key, status, environment) VALUES (?, ?, ?, 'active', 'sandbox')"
        );
        $stmt->execute([$developer_id, $key_prefix, $hashed_key]);

        // The key is now generated and stored. It will be displayed to the user below.

    } catch (Exception $e) {
        $error = "Could not generate API key. Error: " . $e->getMessage();
        // Log the detailed error for debugging, but show a generic message to the user
        error_log("API Key Generation Error: " . $e->getMessage());
        $error = "An unexpected error occurred. Please try again.";
    }
}

// Include the shared header
include 'templates/header.php';
?>

<!-- Page-specific styles -->
<style>
    .api-key-display-container {
        background-color: var(--background-hover);
        border: 1px solid var(--border-color);
        padding: 1rem 1.5rem;
        border-radius: var(--radius);
        margin-top: 1rem;
        margin-bottom: 1.5rem;
    }
    .api-key-display-container h4 {
        margin-top: 0;
        color: var(--primary);
    }
    .api-key-display {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        margin-top: 1rem;
    }
    .api-key-display code {
        background-color: var(--background);
        padding: 0.5rem 1rem;
        border-radius: var(--radius);
        word-break: break-all;
        flex-grow: 1;
    }
    .btn-copy {
        padding: 10px 15px;
        background-color: var(--primary);
        color: white;
        border: none;
        border-radius: var(--radius);
        cursor: pointer;
        font-weight: 500;
    }
    .btn-copy:hover {
        background-color: var(--primary-dark);
    }
    .form-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        margin-top: 1.5rem;
    }
     .btn-secondary {
      background-color: transparent;
      border: 1px solid var(--border-color);
      color: var(--text-color);
    }
    .btn-secondary:hover {
      background-color: var(--background-hover);
    }
    .alert {
        padding: 1rem;
        border-radius: var(--radius);
        margin-bottom: 1.5rem;
        border: 1px solid transparent;
    }
    .alert.error {
        background-color: #fee2e2;
        color: #991b1b;
        border-color: #fecaca;
    }
</style>

<main class="main-content">
    <div class="page-header">
        <h1>Generate New API Key</h1>
    </div>
    <p>Create a new API key for the sandbox environment. This key will have test-mode access only.</p>

    <!-- Display error message if one occurred -->
    <?php if ($error): ?>
        <div class="alert error">
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Display the newly generated key -->
    <?php if ($new_api_key): ?>
        <div class="api-key-display-container">
            <h4>API Key Generated Successfully!</h4>
            <p><strong>Please copy and save this key now. You will not be able to see it again.</strong></p>
            <div class="api-key-display">
                <code id="apiKey"><?php echo htmlspecialchars($new_api_key); ?></code>
                <button class="btn-copy" onclick="copyApiKey()">Copy</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Main action card -->
    <div class="info-card">
        <h3>Create Sandbox Key</h3>
        <p>Click the button below to generate a new key. Remember to store it securely as it will only be shown once.</p>
        <form action="generate_api_key.php" method="post" style="margin-top: 1rem;">
            <button type="submit" class="btn">Generate Key</button>
        </form>
    </div>
    
    <div class="form-actions">
       <a href="api_keys.php" class="btn btn-secondary">&larr; Back to API Keys</a>
    </div>
</main>

<script>
function copyApiKey() {
    // Get the text field
    const apiKeyText = document.getElementById("apiKey").innerText;
    const copyButton = event.target;

    // Use the Clipboard API
    navigator.clipboard.writeText(apiKeyText).then(function() {
        // Success feedback
        copyButton.innerText = 'Copied!';
        setTimeout(function() {
            copyButton.innerText = 'Copy';
        }, 2000); // Reset text after 2 seconds
    }, function(err) {
        // Error feedback (fallback for older browsers is complex, so we'll just log it)
        console.error('Could not copy text: ', err);
        copyButton.innerText = 'Error';
    });
}
</script>

<?php
// Include the shared footer
include 'templates/footer.php';
?>
