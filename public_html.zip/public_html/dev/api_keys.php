<?php
session_start();
require_once 'auth_check.php';
require_once __DIR__ . '/../../database/db.php'; // Corrected path to match other files

// Initialize messages
$message = '';
$error = '';

// Check for messages from other pages (e.g., after generating or revoking a key)
if (isset($_SESSION['success_message'])) {
    $message = '<div class="alert success">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $error = '<div class="alert error">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
    unset($_SESSION['error_message']);
}

$developer_id = $_SESSION['developer_id'];

// Handle Revoke Action from the form submission on this page
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['revoke_key_id'])) {
    $key_id_to_revoke = $_POST['revoke_key_id'];
    try {
        $stmt = $pdo->prepare("UPDATE developer_api_keys SET status = 'revoked' WHERE id = ? AND developer_id = ?");
        $stmt->execute([$key_id_to_revoke, $developer_id]);
        
        if ($stmt->rowCount() > 0) {
             $message = '<div class="alert success">API Key has been successfully revoked.</div>';
        } else {
             $error = '<div class="alert error">Could not revoke key. It may not exist or you may not have permission.</div>';
        }

    } catch (PDOException $e) {
        $error = '<div class="alert error">Database error: Failed to revoke API key.</div>';
        error_log("Revoke API key error: " . $e->getMessage());
    }
}

// Fetch all API keys for the logged-in developer
$api_keys = [];
try {
    $stmt = $pdo->prepare("SELECT id, key_prefix, status, environment, created_at FROM developer_api_keys WHERE developer_id = ? ORDER BY created_at DESC");
    $stmt->execute([$developer_id]);
    $api_keys = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching API keys: " . $e->getMessage());
    $error = '<div class="alert error">Failed to load API keys. Please try again later.</div>';
}

// Include the shared header
include 'templates/header.php';
?>

<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 20px;
    }
    .table-container {
        width: 100%;
        overflow-x: auto;
    }
    /* Badge styling for key status */
    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: capitalize;
        white-space: nowrap;
    }
    .status-badge.active {
        background-color: var(--primary-light);
        color: var(--primary);
    }
    .status-badge.revoked {
        background-color: #fee2e2;
        color: #991b1b;
    }
    /* Smaller button variant for actions */
    .btn-small {
        padding: 8px 15px;
        font-size: 0.9rem;
    }
    .btn-danger {
        background-color: var(--danger);
        color: var(--white);
    }
    .btn-danger:hover {
        background-color: #c82333; /* Darker red on hover */
    }
    /* Alert message styles */
    .alert {
        padding: 1rem;
        border-radius: var(--radius);
        margin-bottom: 1.5rem;
        border: 1px solid transparent;
    }
    .alert.error {
        background-color: #fee2e2;
        color: #991b1b;
        border-color: #fecaca;
    }
    .alert.success {
        background-color: #d1fae5;
        color: #065f46;
        border-color: #a7f3d0;
    }
</style>

<main class="main-content">
    <div class="page-header">
        <h1>Your API Keys</h1>
        <a href="generate_api_key.php" class="btn">Generate New Key</a>
    </div>
    <p>Manage your API keys for accessing Rovicc services. Keep your keys secure and never share them publicly.</p>

    <?php echo $message; ?>
    <?php echo $error; ?>

    <div class="info-card">
        <h3>Manage Keys</h3>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Key Prefix</th>
                        <th>Status</th>
                        <th>Environment</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($api_keys)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 2rem;">You have no API keys. <a href="generate_api_key.php">Generate one</a> to get started.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($api_keys as $key): ?>
                            <tr>
                                <td><code><?php echo htmlspecialchars($key['key_prefix']); ?>...</code></td>
                                <td>
                                    <span class="status-badge <?php echo strtolower(htmlspecialchars($key['status'])); ?>">
                                        <?php echo htmlspecialchars($key['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars(ucfirst($key['environment'])); ?></td>
                                <td><?php echo date("M d, Y", strtotime($key['created_at'])); ?></td>
                                <td>
                                    <?php if ($key['status'] === 'active'): ?>
                                        <form action="api_keys.php" method="POST" style="margin:0;" onsubmit="return confirm('Are you sure? This action cannot be undone.');">
                                            <input type="hidden" name="revoke_key_id" value="<?php echo $key['id']; ?>">
                                            <button type="submit" class="btn btn-small btn-danger">Revoke</button>
                                        </form>
                                    <?php else: ?>
                                        <span>-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<?php
// Include the shared footer
include 'templates/footer.php';
?>