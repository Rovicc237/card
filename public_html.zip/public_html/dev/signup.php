<?php
session_start();
// Include the database connection file
require_once __DIR__ . '/../../database/db.php';

$message = ''; // For success or error messages

// If the developer is already logged in, redirect them
if (isset($_SESSION['developer_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $company_name = trim($_POST['company_name']);
    $website_url = trim($_POST['website_url']);

    // --- All of your original PHP validation logic is preserved ---
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = '<div class="alert alert-danger">All required fields must be filled.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = '<div class="alert alert-danger">Invalid email format.</div>';
    } elseif ($password !== $confirm_password) {
        $message = '<div class="alert alert-danger">Passwords do not match.</div>';
    } elseif (strlen($password) < 6) {
        $message = '<div class="alert alert-danger">Password must be at least 6 characters long.</div>';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM developers WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            $message = '<div class="alert alert-danger">This email is already registered as a developer.</div>';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $verification_token = bin2hex(random_bytes(32));
            $token_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $pdo->prepare("INSERT INTO developers (first_name, last_name, email, password, verification_token, token_expiry, company_name, website_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            // --- Execute the insertion ---
            if ($stmt->execute([$first_name, $last_name, $email, $hashed_password, $verification_token, $token_expiry, $company_name, $website_url])) {
                
                session_regenerate_id(true); // Regenerate session ID after successful signup for security
                
                // --- 1. ADMIN EMAIL NOTIFICATION (Existing functionality) ---
                $admin_email = 'tchindaromaric10@gmail.com';
                $subject_admin = 'New Developer Registration on Rovicc';
                $email_body_admin = "<p>A new developer has registered:</p><ul><li><strong>Name:</strong> " . htmlspecialchars($first_name) . " " . htmlspecialchars($last_name) . "</li><li><strong>Email:</strong> " . htmlspecialchars($email) . "</li><li><strong>Company:</strong> " . (empty($company_name) ? 'N/A' : htmlspecialchars($company_name)) . "</li></ul>";
                $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: Rovicc System <no-reply@rovicc.com>\r\n";
                mail($admin_email, $subject_admin, $email_body_admin, $headers);
                
                // --- 2. USER VERIFICATION EMAIL (Newly added functionality) ---
                $user_email = $email;
                $subject_user = "Verify Your Rovicc Developer Account";
                
                // Construct the verification link
                $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
                $host = $_SERVER['HTTP_HOST'];
                $verify_link = "{$protocol}://{$host}/dev/verify.php?token={$verification_token}";

                $email_body_user = "<html><body>";
                $email_body_user .= "<h2>Welcome to Rovicc, " . htmlspecialchars($first_name) . "!</h2>";
                $email_body_user .= "<p>Thank you for registering. Please click the link below to verify your email address and activate your developer account:</p>";
                $email_body_user .= "<p><a href='{$verify_link}' style='padding: 10px 15px; background-color: #5A54D8; color: white; text-decoration: none; border-radius: 5px;'>Verify My Account</a></p>";
                $email_body_user .= "<p>If you cannot click the link, please copy and paste this URL into your browser:</p>";
                $email_body_user .= "<p>{$verify_link}</p>";
                $email_body_user .= "<p>This link will expire in one hour.</p>";
                $email_body_user .= "<p>Thanks,<br>The Rovicc Team</p>";
                $email_body_user .= "</body></html>";
                
                // Send the email to the user
                mail($user_email, $subject_user, $email_body_user, $headers);
                // --- END: USER VERIFICATION EMAIL ---

                $message = '<div class="alert alert-success">Registration successful! A verification link has been sent to your email. Please check your inbox.</div>';
                header("refresh:5;url=login.php");
            } else {
                $message = '<div class="alert alert-danger">Error during registration. Please try again.</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Signup - Rovicc</title>
    <link rel="stylesheet" href="css/dev-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .form-group {
            text-align: left;
        }
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-dark);
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            background-color: #fdfdff;
            transition: border-color 0.2s ease;
            font-size: 1rem;
        }
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(90, 84, 216, 0.15);
        }
        .btn {
            width: 100%;
            padding: 14px;
            font-size: 1.1rem;
            margin-top: 10px;
        }
        .auth-card h2 {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .auth-card .sub-heading {
             color: var(--text-light);
             margin-bottom: 30px;
        }
        .alert {
            width: 100%;
            padding: 15px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        .alert-danger {
            background-color: #fee2e2;
            color: #991b1b;
            border-color: #fecaca;
        }
        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border-color: #a7f3d0;
        }
        .auth-footer {
            margin-top: 20px;
            font-size: 0.9rem;
            color: var(--text-light);
        }
        .auth-footer a {
            color: var(--primary);
            font-weight: 600;
            text-decoration: none;
        }
        .auth-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 576px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body class="auth-page">

    <div class="auth-container">
        <div class="auth-card">
            
            <h2>Create Developer Account</h2>
            <p class="sub-heading">Join our platform and start building today.</p>

            <?php echo $message; ?>

            <form action="signup.php" method="POST">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group full-width">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                    </div>

                    <div class="form-group full-width">
                        <label for="company_name">Company Name</label>
                        <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo htmlspecialchars($_POST['company_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group full-width">
                        <label for="website_url">Website URL</label>
                        <input type="url" id="website_url" name="website_url" class="form-control" value="<?php echo htmlspecialchars($_POST['website_url'] ?? ''); ?>">
                    </div>

                    <div class="form-group full-width">
                        <button type="submit" class="btn">Sign Up</button>
                    </div>
                </div>
            </form>
            
            <div class="auth-footer">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </div>

</body>
</html>