<?php
session_start();
require_once __DIR__ . '/../../database/db.php'; // Correct path to db.php

// Check if the developer is logged in, if not, redirect to login page
if (!isset($_SESSION['developer_id'])) {
    header("Location: login.php");
    exit();
}

// Dynamically determine the API base URL for examples
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$api_base_url_example = $protocol . "://" . $host . "/api/v1";

?>
<?php include 'templates/header.php'; ?>

<?php include 'templates/sidebar.php'; ?>

<div class="main-content documentation-page">
    <h1>Rovicc API Documentation</h1>
    <p class="lead">Welcome to the Rovicc API! Our API allows you to programmatically integrate virtual card creation and customer management directly into your applications. This documentation provides comprehensive guides, endpoint references, and code examples to help you get started quickly.</p>

    <section class="doc-section">
        <h2 id="authentication">1. Authentication</h2>
        <p>All API requests must be authenticated using an API Key. You can generate and manage your API Keys from your <a href="api_keys.php">Developer Dashboard</a>.</p>
        <p>Your API Key should be sent in the <code>Authorization</code> header of every request, using the Bearer token scheme:</p>
        <div class="code-block">
            <pre><code>Authorization: Bearer YOUR_API_KEY_HERE</code></pre>
        </div>
        <p>Replace <code>YOUR_API_KEY_HERE</code> with your actual API Key.</p>
        <div class="alert info">
            <strong>Important:</strong> Keep your API Keys confidential. Do not expose them in client-side code or public repositories.
        </div>
    </section>

    <section class="doc-section">
        <h2 id="base-url">2. Base URL</h2>
        <p>All API requests should be made to the following base URL:</p>
        <div class="code-block">
            <pre><code><?php echo htmlspecialchars($api_base_url_example); ?></code></pre>
        </div>
    </section>

    <section class="doc-section">
        <h2 id="error-handling">3. Error Handling</h2>
        <p>Our API uses standard HTTP status codes to indicate the success or failure of an API request. In case of an error, the response body will contain a JSON object with <code>"status": "error"</code> and a descriptive <code>"message"</code>.</p>
        <div class="code-block">
            <pre><code>{
    "status": "error",
    "message": "A descriptive error message.",
    "http_code": 400
}</code></pre>
        </div>
        <p>Common HTTP Status Codes:</p>
        <ul>
            <li><code>200 OK</code>: The request was successful (e.g., for GET requests).</li>
            <li><code>201 Created</code>: The resource was successfully created (e.g., for POST requests).</li>
            <li><code>400 Bad Request</code>: The request was malformed or missing required parameters.</li>
            <li><code>401 Unauthorized</code>: Authentication failed (e.g., missing or invalid API Key).</li>
            <li><code>404 Not Found</code>: The requested endpoint or resource does not exist.</li>
            <li><code>405 Method Not Allowed</code>: The HTTP method used is not supported for this endpoint.</li>
            <li><code>402 Payment Required</code>: Insufficient balance in the developer's linked Rovicc account.</li>
            <li><code>500 Internal Server Error</code>: An unexpected error occurred on the server.</li>
        </ul>
    </section>

    <section class="doc-section">
        <h2 id="endpoints">4. API Endpoints</h2>

        <h3 id="status-endpoint">4.1. Get API Status</h3>
        <p>Check the current status of the API and verify your authentication.</p>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/status</code>
        </div>
        <h4>Request:</h4>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/status' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "API is up and running!",
    "authenticated_developer_id": 123,
    "authenticated_api_key_id": 456,
    "timestamp": "2025-07-22 16:30:00"
}</code></pre>
        </div>

        <h3 id="developer-info-endpoint">4.2. Get Authenticated Developer Info</h3>
        <p>Retrieve details about the authenticated developer account.</p>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/developer/info</code>
        </div>
        <h4>Request:</h4>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/developer/info' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Developer information retrieved successfully.",
    "data": {
        "id": 1,
        "first_name": "John",
        "last_name": "Developer",
        "email": "john.developer@example.com",
        "company_name": "DevCo Inc.",
        "website_url": "https://devco.com",
        "created_at": "2025-07-20 10:00:00"
    }
}</code></pre>
        </div>

        <h3 id="create-customer-endpoint">4.3. Create API Customer</h3>
        <p>Create a new customer record in your Rovicc system and provision a corresponding profile with our card provider. This customer can then be used to create virtual cards.</p>
        <div class="endpoint-details">
            <span class="method post">POST</span> <code>/customers/create</code>
        </div>
        <h4>Request Body (JSON):</h4>
        <p>All fields are required.</p>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>first_name</code></td><td>string</td><td>Customer's first name.</td></tr>
                    <tr><td><code>last_name</code></td><td>string</td><td>Customer's last name.</td></tr>
                    <tr><td><code>email</code></td><td>string</td><td>Customer's unique email address.</td></tr>
                    <tr><td><code>phone</code></td><td>string</td><td>Customer's phone number (e.g., <code>+2376XXXXXXXX</code>).</td></tr>
                    <tr><td><code>dob</code></td><td>string</td><td>Customer's date of birth (<code>YYYY-MM-DD</code>).</td></tr>
                    <tr><td><code>id_card_front_url</code></td><td>string</td><td>Publicly accessible URL to the customer's ID card front image.</td></tr>
                    <tr><td><code>id_card_back_url</code></td><td>string</td><td>Publicly accessible URL to the customer's ID card back image.</td></tr>
                </tbody>
            </table>
        </div>
        <div class="code-block">
            <pre><code>{
    "first_name": "Alice",
    "last_name": "Smith",
    "email": "alice.smith@example.com",
    "phone": "+237678123456",
    "dob": "1990-01-01",
    "id_card_front_url": "https://your-storage.com/alice_id_front.jpg",
    "id_card_back_url": "https://your-storage.com/alice_id_back.jpg"
}</code></pre>
        </div>
        <h4>Success Response (200 OK / 201 Created):</h4>
        <p>Returns details of the created or found customer. If the email already exists, it returns the existing customer's data.</p>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "New API customer created.",
    "data": {
        "api_customer_id": 789,
        "email": "alice.smith@example.com",
        "first_name": "Alice",
        "last_name": "Smith",
        "provider_customer_id": "cust_xyz123"
    }
}</code></pre>
        </div>

        <h3 id="create-card-endpoint">4.4. Create Virtual Card</h3>
        <p>Create a new virtual card for a specified customer. The total cost (creation fee + initial funding) will be debited from the **authenticated developer's linked Rovicc user account balance**.</p>
        <div class="endpoint-details">
            <span class="method post">POST</span> <code>/cards/create</code>
        </div>
        <h4>Request Body (JSON):</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_brand</code></td><td>string</td><td>The brand of the card to create (<code>"Visa"</code> or <code>"MasterCard"</code>).</td><td>Yes</td></tr>
                    <tr><td><code>initial_funding_amount_usd</code></td><td>number</td><td>The amount in USD to initially fund the card with. Minimum $3.00.</td><td>Yes</td></tr>
                    <tr><td><code>customer_email</code></td><td>string</td><td><em>(Optional)</em> Email of the target customer (must exist in <code>users</code> or <code>api_customers</code> table). If omitted, the card is created for the developer's linked user account.</td><td>No</td></tr>
                    <tr><td><code>api_customer_id</code></td><td>integer</td><td><em>(Optional)</em> ID of the target customer from the <code>api_customers</code> table. Use this OR <code>customer_email</code>.</td><td>No</td></tr>
                </tbody>
            </table>
        </div>
        <div class="alert info">
            <strong>Cost:</strong> A fixed fee of <strong>$3.00 USD</strong> for card creation will be charged in addition to the <code>initial_funding_amount_usd</code>.
        </div>
        <div class="code-block">
            <pre><code>{
    "card_brand": "Visa",
    "initial_funding_amount_usd": 10.00,
    "customer_email": "alice.smith@example.com"
}</code></pre>
        </div>
        <p>Or using <code>api_customer_id</code>:</p>
        <div class="code-block">
            <pre><code>{
    "card_brand": "MasterCard",
    "initial_funding_amount_usd": 5.00,
    "api_customer_id": 789
}</code></pre>
        </div>
        <p>Or for the developer's own linked account:</p>
        <div class="code-block">
            <pre><code>{
    "card_brand": "Visa",
    "initial_funding_amount_usd": 8.50
}</code></pre>
        </div>
        <h4>Success Response (201 Created):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Virtual card created successfully for alice.smith@example.com",
    "data": {
        "payer_user_id": 123, // The ID of the developer's linked Rovicc user (payer)
        "card_owner_user_id": null, // Rovicc user ID of the card owner (can be null)
        "card_owner_api_customer_id": 789, // API Customer ID of the card owner (can be null)
        "email": "alice.smith@example.com",
        "card_id": "rovicc_card_abc456",
        "brand": "Visa",
        "masked_pan": "428852******1234",
        "last_4_digits": "1234",
        "expiry_month": "12",
        "expiry_year": "28",
        "currency": "USD",
        "initial_funding": 10,
        "total_cost_usd": 13, // $3 fee + $10 funding
        "transaction_ref": "API-CARD-789-1753191852"
    }
}</code></pre>
        </div>
        
        <h3 id="fund-card-endpoint">4.5. Fund Virtual Card</h3>
        <p>Add funds to an existing Rovicc virtual card via a transfer from Rovicc's main account with the card provider. The funding amount plus applicable fees will be debited from the **authenticated developer's linked Rovicc user account balance**.</p>
        <div class="endpoint-details">
            <span class="method post">POST</span> <code>/cards/fund</code>
        </div>
        <h4>Request Body (JSON):</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID (from card creation response) of the virtual card to fund.</td><td>Yes</td></tr>
                    <tr><td><code>amount_usd</code></td><td>number</td><td>The amount in USD to add to the card. Must be a positive number.</td><td>Yes</td></tr>
                </tbody>
            </table>
        </div>
        <div class="alert info">
            <strong>Cost:</strong> Card funding incurs a fixed fee (currently $1.00 USD) and a percentage fee (currently 0%). These fees are configured in your admin settings.
        </div>
        <div class="code-block">
            <pre><code>{
    "card_id": "YOUR_ROVICC_CARD_ID_HERE",
    "amount_usd": 25.00
}</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Virtual card funded successfully via transfer.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "amount_funded_usd": 25,
        "total_cost_to_developer_usd": 26, // $25 funding + $1 fixed fee (example)
        "transaction_ref": "API-FUND-789-1753191852",
        "provider_transfer_id": "transfer_def789",
        "provider_transfer_status": "successful" // or "queued"
    }
}</code></pre>
        </div>

        <h3 id="withdraw-card-endpoint">4.6. Withdraw Funds from Card</h3>
        <p>Withdraw funds from an existing Rovicc virtual card back to Rovicc's main account with the card provider. The withdrawn amount will be credited to the **authenticated developer's linked Rovicc user account balance** after deducting any withdrawal fees.</p>
        <div class="endpoint-details">
            <span class="method post">POST</span> <code>/cards/withdraw</code>
        </div>
        <h4>Request Body (JSON):</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID of the virtual card to withdraw from.</td><td>Yes</td></tr>
                    <tr><td><code>amount_usd</code></td><td>number</td><td>The amount in USD to withdraw from the card. Must be a positive number.</td><td>Yes</td></tr>
                </tbody>
            </table>
        </div>
        <div class="alert info">
            <strong>Cost:</strong> Card withdrawal incurs a fixed fee (currently $0.50 USD) and a percentage fee (currently 0%). These fees are configured in your admin settings and are deducted from the withdrawn amount.
        </div>
        <div class="code-block">
            <pre><code>{
    "card_id": "YOUR_ROVICC_CARD_ID_HERE",
    "amount_usd": 10.00
}</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Funds successfully withdrawn from card to developer's balance.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "amount_withdrawn_usd": 10,
        "fees_usd": 0.50, // Example fixed fee
        "total_debited_from_card_usd": 10.50, // $10 withdrawn + $0.50 fee
        "transaction_ref": "API-WITHDRAW-789-1753191852",
        "provider_transfer_id": "transfer_ghi789",
        "provider_transfer_status": "successful" // or "queued"
    }
}</code></pre>
        </div>

        <h3 id="get-card-balance-endpoint">4.7. Get Card Balance</h3>
        <p>Retrieve the current and available balance for a specific Rovicc virtual card.</p>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/cards/balance</code>
        </div>
        <h4>Request Parameters:</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID (from card creation response) of the virtual card whose balance is to be retrieved.</td><td>Yes</td></tr>
                </tbody>
            </table>
        </div>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/cards/balance?card_id=YOUR_ROVICC_CARD_ID_HERE' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Card balance retrieved successfully.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "account_id": "provider_acct_def789",
        "brand": "Visa",
        "masked_pan": "428852******1234",
        "current_balance_usd": 150.75,
        "available_balance_usd": 145.25
    }
}</code></pre>
        </div>

        <h3 id="get-card-transactions-endpoint">4.8. Get Card Transactions</h3>
        <p>Retrieve a list of transactions for a specific Rovicc virtual card.</p>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/cards/transactions</code>
        </div>
        <h4>Request Parameters:</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID of the virtual card whose transactions are to be retrieved.</td><td>Yes</td></tr>
                    <tr><td><code>page</code></td><td>integer</td><td><em>(Optional)</em> The page number for pagination (0-indexed). Defaults to 0.</td><td>No</td></tr>
                    <tr><td><code>limit</code></td><td>integer</td><td><em>(Optional)</em> The maximum number of transactions to return per page. Defaults to 100. Max 1000.</td><td>No</td></tr>
                    <tr><td><code>fromDate</code></td><td>string</td><td><em>(Optional)</em> Start date for filtering transactions (ISO 8601 format, e.g., <code>2024-01-01T00:00:00Z</code>). Defaults to 2 years ago.</td><td>No</td></tr>
                    <tr><td><code>toDate</code></td><td>string</td><td><em>(Optional)</em> End date for filtering transactions (ISO 8601 format, e.g., <code>2025-07-23T23:59:59Z</code>). Defaults to current date/time.</td><td>No</td></tr>
                </tbody>
            </table>
        </div>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/cards/transactions?card_id=YOUR_ROVICC_CARD_ID_HERE&amp;limit=50&amp;page=0' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Card transactions retrieved successfully.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "masked_pan": "428852******1234",
        "total_transactions": 5,
        "page": 0,
        "limit": 50,
        "transactions": [
            {
                "transaction_id": "tx_12345",
                "type": "debit",
                "status": "successful",
                "amount_usd": 5.00,
                "currency": "USD",
                "narration": "Online Purchase at ExampleStore",
                "created_at": "2025-07-22T10:00:00Z"
            },
            {
                "transaction_id": "tx_67890",
                "type": "credit",
                "status": "successful",
                "amount_usd": 20.00,
                "currency": "USD",
                "narration": "Card Funding",
                "created_at": "2025-07-21T15:30:00Z"
            }
        ]
    }
}</code></pre>
        </div>

        <h3 id="get-card-authorizations-endpoint">4.9. Get Card Authorizations</h3>
        <p>Retrieve a list of authorization attempts for a specific Rovicc virtual card.</p>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/cards/authorizations</code>
        </div>
        <h4>Request Parameters:</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID of the virtual card whose authorizations are to be retrieved.</td><td>Yes</td></tr>
                    <tr><td><code>page</code></td><td>integer</td><td><em>(Optional)</em> The page number for pagination (0-indexed). Defaults to 0.</td><td>No</td></tr>
                    <tr><td><code>limit</code></td><td>integer</td><td><em>(Optional)</em> The maximum number of authorizations to return per page. Defaults to 100. Max 1000.</td><td>No</td></tr>
                    <tr><td><code>fromDate</code></td><td>string</td><td><em>(Optional)</em> Start date for filtering authorizations (ISO 8601 format, e.g., <code>2024-01-01T00:00:00Z</code>). Defaults to 2 years ago.</td><td>No</td></tr>
                    <tr><td><code>toDate</code></td><td>string</td><td><em>(Optional)</em> End date for filtering authorizations (ISO 8601 format, e.g., <code>2025-07-23T23:59:59Z</code>). Defaults to current date/time.</td><td>No</td></tr>
                </tbody>
            </table>
        </div>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/cards/authorizations?card_id=YOUR_ROVICC_CARD_ID_HERE&amp;limit=50' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Card authorizations retrieved successfully.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "masked_pan": "428852******1234",
        "total_authorizations": 5,
        "page": 0,
        "limit": 50,
        "authorizations": [
            {
                "authorization_id": "auth_123",
                "merchant_name": "Online Store XYZ",
                "amount_usd": 15.50,
                "currency": "USD",
                "status": "Approved",
                "reason": "N/A",
                "created_at": "2025-07-22T14:30:00Z"
            },
            {
                "authorization_id": "auth_456",
                "merchant_name": "Gas Station ABC",
                "amount_usd": 30.00,
                "currency": "USD",
                "status": "Declined",
                "reason": "Insufficient funds on the card.",
                "created_at": "2025-07-21T08:15:00Z"
            }
        ]
    }
}</code></pre>
        </div>

        <h3 id="get-secure-card-details-endpoint">4.10. Get Secure Card Details Token</h3>
        <p>Retrieve a secure, temporary token to display full card details (PAN, CVV) via our card provider's SecureProxy/Hosted Fields solution. This data is sensitive and **never** directly returned by the API.</p>
        <div class="alert danger">
            <strong>Security Warning:</strong> Handling full card details requires strict PCI DSS compliance. Use this endpoint and the returned token responsibly within a secure client-side implementation (e.g., in a secure iframe).
        </div>
        <div class="endpoint-details">
            <span class="method get">GET</span> <code>/cards/details</code>
        </div>
        <h4>Request Parameters:</h4>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th><th>Required</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>card_id</code></td><td>string</td><td>The unique Rovicc Card ID (from card creation response) of the virtual card whose details are to be retrieved.</td><td>Yes</td></tr>
                </tbody>
            </table>
        </div>
        <div class="code-block">
            <pre><code>curl -X GET \
  '<?php echo htmlspecialchars($api_base_url_example); ?>/cards/details?card_id=YOUR_ROVICC_CARD_ID_HERE' \
  -H 'Authorization: Bearer YOUR_API_KEY'</code></pre>
        </div>
        <h4>Success Response (200 OK):</h4>
        <p>The <code>secure_display_token</code> is a short-lived token that can be used with the card provider's JavaScript library (e.g., SecureProxy) to securely render the full card number and CVV in an iframe. The <code>provider_vault_id</code> is also necessary for this initialization.</p>
        <div class="code-block">
            <pre><code>{
    "status": "success",
    "message": "Secure display token retrieved successfully.",
    "data": {
        "card_id": "rovicc_card_abc456",
        "masked_pan": "428852******1234",
        "brand": "Visa",
        "expiry_month": "12",
        "expiry_year": "28",
        "currency": "USD",
        "status": "active",
        "secure_display_token": "temp_token_xyz_123...", // Temporary token for hosted fields
        "provider_vault_id": "vlt_abcde" // Your configured provider vault ID
    },
    "security_note": "Full PAN/CVV are displayed via SecureProxy/Hosted Fields using the token. They are NOT directly returned in this API response for security compliance."
}</code></pre>
        </div>
        <h4>Client-Side Display Example (JavaScript):</h4>
        <p>Include the card provider's JavaScript library (e.g., from `https://js.securepro.xyz/`) and use the `secure_display_token` and `provider_vault_id` from the API response:</p>
        <div class="code-block">
            <pre><code class="language-javascript">&lt;!-- In your HTML where you want to display card number --&gt;
&lt;div id="cardNumberContainer" style="height: 30px; border: 1px solid #ccc;"&gt;&lt;/div&gt;
&lt;div id="cvvContainer" style="height: 30px; border: 1px solid #ccc; width: 100px;"&gt;&lt;/div&gt;

&lt;!-- Include the provider's JS library (check their documentation for the correct version and path) --&gt;
&lt;script type="text/javascript" src="https://js.securepro.xyz/sudo-show/1.1/ACiWvWF9tYAez4M498DHs.min.js"&gt;&lt;/script&gt;

&lt;script&gt;
async function displaySecureCardDetails(cardId, apiKey) {
    const apiUrl = '<?php echo htmlspecialchars($api_base_url_example); ?>/cards/details?card_id=' + cardId;
    
    try {
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            }
        });
        const result = await response.json();

        if (result.status === 'success' && result.data.secure_display_token && result.data.provider_vault_id) {
            const vaultId = result.data.provider_vault_id;
            const cardToken = result.data.secure_display_token;

            // Initialize SecureProxy/Hosted Fields
            const numberSecret = SecureProxy.create(vaultId);
            const cvv2Secret = SecureProxy.create(vaultId);

            // Render Card Number
            numberSecret.request({
                name: 'pan-text', // Or 'pan-input' if you want an input field
                method: 'GET',
                path: `/cards/${cardId}/secure-data/number`, // Provider's endpoint for PAN
                headers: { "Authorization": `Bearer ${cardToken}` },
                htmlWrapper: 'text', // To display as text, use 'input' for an input field
                jsonPathSelector: 'data.number',
                style: { 'height': '100%', 'width': '100%', 'border': 'none', 'padding': '0' },
                // Example serializer to format the PAN with spaces
                serializers: [ numberSecret.SERIALIZERS.replace('(\\d{4})(\\d{4})(\\d{4})(\\d{4})', '$1 $2 $3 $4') ]
            }).render('#cardNumberContainer'); // Target HTML element to render into

            // Render CVV
            cvv2Secret.request({
                name: 'cvv-text', // Or 'cvv-input'
                method: 'GET',
                path: `/cards/${cardId}/secure-data/cvv2`, // Provider's endpoint for CVV2
                headers: { "Authorization": `Bearer ${cardToken}` },
                htmlWrapper: 'text', // To display as text
                jsonPathSelector: 'data.cvv2',
                style: { 'height': '100%', 'width': '100%', 'border': 'none', 'padding': '0' },
                serializers: []
            }).render('#cvvContainer'); // Target HTML element to render into

        } else {
            console.error("API response error or missing token/vaultId:", result.message);
            document.getElementById('cardNumberContainer').textContent = 'Error loading card number.';
            document.getElementById('cvvContainer').textContent = 'Error loading CVV.';
        }
    } catch (error) {
        console.error("Error fetching secure details:", error);
        document.getElementById('cardNumberContainer').textContent = 'Network error.';
        document.getElementById('cvvContainer').textContent = 'Network error.';
    }
}

// Example usage: Call this function when the user wants to reveal details
// displaySecureCardDetails('YOUR_ROVICC_CARD_ID_HERE', 'YOUR_DEVELOPER_API_KEY');
&lt;/script&gt;</code></pre>
        </div>
    </section>

    <section class="doc-section">
        <h2 id="next-steps">5. Next Steps</h2>
        <p>We are continuously expanding our API. Future endpoints will include:</p>
        <ul>
            <li>Card Freezing/Unfreezing</li>
            <li>Webhooks for Real-time Notifications</li>
        </ul>
        <p>Stay tuned for updates!</p>
    </section>

</div>

<?php include 'templates/footer.php'; ?>

<style>
    /* Specific styles for documentation */
    .documentation-page {
        max-width: 900px; /* Constrain width for readability */
        margin: 0 auto;
        padding: 30px;
        background-color: var(--white);
        border-radius: var(--radius);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }

    .documentation-page h1 {
        color: var(--primary);
        font-size: 2.5rem;
        margin-bottom: 20px;
        border-bottom: 2px solid var(--border-color);
        padding-bottom: 15px;
    }

    .documentation-page h2 {
        color: var(--text-dark);
        font-size: 2rem;
        margin-top: 40px;
        margin-bottom: 15px;
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
    }

    .documentation-page h3 {
        color: var(--primary-dark);
        font-size: 1.5rem;
        margin-top: 30px;
        margin-bottom: 10px;
    }

    .documentation-page h4 {
        color: var(--text-dark);
        font-size: 1.2rem;
        margin-top: 20px;
        margin-bottom: 10px;
    }

    .documentation-page p {
        line-height: 1.6;
        color: var(--text-light);
        margin-bottom: 15px;
    }

    .documentation-page .lead {
        font-size: 1.1rem;
        font-weight: 400;
        color: var(--text-dark);
    }

    .doc-section {
        margin-bottom: 40px;
    }

    .code-block {
        background-color: #f8fafd;
        border: 1px solid #e0e7eb;
        border-left: 5px solid var(--primary); /* Highlight with primary color */
        padding: 15px;
        border-radius: var(--radius); /* Use global radius */
        margin-bottom: 20px;
        overflow-x: auto; /* Enable horizontal scroll for wide code */
    }

    .code-block pre {
        margin: 0;
        padding: 0;
    }

    .code-block code {
        font-family: var(--font-mono);
        font-size: 0.9rem;
        color: #333;
        display: block; /* Ensure code takes full width */
    }

    .endpoint-details {
        background-color: #e6f7ff; /* Light blue background */
        border: 1px solid #91d5ff; /* Blue border */
        padding: 10px 15px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-family: var(--font-mono);
        font-size: 1rem;
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .endpoint-details .method {
        padding: 5px 10px;
        border-radius: 4px;
        font-weight: bold;
        color: var(--white);
        font-size: 0.85rem;
        text-transform: uppercase;
    }

    .method.get { background-color: #28a745; } /* Green for GET */
    .method.post { background-color: #007bff; } /* Blue for POST */
    .method.put { background-color: #ffc107; color: var(--text-dark);} /* Yellow for PUT */
    .method.delete { background-color: #dc3545; } /* Red for DELETE */

    .documentation-page .table-responsive {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch; /* Smooth scrolling on iOS */
    }

    .documentation-page table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        margin-bottom: 20px;
    }

    .documentation-page table th,
    .documentation-page table td {
        border: 1px solid var(--border-color);
        padding: 10px;
        text-align: left;
        font-size: 0.9rem;
        color: var(--text-dark);
    }

    .documentation-page table th {
        background-color: #f2f2f2;
        font-weight: 600;
    }

    .documentation-page ul {
        list-style: disc;
        margin-left: 20px;
        margin-bottom: 15px;
        color: var(--text-light);
    }

    .documentation-page ul li {
        margin-bottom: 8px;
    }

    .documentation-page a {
        color: var(--primary);
        text-decoration: none;
    }

    .documentation-page a:hover {
        text-decoration: underline;
    }

    /* Specific alert styles for documentation (if not already in dev-style.css) */
    .alert {
        padding: 15px;
        border-radius: var(--radius);
        margin-bottom: 20px;
        font-size: 0.95rem;
    }
    .alert.info {
        background-color: #e0f2f7;
        color: #01579b;
        border: 1px solid #b3e5fc;
    }

    .alert.danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    /* === Media Queries for Responsiveness === */

    /* For Tablets and smaller devices */
    @media (max-width: 992px) {
        .documentation-page {
            padding: 25px;
        }
    }

    /* For Mobile devices */
    @media (max-width: 768px) {
        .documentation-page {
            padding: 20px;
            margin: 0;
            border-radius: 0;
            box-shadow: none;
        }

        .documentation-page h1 {
            font-size: 2.0rem;
        }

        .documentation-page h2 {
            font-size: 1.75rem;
        }

        .documentation-page h3 {
            font-size: 1.4rem;
        }

        .documentation-page h4 {
            font-size: 1.1rem;
        }

        .endpoint-details {
            flex-wrap: wrap;
            gap: 10px;
        }
    }

    /* For very small mobile devices */
    @media (max-width: 480px) {
        .documentation-page {
            padding: 15px;
        }

        .documentation-page h1 {
            font-size: 1.8rem;
        }

        .documentation-page h2 {
            font-size: 1.5rem;
        }

        .documentation-page h3 {
            font-size: 1.25rem;
        }

        .code-block {
            padding: 10px;
            border-left-width: 4px;
        }

        .code-block code {
            font-size: 0.85rem;
        }
    }
</style>