<?php
session_start();
// Corrected database path
require_once __DIR__ . '/../../database/db.php';

$errors = [];
$email = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    if (empty($errors)) {
        try {
            // Fetch 'first_name' along with other details for session
            $stmt = $pdo->prepare("SELECT id, password, is_verified, is_disabled, sandbox_access, first_name FROM developers WHERE email = ?");
            $stmt->execute([$email]);
            $developer = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($developer && password_verify($password, $developer['password'])) {
                if ($developer['is_verified'] != 1) {
                    $errors[] = "Your account is not verified. Please check your email.";
                } elseif ($developer['is_disabled'] == 1) {
                    $errors[] = "Your account has been disabled. Please contact support.";
                } else {
                    if ($developer['sandbox_access'] == 1) {
                        // Regenerate session ID to prevent session fixation
                        session_regenerate_id(true); 

                        $_SESSION['developer_id'] = $developer['id'];
                        $_SESSION['developer_email'] = $email;
                        $_SESSION['developer_first_name'] = $developer['first_name']; // Store first name in session
                        header("Location: dashboard.php");
                        exit();
                    } else {
                        header("Location: pending_access.php");
                        exit();
                    }
                }
            } else {
                $errors[] = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            $errors[] = "A database error occurred. Please try again later.";
            // For debugging: error_log("Login PDOException: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- Global Styles & Variables --- */
        :root {
            --primary-color: #4F46E5; /* Indigo */
            --primary-hover: #4338CA;
            --secondary-color: #1F2937; /* Dark Gray */
            --background-color: #F9FAFB; /* Light Gray */
            --card-background: #FFFFFF;
            --text-color: #374151;
            --muted-text-color: #6B7280;
            --border-color: #E5E7EB;
            --success-color: #10B981;
            --error-color: #EF4444;
            --font-family: 'Inter', sans-serif;
        }

        /* --- Base & Typography --- */
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            color: var(--text-color);
            margin: 0;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        h1, h2, h3, h4, h5, h6 {
            color: var(--secondary-color);
            margin-top: 0;
        }

        p {
            line-height: 1.6;
        }

        a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.2s ease;
        }

        a:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }

        code {
            font-family: 'SF Mono', 'Consolas', 'Menlo', monospace;
            background-color: #F3F4F6;
            padding: 0.2em 0.4em;
            border-radius: 4px;
            font-size: 0.9em;
        }

        /* --- Authentication Pages (Login/Signup) --- */
        .auth-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 1rem;
        }

        .auth-card {
            background-color: var(--card-background);
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            width: 100%;
            max-width: 420px;
            text-align: center;
        }

        .auth-card h2 {
            font-size: 1.75rem;
            margin-bottom: 0.5rem;
        }

        .auth-card p {
            color: var(--muted-text-color);
            margin-bottom: 2rem;
        }

        .auth-links {
            margin-top: 1.5rem;
            font-size: 0.9rem;
            color: var(--muted-text-color);
        }

        /* --- Form Elements --- */
        .form-group {
            margin-bottom: 1.5rem;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            transition: box-shadow 0.2s ease, border-color 0.2s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.3);
        }

        /* --- Buttons --- */
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s ease;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
        }

        /* --- Messages & Notifications --- */
        .error-messages {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            text-align: left;
            background-color: #FEE2E2;
            color: #B91C1C;
            border: 1px solid #FCA5A5;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <h2>Developer Login</h2>
            <p>Access your Rovicc API dashboard.</p>
            
            <?php if (!empty($errors)): ?>
                <div class="error-messages">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-primary">Login</button>
                </div>
            </form>
            <div class="auth-links">
                <a href="f.php">Forgot Password?</a>
                <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            </div>
        </div>
    </div>
</body>
</html>