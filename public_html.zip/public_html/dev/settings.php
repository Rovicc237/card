<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

// Check if the developer is logged in
if (!isset($_SESSION['developer_id'])) {
    header("Location: login.php");
    exit();
}

$developer_id = $_SESSION['developer_id'];
$success_message = '';
$error_message = '';

// --- Handle Profile Information Update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $company_name = trim($_POST['company_name']);
    $website_url = trim($_POST['website_url']);

    if (!empty($first_name) && !empty($last_name)) {
        try {
            $stmt = $pdo->prepare(
                "UPDATE developers SET first_name = ?, last_name = ?, company_name = ?, website_url = ? WHERE id = ?"
            );
            $stmt->execute([$first_name, $last_name, $company_name, $website_url, $developer_id]);
            $_SESSION['developer_first_name'] = $first_name; // Update session variable
            $success_message = "Profile updated successfully!";
        } catch (PDOException $e) {
            $error_message = "Error updating profile: " . $e->getMessage();
        }
    } else {
        $error_message = "First name and last name are required.";
    }
}

// --- Handle Password Change ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $error_message = "New passwords do not match.";
    } else {
        $stmt = $pdo->prepare("SELECT password_hash FROM developers WHERE id = ?");
        $stmt->execute([$developer_id]);
        $developer = $stmt->fetch();

        if ($developer && password_verify($current_password, $developer['password_hash'])) {
            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE developers SET password_hash = ? WHERE id = ?");
            $stmt->execute([$new_password_hash, $developer_id]);
            $success_message = "Password changed successfully!";
        } else {
            $error_message = "Incorrect current password.";
        }
    }
}


// Fetch the latest developer data for the form
$stmt = $pdo->prepare("SELECT first_name, last_name, email, company_name, website_url FROM developers WHERE id = ?");
$stmt->execute([$developer_id]);
$dev = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<?php include 'templates/header.php'; ?>

<style>
    /* Add some specific styles for the settings page form */
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--text-dark);
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        background-color: #fdfdff;
        transition: border-color 0.2s ease;
    }
    .form-control:focus {
        outline: none;
        border-color: var(--primary);
    }
    .form-control[disabled] {
        background-color: #f1f1f1;
        cursor: not-allowed;
    }
    .btn {
        width: auto; /* Override full-width button for forms */
        padding: 12px 30px;
    }
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: var(--radius);
        border: 1px solid transparent;
        font-weight: 500;
    }
    .alert-success {
        background-color: #d1fae5;
        color: #065f46;
        border-color: #a7f3d0;
    }
    .alert-danger {
        background-color: #fee2e2;
        color: #991b1b;
        border-color: #fecaca;
    }
</style>

<main class="main-content">
    <h1>Settings</h1>
    <p>Manage your account details and password.</p>

    <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <div class="info-card">
        <h3>Profile Information</h3>
        <form action="settings.php" method="POST">
            <div class="form-group">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo htmlspecialchars($dev['first_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo htmlspecialchars($dev['last_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($dev['email']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="company_name">Company Name</label>
                <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo htmlspecialchars($dev['company_name']); ?>">
            </div>
            <div class="form-group">
                <label for="website_url">Website URL</label>
                <input type="url" id="website_url" name="website_url" class="form-control" value="<?php echo htmlspecialchars($dev['website_url']); ?>">
            </div>
            <button type="submit" name="update_profile" class="btn">Save Changes</button>
        </form>
    </div>

    <div class="info-card">
        <h3>Change Password</h3>
        <form action="settings.php" method="POST">
            <div class="form-group">
                <label for="current_password">Current Password</label>
                <input type="password" id="current_password" name="current_password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" name="change_password" class="btn">Change Password</button>
        </form>
    </div>

</main>

<?php include 'templates/footer.php'; ?>