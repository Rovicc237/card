<?php
// Start the session if it's not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the developer_id session variable is set.
// This is the key to ensuring only logged-in developers can access the page.
if (!isset($_SESSION['developer_id'])) {
    // If the developer is not logged in, destroy the session to be safe
    session_destroy();
    
    // Redirect them to the login page
    header("Location: login.php?error=unauthorized");
    
    // Stop script execution
    exit();
}

// You can also add checks here for account status (e.g., if disabled) on every page load
// require_once '../config/database.php';
// $stmt = $pdo->prepare("SELECT is_disabled FROM developers WHERE id = ?");
// $stmt->execute([$_SESSION['developer_id']]);
// $developer = $stmt->fetch();
// if ($developer && $developer['is_disabled']) {
//     session_destroy();
//     header("Location: login.php?error=disabled");
//     exit();
// }
?>
