<?php
// (public_html/index.php)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rovicc - The Future of Digital Banking</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Roboto+Mono&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Additional styles for the new premium look */
        .hero {
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(ellipse at 70% 30%, rgba(90, 84, 216, 0.1), transparent 70%),
                        radial-gradient(ellipse at 30% 70%, rgba(46, 229, 181, 0.1), transparent 70%);
            z-index: -1;
        }

        /* --- START OF WHATSAPP FAB STYLES --- */
        .whatsapp-fab {
            position: fixed;
            width: 60px; /* Made slightly larger for more prominence on the homepage */
            height: 60px;
            bottom: 40px;
            right: 40px;
            background-color: #25D366; /* Official WhatsApp Green */
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 36px; /* Increased icon size */
            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.25);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }
        .whatsapp-fab:hover {
            transform: scale(1.1);
            background-color: #128C7E; /* Darker WhatsApp Green */
        }
        /* --- END OF WHATSAPP FAB STYLES --- */
    </style>
</head>
<body>

    <header>
        <div class="container">
            <nav>
                <a href="index.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
                <ul class="nav-links">
                    <li><a href="index.php" class="active">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li class="nav-buttons-container">
                        <a href="user/login.php" class="btn btn-outline">Log In</a>
                        <a href="user/signup.php" class="btn btn-primary">Sign Up</a>
                    </li>
                </ul>
                <div class="hamburger">
                    <div class="bar"></div>
                    <div class="bar"></div>
                    <div class="bar"></div>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <div class="hero-content">
                    <h1 class="reveal">Your Money, <span>Borderless</span> and <span>Secure</span>.</h1>
                    <p class="reveal">Instantly issue virtual cards, manage spending with precision, and experience a new era of financial control with Rovicc. Built for the modern digital economy.</p>
                    <div class="hero-buttons reveal">
                        <a href="user/signup.php" class="btn btn-primary btn-large">Open a Free Account</a>
                        <a href="services.php" class="btn btn-secondary btn-large">Explore Features</a>
                    </div>
                </div>
                <div class="hero-card reveal">
                    <div class="card-flipper">
                        <div class="card-side card-front">
                             <div class="card-brand-logo">ROVICC</div>
                            <div class="card-chip"></div>
                            <div class="card-contactless">
                                <i class="fa-solid fa-wifi"></i>
                            </div>
                            <div class="card-number">
                                <span>4012</span>
                                <span>8888</span>
                                <span>9012</span>
                                <span>3456</span>
                            </div>
                            <div class="card-info">
                                <div class="card-holder">
                                    <small>Card Holder</small>
                                    <p>Tchinda Romaric</p>
                                </div>
                                <div class="card-expiry">
                                    <small>Expires</small>
                                    <p>12/28</p>
                                </div>
                            </div>
                             <div class="card-network-logo">
                                <svg xmlns="http://www.w3.org/2000/svg" width="60" height="40" viewBox="0 0 78 48"><circle fill="#EB001B" cx="24" cy="24" r="24"/><circle fill="#F79E1B" cx="54" cy="24" r="24" opacity=".95"/></svg>
                            </div>
                        </div>
                         <div class="card-side card-back">
                            <div class="card-mag-stripe"></div>
                            <div class="card-signature-panel">
                                <small>CVV</small>
                                <div class="card-cvv">123</div>
                            </div>
                            <p class="card-back-text">
                                Issued by Rovicc Financial Technologies. Use of this card is subject to the cardholder agreement.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="features" class="features">
            <div class="container">
                <div class="section-header reveal">
                    <h2>The Ultimate Financial <span>Toolkit</span></h2>
                    <p>Rovicc provides the tools you need for effortless and secure digital finance management.</p>
                </div>
                <div class="features-grid">
                    <div class="feature-card reveal">
                        <div class="feature-icon"><i class="fa-solid fa-bolt"></i></div>
                        <h3>Instant Issuance</h3>
                        <p>Generate virtual Visa and Mastercard cards in seconds to meet your immediate spending needs.</p>
                    </div>
                     <div class="feature-card reveal">
                        <div class="feature-icon"><i class="fa-solid fa-shield-halved"></i></div>
                        <h3>Fortress-Like Security</h3>
                        <p>Protect your primary funds by using unique card numbers for every online transaction and vendor.</p>
                    </div>
                    <div class="feature-card reveal">
                        <div class="feature-icon"><i class="fa-solid fa-sliders"></i></div>
                        <h3>Granular Controls</h3>
                        <p>Set custom spending limits, freeze cards instantly, and manage permissions with unparalleled ease.</p>
                    </div>
                     <div class="feature-card reveal">
                        <div class="feature-icon"><i class="fa-solid fa-globe"></i></div>
                        <h3>Global Acceptance</h3>
                        <p>Use your Rovicc virtual cards anywhere Visa or Mastercard is accepted across the globe.</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="acceptance" class="acceptance">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Pay Anywhere, <span>Worry-Free</span></h2>
                    <p>Your Rovicc card is your key to a world of online services and products. Accepted on all major platforms.</p>
                </div>
                 <div class="logos-grid">
                    <div class="logo-item reveal"><i class="fa-brands fa-google-play"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-apple"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-amazon"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-netflix"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-spotify"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-paypal"></i></div>
                    <div class="logo-item reveal"><i class="fa-brands fa-aws"></i></div>
                     <div class="logo-item reveal"><i class="fa-brands fa-facebook"></i></div>
                </div>
            </div>
        </section>

        <section class="how-it-works">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Get Started in <span>Minutes</span></h2>
                    <p>A seamless onboarding experience designed to get you up and running quickly and securely.</p>
                </div>
                <div class="steps">
                    <div class="step reveal">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h3>Create Your Secure Account</h3>
                            <p>Sign up with your basic details and complete a quick, one-time identity verification (KYC).</p>
                        </div>
                    </div>
                    <div class="step reveal">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h3>Fund Your Wallet</h3>
                            <p>Easily add funds to your Rovicc account using Mobile Money or other local payment methods.</p>
                        </div>
                    </div>
                    <div class="step reveal">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h3>Generate Your First Card</h3>
                            <p>Instantly create a virtual card, set your spending limits, and start transacting online immediately.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="testimonials" class="testimonials">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Trusted by Innovators <span>Worldwide</span></h2>
                    <p>Join thousands of satisfied users who trust Rovicc for secure online payments.</p>
                </div>
                <div class="testimonial-cards">
                    <div class="testimonial reveal">
                        <div class="rating">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p>"Rovicc has revolutionized how I handle my online subscriptions. Creating a unique card for each service gives me total control and peace of mind."</p>
                        <div class="user">
                            <img src="https://randomuser.me/api/portraits/women/43.jpg" alt="User Sarah Johnson">
                            <div>
                                <h4>Sarah Johnson</h4>
                                <small>Digital Entrepreneur</small>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial reveal">
                        <div class="rating">
                             <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p>"As a developer, I was blown away by how easy it was to manage payments for various cloud services. The security features are top-notch."</p>
                        <div class="user">
                            <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="User Michael Chen">
                            <div>
                                <h4>Michael Chen</h4>
                                <small>Software Engineer</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <section class="cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Redefine <span>Your Digital Wallet?</span></h2>
                <p>Sign up for your free Rovicc account today and issue your first virtual card in under 5 minutes. Take the first step towards smarter, safer online spending.</p>
                <a href="user/signup.php" class="btn btn-primary btn-large">Create Your Free Account</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col reveal">
                     <a href="index.php" class="logo">
                        <span class="logo-icon">R</span>
                        <span>ROVICC</span>
                    </a>
                    <p>Secure, flexible, and instantly generated virtual cards for all your online transactions.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-col reveal">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Security</a></li>
                        <li><a href="#">Developers</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Compliance</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2024 Rovicc Financial Technologies. All rights reserved.</p>
                <div class="payment-methods">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                    <i class="fa-brands fa-cc-apple-pay"></i>
                </div>
            </div>
        </div>
    </footer>

    <a href="https://chat.whatsapp.com/FYeR3QeOUaW3KKHcAeppZ4" class="whatsapp-fab" target="_blank" rel="noopener noreferrer" title="Join our WhatsApp Group">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="js/script.js" defer></script>
</body>
</html>