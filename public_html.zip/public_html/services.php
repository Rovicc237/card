<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - Rovicc</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="container">
            <nav>
                <a href="index.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" class="active">Services</a></li>
                    <li><a href="index.php#testimonials">Testimonials</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li class="nav-buttons-container">
                        <a href="user/login.php" class="btn btn-outline">Log In</a>
                        <a href="user/signup.php" class="btn btn-primary">Sign Up</a>
                    </li>
                </ul>
                <div class="hamburger">
                    <div class="bar"></div>
                    <div class="bar"></div>
                    <div class="bar"></div>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <section class="services-hero">
            <div class="container">
                <div class="page-hero-content reveal">
                    <h1>Solutions <span>for Modern Spending</span></h1>
                    <p>Tailored virtual card solutions designed for the unique needs of individuals and modern businesses. Secure, scalable, and simple.</p>
                </div>
            </div>
        </section>

        <section class="services-section">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Flexible Plans for <span>Everyone</span></h2>
                    <p>Whether you're an individual safeguarding your online shopping or a business streamlining corporate expenses, Rovicc has a plan for you.</p>
                </div>
                <div class="services-grid">
                    <div class="service-card reveal">
                        <div class="service-icon"><i class="fa-solid fa-user-shield"></i></div>
                        <h3>Personal Plan</h3>
                        <p>Empower your personal online spending with secure, flexible virtual cards. Perfect for subscriptions, online shopping, and budgeting.</p>
                        <ul>
                            <li><i class="fa-solid fa-check-circle"></i>Shop online without exposing your real card details.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Manage subscriptions with single-use or merchant-locked cards.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Set spending limits to control your budget effectively.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Instantly create or freeze cards anytime, anywhere.</li>
                        </ul>
                        <a href="user/signup.php" class="btn btn-primary">Get Started Free</a>
                    </div>

                    <div class="service-card reveal">
                        <div class="service-icon"><i class="fa-solid fa-briefcase"></i></div>
                        <h3>Business Plan</h3>
                        <p>Streamline your company's expenses and payments with our powerful platform. Ideal for managing team spending and vendor payments.</p>
                        <ul>
                            <li><i class="fa-solid fa-check-circle"></i>Issue cards to employees with custom rules and limits.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Track team spending in real-time with detailed analytics.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Simplify vendor and SaaS payments with dedicated cards.</li>
                            <li><i class="fa-solid fa-check-circle"></i>Integrate with accounting software to automate reporting.</li>
                        </ul>
                        <a href="contact.php" class="btn btn-secondary">Contact Sales</a>
                    </div>
                </div>
            </div>
        </section>

        <section class="comparison-section">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Compare <span>Our Plans</span></h2>
                    <p>Find the perfect fit. Here’s a detailed look at what each Rovicc plan has to offer.</p>
                </div>
                <div class="comparison-table-wrapper reveal">
                    <table class="comparison-table">
                        <thead>
                            <tr>
                                <th>Features</th>
                                <th>Personal</th>
                                <th>Business</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Instant Virtual Card Creation</td>
                                <td><i class="fa-solid fa-check"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Single-Use "Burner" Cards</td>
                                <td><i class="fa-solid fa-check"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                             <tr>
                                <td>Merchant-Locked Cards</td>
                                <td><i class="fa-solid fa-check"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Custom Spending Limits</td>
                                <td><i class="fa-solid fa-check"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Real-Time Transaction Feed</td>
                                <td><i class="fa-solid fa-check"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Employee/Team Cards</td>
                                <td><i class="fa-solid fa-times"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Advanced User Roles & Permissions</td>
                                <td><i class="fa-solid fa-times"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                             <tr>
                                <td>Expense Categorization & Reporting</td>
                               <td><i class="fa-solid fa-times"></i></td>
                                <td><i class="fa-solid fa-check"></i></td>
                            </tr>
                            <tr>
                                <td>Accounting Software Integration</td>
                               <td><i class="fa-solid fa-times"></i></td>
                                <td><span class="badge-beta">Beta</span></td>
                            </tr>
                            <tr>
                                <td>Dedicated Account Manager</td>
                                <td><i class="fa-solid fa-times"></i></td>
                                <td><span class="badge-enterprise">Enterprise Only</span></td>
                            </tr>
                        </tbody>
                         <tfoot>
                            <tr>
                                <td></td>
                                <td><a href="user/signup.php" class="btn btn-primary">Choose Personal</a></td>
                                <td><a href="dev/login.php" class="btn btn-secondary">Choose Business</a></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </section>


        <section class="faq-section">
            <div class="container">
                <div class="section-header reveal">
                    <h2>Frequently <span>Asked Questions</span></h2>
                    <p>Have questions? We’ve got answers. Here are some of the most common queries we receive.</p>
                </div>
                <div class="faq-accordion reveal">
                    <div class="faq-item">
                        <button class="faq-question">
                            <span>What is a virtual credit card?</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                        <div class="faq-answer">
                            <p>A virtual credit card is a unique 16-digit card number that is generated instantly and can be used for online purchases. It acts as a layer of protection by masking your real credit card or bank account details, significantly enhancing your security online.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button class="faq-question">
                            <span>Is Rovicc a bank?</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                        <div class="faq-answer">
                            <p>No, Rovicc is a financial technology platform, not a bank. We partner with licensed financial institutions to issue our virtual cards. All funds are held securely with our partner banks.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <button class="faq-question">
                            <span>How do I fund my virtual cards?</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                        <div class="faq-answer">
                            <p>You can securely link your existing bank account, debit card, or credit card as a funding source. When you use a Rovicc virtual card, we process the transaction and draw the funds from your linked source, so you don't need to pre-load a balance.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button class="faq-question">
                            <span>Can I use Rovicc cards for in-store purchases?</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                        <div class="faq-answer">
                            <p>Currently, Rovicc virtual cards are designed for online use only. They can be added to mobile wallets like Apple Pay or Google Pay, allowing you to use them for contactless payments where accepted.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="api-section">
            <div class="container">
                <div class="api-content reveal">
                    <div class="api-text">
                         <span class="badge">Available</span>
                        <h2>Developer API: Power Your Platform</h2>
                        <p>Want to offer virtual cards to your own users? Integrate Rovicc's secure card issuance infrastructure directly into your application with our robust, modern API. Perfect for fintechs, marketplaces, and platforms.</p>
                        <a href="dev/login.php" class="btn btn-primary btn-large">Request API Key</a>
                    </div>
                    <div class="api-visual">
                        <div class="code-icon-wrapper">
                             <i class="fa-solid fa-code"></i>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <footer id="contact">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col reveal">
                    <a href="index.php" class="logo">
                        <span class="logo-icon">R</span>
                        <span>ROVICC</span>
                    </a>
                    <p>Secure virtual credit cards for the digital age. Experience financial freedom with enhanced security.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-col reveal">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Security</a></li>
                        <li><a href="#">Developers</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Compliance</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2024 Rovicc Financial Technologies. All rights reserved.</p>
                <div class="payment-methods">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-amex"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                    <i class="fa-brands fa-cc-apple-pay"></i>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/script.js" defer></script>
</body>
</html>