<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Rovicc</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="container">
            <nav>
                <a href="index.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="index.php#testimonials">Testimonials</a></li>
                    <li><a href="contact.php" class="active">Contact</a></li>
                    <li class="nav-buttons-container">
                        <a href="user/login.php" class="btn btn-outline">Log In</a>
                        <a href="user/signup.php" class="btn btn-primary">Sign Up</a>
                    </li>
                </ul>
                <div class="hamburger">
                    <div class="bar"></div>
                    <div class="bar"></div>
                    <div class="bar"></div>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <section class="page-hero contact-hero">
            <div class="container">
                <div class="page-hero-content reveal">
                    <h1>Get In <span>Touch</span></h1>
                    <p>We're here to help. Whether you have a question about features, trials, pricing, or anything else, our team is ready to answer all your questions.</p>
                </div>
            </div>
        </section>

        <section class="contact-page-section">
            <div class="container">
                <div class="contact-grid">
                    <div class="contact-info reveal">
                        <h3>Contact Information</h3>
                        <p>Fill up the form and our Team will get back to you within 24 hours.</p>
                        <div class="info-item">
                            <i class="fa-solid fa-phone"></i>
                            <p>+237676244204</p>
                        </div>
                         <div class="info-item">
                            <i class="fa-solid fa-envelope"></i>
                            <p>mail@rovicc.com</p>
                        </div>
                         <div class="info-item">
                            <i class="fa-solid fa-map-marker-alt"></i>
                            <p>Buea, Cameroon</p>
                        </div>
                        <div class="contact-social-icons">
                             <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                             <a href="#"><i class="fa-brands fa-twitter"></i></a>
                             <a href="#"><i class="fa-brands fa-instagram"></i></a>
                             <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="contact-form-wrapper reveal">
                        <form action="#" class="contact-form">
                            <div class="form-group-row">
                                <div class="form-group">
                                    <label for="firstName">First Name</label>
                                    <input type="text" id="firstName" name="firstName" required>
                                </div>
                                <div class="form-group">
                                    <label for="lastName">Last Name</label>
                                    <input type="text" id="lastName" name="lastName" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" required>
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea id="message" name="message" rows="6" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-large">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <section class="map-section">
             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31826.5495449298!2d9.220199852899032!3d4.164399991873292!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1061317574797e89%3A0x86a63810488d76e6!2sBuea%2C%20Cameroon!5e0!3m2!1sen!2s!4v1678886432123!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </section>

    </main>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col reveal">
                    <a href="index.php" class="logo">
                        <span class="logo-icon">R</span>
                        <span>ROVICC</span>
                    </a>
                    <p>Secure virtual credit cards for the digital age. Experience financial freedom with enhanced security.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-col reveal">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Press</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Security</a></li>
                        <li><a href="#">Developers</a></li>
                    </ul>
                </div>
                <div class="footer-col reveal">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Compliance</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2024 Rovicc Financial Technologies. All rights reserved.</p>
                <div class="payment-methods">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-amex"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                    <i class="fa-brands fa-cc-apple-pay"></i>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/script.js" defer></script>
</body>
</html>