<?php
/**
 * FILENAME: ShowCard_Token.php
 *
 * DESCRIPTION:
 * This script provides a form to enter a Sudo Card ID. On submission, it
 * generates a secure token via a server-side API call and displays that token.
 * It also renders sensitive card details using the Secure Proxy service.
 */

// --- CONFIGURATION (PRODUCTION) ---
define('API_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjJmYTVmMGQyMzZlNGE2ZmY1OWFkZjciLCJlbWFpbEFkZHJlc3MiOiJ0Y2hpbmRhcm9tYXJpYzYwQGdtYWlsLmNvbSIsImp0aSI6IjY3MzI1YzRkNjA0MWEzNzYyYjBkMmFlYiIsIm1lbWJlcnNoaXAiOnsiX2lkIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGZhIiwiYnVzaW5lc3MiOnsiX2lkIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGY1IiwibmFtZSI6IlJvdmljYyIsImlzQXBwcm92ZWQiOnRydWV9LCJ1c2VyIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGY3Iiwicm9sZSI6IkFQSUtleSJ9LCJpYXQiOjE3MzEzNTM2NzcsImV4cCI6MTc2MjkxMTI3N30.jjdOojt0J5AYaWIut2U7Izbb3DEVaRmMGo75QH4qmro'); // Replace with your actual API key
define('API_URL', 'https://api.sudo.africa/cards/');

// Initialize variables
$cardId = '';
$cardToken = ''; // This will hold the token for display
$error_message = '';
$raw_response = ''; // To hold the raw response for debugging

// --- SERVER-SIDE LOGIC ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cardId = htmlspecialchars(trim($_POST['cardId'] ?? ''));

    if (empty($cardId)) {
        $error_message = "Please enter a Card ID.";
    } else {
        // Generate Card Token
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => API_URL . $cardId . "/token",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer " . API_KEY,
                "Accept: application/json"
            ],
        ]);

        $response_body = curl_exec($curl);
        $curl_error = curl_error($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($curl_error) {
            $error_message = "A system error occurred: " . $curl_error;
        } else {
            $response_data = json_decode($response_body, true);
            $raw_response = $response_body; // Store the raw response for debugging
            if ($http_code == 200 && isset($response_data['data']['token'])) {
                // Successfully got the token, store it for display
                $cardToken = $response_data['data']['token'];
            } else {
                // Handle API errors (e.g., card not found, invalid API key)
                $error_message = "API Error: " . ($response_data['message'] ?? 'Could not retrieve token. HTTP Code: ' . $http_code);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sudo Card Token Viewer (Production)</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('public/frontend/') }}/css/virtual-card.css">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 2em; background-color: #f8f9fa; color: #212529; }
        .container { background-color: #fff; border: 1px solid #dee2e6; padding: 30px; border-radius: 8px; max-width: 600px; margin: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .input-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; }
        input[type="text"] { width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #ced4da; border-radius: 6px; font-size: 16px; }
        button { width: 100%; padding: 12px 15px; border: none; background-color: #007bff; color: white; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; }
        button:hover { background-color: #0056b3; }
        .response-box { margin-top: 25px; border-top: 1px solid #eee; padding-top: 20px; }
        .error { color: #721c24; background-color: #f8d7da; padding: 12px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #f5c6cb; }
        .token-display { padding: 10px; background-color: #e9ecef; border: 1px solid #ced4da; border-radius: 6px; font-family: monospace; word-wrap: break-word; font-size: 14px; }
        .raw-response { padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; border-radius: 6px; font-family: monospace; white-space: pre-wrap; }
        iframe { height: 20px; }
    </style>
</head>
<body>

<div class="container">
    <h2>Sudo Card Token Viewer (Production)</h2>
    <p>Enter a Card ID to generate a secure token and display card details.</p>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <div class="input-group">
            <label for="cardId">Card ID:</label>
            <input type="text" id="cardId" name="cardId" value="<?php echo htmlspecialchars($cardId); ?>" required>
        </div>
        <button type="submit">Get Token and Display Card Details</button>
    </form>

    <?php if ($error_message): ?>
        <p class="error"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <?php if ($cardToken): ?>
        <div class="response-box">
            <h3>Generated Card Token:</h3>
            <div class="token-display">
                <?php echo htmlspecialchars($cardToken); ?>
            </div>
        </div>

        <h3>Card Details:</h3>
        <label>Card Number:</label>
        <div class="cardNumber"></div>
        
        <label>CVV2:</label>
        <div id="cvv"></div>
        
        <h3>Raw API Response:</h3>
        <div class="raw-response">
            <?php echo htmlspecialchars($raw_response); ?>
        </div>
    <?php endif; ?>
</div>
<script type="text/javascript" src="https://js.verygoodvault.com/vgs-show/1.5/ACcHSbXEBmKzyoAT5fzzyLTu.js"></script>
<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
        if ("<?php echo $cardToken; ?>" !== "") {
            getSecureData();
        } else {
            console.error("Card token is empty. Cannot fetch secure data.");
        }
    });

    function getSecureData() {
        var show = VGSShow.create('tntpaxvvvet'); // Replace with your actual API vault ID
        var cardToken = "<?php echo $cardToken; ?>"; // PHP variable for card token
        var cardId = "<?php echo $cardId; ?>"; // PHP variable for card ID

        // Create an array of promises for both requests
        var cvvPromise = show.request({
            name: 'cvv-text',
            method: 'GET',
            path: '/cards/' + cardId + '/secure-data/cvv',
            headers: {
                "Authorization": "Bearer " + cardToken
            },
            htmlWrapper: 'text',
            jsonPathSelector: 'data.cvv'
        });

        var cardNumberPromise = show.request({
            name: 'pan-text',
            method: 'GET',
            path: '/cards/' + cardId + '/secure-data/number',
            headers: {
                "Authorization": "Bearer " + cardToken
            },
            htmlWrapper: 'text',
            jsonPathSelector: 'data.number'
        });

        // Use Promise.all to wait for both requests to complete
        Promise.all([cvvPromise, cardNumberPromise]).then(function(responses) {
            // Clear existing text
            

            // Render the fetched CVV and card number
            responses[0].render('#cvv');
            responses[1].render('.cardNumber');
        }).catch(function(error) {
            console.error("Error fetching secure data:", error);
            // Handle errors if needed
        });
    }
</script>
</body>
</html>
