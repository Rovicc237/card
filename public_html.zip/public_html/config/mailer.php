<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'PHPMailer-master/src/Exception.php';
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';

function getMailer(PDO $pdo): PHPMailer {
    try {
        // Fetch all necessary email settings in one go
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key LIKE 'smtp_%'");
        $settings_raw = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Assign settings with defaults
        $settings = [
            'smtp_host' => $settings_raw['smtp_host'] ?? '',
            'smtp_port' => $settings_raw['smtp_port'] ?? 587,
            'smtp_username' => $settings_raw['smtp_username'] ?? '',
            'smtp_password' => $settings_raw['smtp_password'] ?? '',
            'smtp_encryption' => $settings_raw['smtp_encryption'] ?? 'tls',
            'smtp_from_email' => $settings_raw['smtp_from_email'] ?? '',
            'smtp_from_name' => $settings_raw['smtp_from_name'] ?? 'Rovicc',
        ];

    } catch (PDOException $e) {
        error_log("Mailer Config Error: Could not fetch email settings from database. " . $e->getMessage());
        throw new Exception("System mailer is not configured.");
    }

    if (empty($settings['smtp_host']) || empty($settings['smtp_from_email'])) {
        error_log("Mailer Config Error: SMTP host or From Email is not set in the admin panel.");
        throw new Exception("System mailer is missing essential configuration.");
    }

    $mail = new PHPMailer(true); 

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = $settings['smtp_host'];
        $mail->SMTPAuth   = !empty($settings['smtp_username']);
        $mail->Username   = $settings['smtp_username'];
        $mail->Password   = $settings['smtp_password'];
        
        if (strtolower($settings['smtp_encryption']) === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        
        $mail->Port       = $settings['smtp_port'];

        // From Address - This is the crucial part
        $mail->setFrom($settings['smtp_from_email'], $settings['smtp_from_name']);

        // Content
        $mail->isHTML(true);

        return $mail;

    } catch (Exception $e) {
        error_log("PHPMailer could not be configured. Mailer Error: {$e->getMessage()}");
        throw $e; 
    }
}