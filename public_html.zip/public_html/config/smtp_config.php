<?php
// /public_html/config/smtp_config.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function get_mailer() {
    $mail = new PHPMailer(true);

    try {
        // --- Server settings are now hardcoded as requested ---
        // The debug level is now controlled by the script that calls this function.
        // $mail->SMTPDebug = SMTP::DEBUG_OFF; 
        
        $mail->isSMTP();
        $mail->Host       = 'd5.my-control-panel.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'mail@rovicc.com';
        $mail->Password   = '676244204aA@';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        // **CRITICAL FIX**: Set the From address directly in the mailer configuration.
        // This was the missing step in the cron job script. By adding it here,
        // all scripts that use get_mailer() will be correctly configured.
        $mail->setFrom('mail@rovicc.com', 'Rovicc Notifier');

    } catch (Exception $e) {
        // This will catch any configuration errors from PHPMailer
        error_log("PHPMailer Configuration Error: " . $e->getMessage());
        // We re-throw the exception to be handled by the calling script
        throw $e;
    }
    
    return $mail;
}
