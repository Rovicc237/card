<?php
// This script should be run by a cron job every 5 minutes.
// Example cron command: */5 * * * * /usr/bin/php /home/roviccco/public_html/cron/process_notifications.php?secret=YOUR_SECRET_KEY

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/cron_error.log');

if (php_sapi_name() !== 'cli' && (!isset($_GET['secret']) || $_GET['secret'] !== 'YOUR_VERY_SECRET_KEY_HERE')) {
    http_response_code(403);
    die('Forbidden');
}

require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

echo "--- Notification Processor Started: " . date('Y-m-d H:i:s') . " ---\n";

try {
    $stmt_admin_email = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key = 'notification_email'");
    $admin_email = $stmt_admin_email->fetchColumn();

    if (!$admin_email) {
        die("No admin notification email configured. Exiting.\n");
    }

    $stmt_transactions = $pdo->prepare("
        SELECT t.*, u.first_name, u.last_name, u.email
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        WHERE t.status = 'successful' AND t.admin_notified = 0
        LIMIT 5
    ");
    $stmt_transactions->execute();
    $transactions_to_notify = $stmt_transactions->fetchAll();

    if (empty($transactions_to_notify)) {
        echo "No new transactions to notify about. Exiting.\n";
        exit();
    }

    echo "Found " . count($transactions_to_notify) . " transaction(s) to process.\n";
    
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'd5.my-control-panel.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mail@rovicc.com';
    $mail->Password   = '676244204aA@';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;
    $mail->setFrom('mail@rovicc.com', 'Rovicc Notifier');

    foreach ($transactions_to_notify as $tx) {
        echo "Processing transaction ID: {$tx['id']}...\n";
        try {
            $mail->clearAddresses();
            $mail->addAddress($admin_email, 'Rovicc Admin');
            $mail->isHTML(true);
            $mail->Subject = '✅ SUCCESSFUL DEPOSIT: Rovicc Account Funded';
            
            $messageBody = "A new deposit has been successfully processed.<br><br>"
                          . "<strong>User:</strong> " . htmlspecialchars($tx['first_name'] . ' ' . $tx['last_name']) . "<br>"
                          . "<strong>Transaction Ref:</strong> " . htmlspecialchars($tx['tx_ref']);

            $mail->Body = $messageBody;
            $mail->send();

            echo "  - Email sent successfully.\n";

            $stmt_update_flag = $pdo->prepare("UPDATE transactions SET admin_notified = 1 WHERE id = ?");
            $stmt_update_flag->execute([$tx['id']]);
            echo "  - Database flag updated.\n";

        } catch (Exception $e) {
            echo "  - FAILED to send email for transaction ID {$tx['id']}: " . $mail->ErrorInfo . "\n";
        }
    }

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage() . "\n");
}

echo "--- Notification Processor Finished: " . date('Y-m-d H:i:s') . " ---\n";
