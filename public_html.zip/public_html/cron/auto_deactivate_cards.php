<?php
/**
 * This script is designed to be triggered by an external scheduler (cron job service).
 * It deactivates cards based on low balance or consecutive failed transaction charges and notifies the user via your centralized SMTP configuration.
 */

// --- Enhanced Error Reporting for Debugging ---
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- PHPMailer Inclusion ---
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// --- Security Check ---
define('CRON_SECRET_KEY', '676244204'); 

if (!isset($_GET['secret']) || $_GET['secret'] !== CRON_SECRET_KEY) {
    http_response_code(403);
    die('Forbidden: You do not have permission to access this script.');
}

// --- Dependency Inclusion ---
require_once __DIR__ . '/../../database/db.php';
// **THE FIX**: Include your centralized SMTP configuration file.
require_once __DIR__ . '/../config/smtp_config.php'; 
// Include PHPMailer library files, as they are required to instantiate the object.
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';


// --- Functions ---
function get_api_settings($pdo) {
    // This function now only needs to fetch Sudo-related and site settings.
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'site_name')");
    return $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
}

function call_sudo_api($method, $url, $apiKey, $payload = null) {
    $ch = curl_init();
    $headers = [
        "Authorization: Bearer " . $apiKey,
        "Content-Type: application/json",
        "Accept: application/json"
    ];
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FAILONERROR => false
    ];
    if ($method === 'PUT' && $payload) {
        $options[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $options);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    
    curl_close($ch);

    if ($response === false) {
        return ['code' => 'CURL_ERROR', 'body' => null, 'raw_body' => $curl_error];
    }
    
    return ['code' => $http_code, 'body' => json_decode($response, true), 'raw_body' => $response];
}

function log_card_check($pdo, $card_id, $user_id, $status_before, $action, $details) {
    try {
        $sql = "INSERT INTO card_check_logs (card_id, user_id, card_status_before_check, action_taken, details) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$card_id, $user_id, $status_before, $action, $details]);
    } catch (PDOException $e) {
        error_log("Failed to log card check for card ID {$card_id}: " . $e->getMessage());
    }
}


// --- Main Script Logic ---
echo "Cron Job Started: " . date('Y-m-d H:i:s') . "\n";

try {
    $api_settings = get_api_settings($pdo);
    
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;
    $site_name = htmlspecialchars($api_settings['site_name'] ?? 'Rovicc');

    if (!$sudo_api_key || !$sudo_base_url) {
        throw new Exception("Sudo API settings are not configured. Cron job cannot run.");
    }

    $stmt_cards = $pdo->query("SELECT id, card_id, user_id, account_id, last4, brand FROM virtual_cards WHERE status = 'active'");
    $active_cards = $stmt_cards->fetchAll(PDO::FETCH_ASSOC);

    echo "Found " . count($active_cards) . " active cards to check.\n";

    foreach ($active_cards as $card) {
        $card_db_id = $card['id'];
        $card_api_id = $card['card_id'];
        $card_account_id = $card['account_id'];
        $user_id = $card['user_id'];
        
        $should_deactivate = false;
        $deactivation_reason = '';

        echo "--- Checking Card API ID: {$card_api_id} ---\n";

        if (empty($card_account_id)) {
            echo "Skipping card {$card_api_id} because it has no account_id.\n";
            continue;
        }

        // CHECK 1: LOW BALANCE
        $balance_url = rtrim($sudo_base_url, '/') . "/accounts/{$card_account_id}/balance";
        $balance_response = call_sudo_api('GET', $balance_url, $sudo_api_key);

        if ($balance_response['code'] === 200 && isset($balance_response['body']['data']['currentBalance'])) {
            $balance = $balance_response['body']['data']['currentBalance'];
            echo "API Balance: \${$balance}\n";
            if ($balance < 2) {
                $should_deactivate = true;
                $deactivation_reason = "Low balance (less than $2)";
            }
        } else {
            continue; // Skip if we can't get balance
        }

        // CHECK 2: CONSECUTIVE FAILED TRANSACTION CHARGES
        if (!$should_deactivate) {
            $transactions_url = rtrim($sudo_base_url, '/') . "/cards/{$card_api_id}/transactions?limit=2";
            $transactions_response = call_sudo_api('GET', $transactions_url, $sudo_api_key);

            if ($transactions_response['code'] === 200 && isset($transactions_response['body']['data']) && count($transactions_response['body']['data']) >= 2) {
                $transactions = $transactions_response['body']['data'];
                $tx1_desc = $transactions[0]['merchant']['name'] ?? 'N/A';
                $tx2_desc = $transactions[1]['merchant']['name'] ?? 'N/A';
                echo "Latest two transaction descriptions: '{$tx1_desc}', '{$tx2_desc}'\n";

                if ($tx1_desc === 'Failed Transaction Charge' && $tx2_desc === 'Failed Transaction Charge') {
                    $should_deactivate = true;
                    $deactivation_reason = "Two consecutive failed transaction charges";
                }
            }
        }

        // DEACTIVATION LOGIC AND EMAIL NOTIFICATION
        if ($should_deactivate) {
            echo "DEACTIVATION TRIGGERED for card {$card_api_id}. Reason: {$deactivation_reason}\n";
            
            $deactivate_url = rtrim($sudo_base_url, '/') . '/cards/' . $card_api_id;
            $deactivate_response = call_sudo_api('PUT', $deactivate_url, $sudo_api_key, ['status' => 'inactive']);

            if ($deactivate_response['code'] === 200) {
                $stmt_deactivate = $pdo->prepare("UPDATE virtual_cards SET status = 'inactive' WHERE id = ?");
                $stmt_deactivate->execute([$card_db_id]);
                log_card_check($pdo, $card_api_id, $user_id, 'active', 'deactivated', $deactivation_reason);
                echo "SUCCESS: Card {$card_api_id} has been deactivated.\n";

                // --- SEND EMAIL NOTIFICATION TO USER ---
                $stmt_user = $pdo->prepare("SELECT first_name, email FROM users WHERE id = ?");
                $stmt_user->execute([$user_id]);
                $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                    try {
                        // Use your centralized mailer function
                        $mail = get_mailer(); 
                        
                        $mail->addAddress($user['email'], $user['first_name']);
                        $mail->isHTML(true);
                        $mail->Subject = 'Important Notice: Your Rovicc Virtual Card Has Been Deactivated';

                        $email_year = date('Y');
                        $card_last4 = htmlspecialchars($card['last4']);
                        $card_brand = htmlspecialchars($card['brand']);
                        $template_path = __DIR__ . '/emails/card_deactivation_template.html';

                        if (!file_exists($template_path)) {
                            throw new Exception("Email template file not found at: " . $template_path);
                        }
                        
                        $body = file_get_contents($template_path);
                        $body = str_replace('{{NAME}}', htmlspecialchars($user['first_name']), $body);
                        $body = str_replace('{{CARD_LAST4}}', $card_last4, $body);
                        $body = str_replace('{{CARD_BRAND}}', $card_brand, $body);
                        $body = str_replace('{{DEACTIVATION_REASON}}', htmlspecialchars($deactivation_reason), $body);
                        $body = str_replace('{{SITE_NAME}}', $site_name, $body);
                        $body = str_replace('{{YEAR}}', $email_year, $body);
                        $mail->Body = $body;

                        $mail->send();
                        echo "Sent deactivation email to {$user['email']} via SMTP.\n";
                    } catch (Exception $e) {
                        error_log("Failed to send deactivation email to {$user['email']} (Card {$card_api_id}): {$mail->ErrorInfo}");
                    }
                }
            } else {
                log_card_check($pdo, $card_api_id, $user_id, 'active', 'error', 'Deactivation failed at API level.');
            }
        } else {
            echo "Card passed all checks. Remains active.\n";
            log_card_check($pdo, $card_api_id, $user_id, 'active', 'none', 'Card checks passed.');
        }
    }

} catch (Exception $e) {
    error_log("Cron Job Error: " . $e->getMessage());
    echo "ERROR: " . $e->getMessage() . "\n";
    http_response_code(500);
}

echo "Cron Job Finished: " . date('Y-m-d H:i:s') . "\n";
?>