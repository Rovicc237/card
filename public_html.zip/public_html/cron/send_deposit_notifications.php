<?php
// This script should be run by a cron job every 5 minutes.
// Example cron command: */5 * * * * /usr/bin/php /home/roviccco/public_html/cron/send_deposit_notifications.php

// --- Configuration and Setup ---
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/cron_error.log');

// Set a longer execution time for sending multiple emails
set_time_limit(300); // 5 minutes

// --- !! IMPORTANT SECURITY STEP !! ---
// This key prevents unauthorized access to the script via a web browser.
$secret_key = '676244204'; 

// Security check: Ensure the script is run from the command line or with a valid secret key
if (php_sapi_name() !== 'cli' && (!isset($_GET['secret']) || $_GET['secret'] !== $secret_key)) {
    http_response_code(403);
    die('Forbidden: Access is denied.');
}

// --- Dependency Inclusion ---
require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../vendor/PHPMailer-master/src/Exception.php';

// --- PHPMailer Namespace ---
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

echo "--- Notification Processor Started: " . date('Y-m-d H:i:s') . " ---\n";

try {
    // --- Fetch Admin and Transaction Data ---
    $stmt_admin_email = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key = 'notification_email'");
    $admin_email = $stmt_admin_email->fetchColumn();

    if (!$admin_email) {
        die("Error: Admin notification email is not configured in settings. Exiting.\n");
    }

    // Fetch up to 5 pending notifications
    $stmt_transactions = $pdo->prepare("
        SELECT t.*, u.first_name, u.last_name, u.email
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        WHERE t.status = 'successful' AND t.email_sent = 'no'
        ORDER BY t.created_at ASC
        LIMIT 5
    ");
    $stmt_transactions->execute();
    $transactions_to_notify = $stmt_transactions->fetchAll();

    if (empty($transactions_to_notify)) {
        echo "No new transactions to notify about. Exiting.\n";
        exit();
    }

    echo "Found " . count($transactions_to_notify) . " transaction(s) to process.\n";

    // --- Initialize PHPMailer ---
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'd5.my-control-panel.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mail@rovicc.com';
    $mail->Password   = '676244204aA@'; // Consider using environment variables for credentials
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;
    $mail->setFrom('mail@rovicc.com', 'Rovicc');

    // --- Process Each Transaction ---
    foreach ($transactions_to_notify as $tx) {
        echo "Processing transaction ID: {$tx['id']} for User: {$tx['email']}...\n";
        
        $admin_email_sent = false;
        $user_email_sent = false;

        // --- 1. SEND EMAIL TO ADMIN (Original Method) ---
        try {
            $unique_id = mt_rand(10000, 99999);
            $mail->clearAddresses();
            $mail->addAddress($admin_email, 'Rovicc Admin');
            $mail->isHTML(true);
            
            $subject_line = '';
            $messageBody = '';

            switch ($tx['type']) {
                case 'deposit':
                    $subject_line = 'SUCCESSFUL DEPOSIT: Rovicc Account Funded';
                    $messageBody = "A new deposit has been successfully processed and the user's balance has been updated.<br><br>";
                    break;
                case 'card_funding':
                    $subject_line = 'CARD FUNDED: Virtual Card Top-Up Successful';
                    $messageBody = "A card funding transaction has been successfully processed.<br><br>";
                    break;
                case 'card_withdrawal':
                    $subject_line = 'CARD WITHDRAWAL: Funds Withdrawn from Card';
                    $messageBody = "A card withdrawal has been successfully processed.<br><br>";
                    break;
                case 'card_creation':
                    $subject_line = 'CARD BUY: NEW CARD';
                    $messageBody = "A new card has been created.<br><br>";
                    break;
                default:
                    $subject_line = 'TRANSACTION UPDATE: A transaction was successful';
                    $messageBody = "A transaction of type '{$tx['type']}' has been successfully processed.<br><br>";
                    break;
            }

            $mail->Subject = $subject_line . "[{$unique_id}] ";
            $template_path = __DIR__ . '/../admin/emails/admin_general_template.html';
            
            if (!file_exists($template_path)) {
                throw new Exception("Admin email template not found at {$template_path}");
            }
            $emailTemplate = file_get_contents($template_path);

            $messageBody .= "<strong>User:</strong> " . htmlspecialchars($tx['first_name'] . ' ' . $tx['last_name']) . "<br>"
                          . "<strong>Email:</strong> " . htmlspecialchars($tx['email']) . "<br>"
                          . "<strong>Amount (USD):</strong> $" . number_format($tx['amount_usd'], 2) . "<br>"
                          . "<strong>Amount (XAF):</strong> " . number_format($tx['amount_xaf'], 2) . " XAF<br>"
                          . "<strong>Transaction Ref:</strong> " . htmlspecialchars($tx['tx_ref']);

            $finalEmailBody = str_replace('{{NAME}}', 'Admin', $emailTemplate);
            $finalEmailBody = str_replace('{{SUBJECT}}', $mail->Subject, $finalEmailBody);
            $finalEmailBody = str_replace('{{MESSAGE_BODY}}', $messageBody, $finalEmailBody);
            $mail->Body = $finalEmailBody;
            
            $mail->send();
            echo "  - Admin email sent successfully.\n";
            $admin_email_sent = true;

        } catch (Exception $e) {
            echo "  - FAILED to send admin email for transaction ID {$tx['id']}: " . $mail->ErrorInfo . "\n";
        }

        // --- 2. SEND EMAIL TO USER (New Addition) ---
        if ($admin_email_sent) { // Only try to send to user if admin email was successful
            try {
                $mail->clearAddresses();
                $mail->addAddress($tx['email'], htmlspecialchars($tx['first_name'] . ' ' . $tx['last_name']));
                $mail->isHTML(true);
                $mail->Subject = 'Your Rovicc Transaction Receipt';

                $user_template_path = __DIR__ . '/../user/emails/user_transaction_notification.html';
                if (!file_exists($user_template_path)) {
                    throw new Exception("User email template not found at {$user_template_path}");
                }
                $userEmailTemplate = file_get_contents($user_template_path);

                $userBody = str_replace('{{USER_NAME}}', htmlspecialchars($tx['first_name']), $userEmailTemplate);
                $userBody = str_replace('{{TRANSACTION_TYPE}}', ucfirst(str_replace('_', ' ', $tx['type'])), $userBody);
                $userBody = str_replace('{{AMOUNT_USD}}', number_format($tx['amount_usd'], 2), $userBody);
                $userBody = str_replace('{{AMOUNT_XAF}}', number_format($tx['amount_xaf'], 2), $userBody);
                $userBody = str_replace('{{TX_REF}}', htmlspecialchars($tx['tx_ref']), $userBody);
                $userBody = str_replace('{{TIMESTAMP}}', date("F j, Y, g:i A", strtotime($tx['created_at'])), $userBody);

                $mail->Body = $userBody;
                $mail->send();
                echo "  - User email sent successfully.\n";
                $user_email_sent = true;

            } catch (Exception $e) {
                echo "  - FAILED to send user email for transaction ID {$tx['id']}: " . $mail->ErrorInfo . "\n";
            }
        }

        // --- 3. UPDATE DATABASE IF BOTH EMAILS SUCCEEDED ---
        if ($admin_email_sent && $user_email_sent) {
            $stmt_update_flag = $pdo->prepare("UPDATE transactions SET email_sent = 'yes' WHERE id = ?"); // Changed to 'yes' for consistency
            $stmt_update_flag->execute([$tx['id']]);
            echo "  - Database flag updated to 'yes'.\n";
        } else {
            echo "  - Database flag not updated due to an email sending failure.\n";
        }
        
        // Wait for 2 seconds before processing the next transaction
        echo "------------------------------------------------------\n";
        sleep(2);
    }

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage() . "\n");
} catch (Exception $e) {
    die("A general error occurred: " . $e->getMessage() . "\n");
}

echo "--- Notification Processor Finished: " . date('Y-m-d H:i:s') . " ---\n";