document.addEventListener('DOMContentLoaded', function () {
    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            const isActive = hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');

            if (isActive) {
                navLinks.style.maxHeight = navLinks.scrollHeight + "px";
            } else {
                navLinks.style.maxHeight = null;
            }
        });

        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navLinks.classList.remove('active');
                navLinks.style.maxHeight = null;
            });
        });
    }

    // Header scroll effect
    const header = document.querySelector('header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // Card flip on click
    const cardFlipper = document.querySelector('.card-flipper');
    if (cardFlipper) {
        cardFlipper.addEventListener('click', () => {
            cardFlipper.classList.toggle('is-flipped');
        });
    }

    // Scroll Reveal Animation
    const revealElements = document.querySelectorAll('.reveal');
    if (revealElements.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        revealElements.forEach(el => observer.observe(el));
    }

    // FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            const answer = item.querySelector('.faq-answer');

            question.addEventListener('click', () => {
                const otherActiveItem = document.querySelector('.faq-item.active');
                if (otherActiveItem && otherActiveItem !== item) {
                    otherActiveItem.classList.remove('active');
                    otherActiveItem.querySelector('.faq-answer').style.maxHeight = 0;
                }

                item.classList.toggle('active');
                if (item.classList.contains('active')) {
                    answer.style.maxHeight = answer.scrollHeight + "px";
                } else {
                    answer.style.maxHeight = 0;
                }
            });
        });
    }
});

// --- Floating Alert Function ---
function showAlert(message, type = 'success') {
    const alertContainer = document.getElementById('alert-container');
    if (!alertContainer) {
        console.error("Alert container not found!");
        return;
    }

    const alertBox = document.createElement('div');
    alertBox.className = `floating-alert ${type}`;

    const iconClass = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    alertBox.innerHTML = `<i class="fas ${iconClass}"></i><p>${message}</p>`;

    alertContainer.appendChild(alertBox);

    // Make the alert visible
    setTimeout(() => {
        alertBox.classList.add('visible');
    }, 100);

    // Hide the alert after 10 seconds
    setTimeout(() => {
        alertBox.classList.remove('visible');
        // Remove the element from the DOM after the transition ends
        alertBox.addEventListener('transitionend', () => {
            alertBox.remove();
        });
    }, 10000);
}