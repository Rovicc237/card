<?php
// Set the HTTP response code to 404
http_response_code(404);

// Check if a user session exists to determine which dashboard to link back to.
session_start();
$dashboard_link = "index.php"; // Default link
if (isset($_SESSION["user_id"])) {
    $dashboard_link = "user/dashboard.php";
} elseif (isset($_SESSION["admin_id"])) {
    $dashboard_link = "admin/dashboard.php";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #5A54D8;
            --background: #f7f8fc;
            --text-dark: #0D1022;
            --text-light: #6c757d;
            --white: #ffffff;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--background);
            color: var(--text-dark);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
        }
        .error-container {
            max-width: 500px;
            padding: 40px;
            background-color: var(--white);
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .error-code {
            font-size: 6rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0;
            line-height: 1;
        }
        .error-title {
            font-size: 1.75rem;
            font-weight: 600;
            margin: 20px 0 10px;
        }
        .error-message {
            color: var(--text-light);
            font-size: 1rem;
            margin-bottom: 30px;
        }
        .btn-home {
            display: inline-block;
            background-color: var(--primary);
            color: var(--white);
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-home:hover {
            background-color: #4540ae;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(90, 84, 216, 0.3);
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1 class="error-code">404</h1>
        <h2 class="error-title">Page Not Found</h2>
        <p class="error-message">We're sorry, but the page you were looking for doesn't exist. It might have been moved or deleted.</p>
        <a href="/<?= htmlspecialchars($dashboard_link) ?>" class="btn-home">
            <i class="fa-solid fa-house"></i> Go to Dashboard
        </a>
    </div>
</body>
</html>

