<?php

function authenticate_api_key($pdo) {
    $api_key = null;

    // Get API key from Authorization header
    $headers = getallheaders(); // This function might not be available in all SAPI (e.g., CGI)
    if (isset($headers['Authorization'])) {
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            $api_key = $matches[1];
        }
    }

    // IMPORTANT: Removed the fallback to $_GET['api_key'] for security.
    // API keys should ONLY be transmitted via the Authorization header.

    if ($api_key === null) {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "API Key is missing."]);
        exit();
    }

    // Validate the API key against the hashed keys in the database
    $stmt = $pdo->prepare("SELECT id, developer_id, api_key FROM developer_api_keys WHERE status = 'active'");
    $stmt->execute();
    $active_keys = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $authenticated_developer_id = null;
    $authenticated_api_key_id = null;

    foreach ($active_keys as $db_key_info) {
        // Use password_verify to check the provided key against the stored hash
        if (password_verify($api_key, $db_key_info['api_key'])) {
            $authenticated_developer_id = $db_key_info['developer_id'];
            $authenticated_api_key_id = $db_key_info['id'];
            break; // Key found and verified
        }
    }

    if ($authenticated_developer_id === null) {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Invalid or inactive API Key."]);
        exit();
    }

    return [$authenticated_developer_id, $authenticated_api_key_id];
}
?>