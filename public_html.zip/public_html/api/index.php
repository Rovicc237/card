<?php
// Set content type to JSON
header("Content-Type: application/json; charset=UTF-8");

// Define allowed origins for CORS
$allowed_origins = [
    'https://sandbox.rovicc.com',
    'https://rovicc.com'
    // Add any other trusted frontend origins here
];

// Check the Origin header from the incoming request
if (isset($_SERVER['HTTP_ORIGIN']) && in_array($_SERVER['HTTP_ORIGIN'], $allowed_origins)) {
    header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN']);
} else {
    // For origins not in the allowed list, do not send the Access-Control-Allow-Origin header.
    // Browsers will then enforce the same-origin policy, blocking the request.
    // Optionally, you might log attempts from disallowed origins for monitoring.
}

header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle OPTIONS method for CORS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
require_once __DIR__ . '/../../database/db.php'; // Path from public_html/api/index.php to public_html/database/db.php

// Include API authentication middleware
require_once __DIR__ . '/middleware/auth.php'; // Path to authentication logic

// --- API Routing Logic ---
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri_segments = explode('/', trim($request_uri, '/'));

// Assuming API base path is /api/v1/
// We need to find the segments after 'api' and 'v1'
// Example: /api/v1/cards/create -> segments [..., 'api', 'v1', 'cards', 'create']
$api_index = array_search('api', $uri_segments);
$version_index = array_search('v1', $uri_segments);

$endpoint_path = [];
if ($api_index !== false && $version_index !== false && $version_index > $api_index) {
    // Get segments after /api/v1/
    $endpoint_path = array_slice($uri_segments, $version_index + 1);
} else {
    // If /api/v1/ structure is not matched, return 404
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Invalid API endpoint format."]);
    exit();
}


// Determine the endpoint file based on the first segment
$resource = !empty($endpoint_path[0]) ? $endpoint_path[0] : '';
$action = !empty($endpoint_path[1]) ? $endpoint_path[1] : '';

// Authenticate API request
// The authenticate_api_key function (from middleware/auth.php) will either
// populate $authenticated_developer_id and $authenticated_api_key_id or exit with an error.
list($authenticated_developer_id, $authenticated_api_key_id) = authenticate_api_key($pdo);

// Pass the authenticated developer ID to the endpoint logic
$_REQUEST['authenticated_developer_id'] = $authenticated_developer_id;
$_REQUEST['authenticated_api_key_id'] = $authenticated_api_key_id;


// Simple routing based on resource and action.
switch ($resource) {
    case 'status':
        require_once __DIR__ . '/v1/endpoints/status.php';
        break;
    case 'developer':
        if ($action === 'info') {
            require_once __DIR__ . '/v1/endpoints/developer_info.php';
        } else {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Developer endpoint not found."]);
        }
        break;
    case 'customers':
        if ($action === 'create') {
            require_once __DIR__ . '/v1/endpoints/customers/create.php';
        } else {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Customer endpoint not found or action not supported."]);
        }
        break;
    case 'cards':
        if ($action === 'create') {
            require_once __DIR__ . '/v1/endpoints/cards/create.php';
        } elseif ($action === 'fund') {
            require_once __DIR__ . '/v1/endpoints/cards/fund.php';
        } elseif ($action === 'withdraw') {
            require_once __DIR__ . '/v1/endpoints/cards/withdraw.php';
        } elseif ($action === 'balance') { // This is the new endpoint
            require_once __DIR__ . '/v1/endpoints/cards/balance.php';
        } elseif ($action === 'transactions') {
            require_once __DIR__ . '/v1/endpoints/cards/transactions.php';
        } elseif ($action === 'details') { // NEW ACTION FOR GETTING SECURE DETAILS TOKEN
            require_once __DIR__ . '/v1/endpoints/cards/details.php';
        } elseif ($action === 'authorizations') { // NEW ACTION FOR GETTING AUTHORIZATIONS
            require_once __DIR__ . '/v1/endpoints/cards/authorizations.php';
        }
        else {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Card endpoint not found or action not supported."]);
        }
        break;
    default:
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "API Endpoint Not Found."]);
        break;
}

// Exit after including the endpoint file to prevent further execution
exit();
?>