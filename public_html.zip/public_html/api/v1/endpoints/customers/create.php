<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Helper function to call the Sudo API (reused)
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Only POST requests are allowed for this endpoint."]);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents("php://input"), true);

$first_name = trim($input['first_name'] ?? '');
$last_name = trim($input['last_name'] ?? '');
$email = trim($input['email'] ?? '');
$phone = trim($input['phone'] ?? '');
$dob = trim($input['dob'] ?? ''); // YYYY-MM-DD
$id_card_front_url = trim($input['id_card_front_url'] ?? '');
$id_card_back_url = trim($input['id_card_back_url'] ?? '');

// Basic validation (updated to make ID card URLs mandatory)
if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($dob) || empty($id_card_front_url) || empty($id_card_back_url)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing required customer details: first_name, last_name, email, phone, dob, id_card_front_url, id_card_back_url."]);
    exit();
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid email format."]);
    exit();
}
// Validate DOB format (simple check, YYYY-MM-DD)
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $dob)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid DOB format. Use YYYY-MM-DD."]);
    exit();
}
// Optional: Add URL validation for ID card URLs if needed
// if (!filter_var($id_card_front_url, FILTER_VALIDATE_URL) || !filter_var($id_card_back_url, FILTER_VALIDATE_URL)) {
//     http_response_code(400);
//     echo json_encode(["status" => "error", "message" => "Invalid format for ID card front/back URLs."]);
//     exit();
// }


// Authenticated Developer ID (who is making this customer creation request)
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    $pdo->beginTransaction();

    // 1. Fetch Sudo API Settings
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;

    if (empty($sudo_api_key) || empty($sudo_base_url)) {
        http_response_code(500);
        error_log("API Customer Creation Error: Sudo API keys/base URL missing in configuration.");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred. Please contact support."]);
        exit();
    }

    $api_customer_id = null;
    $sudo_customer_id = null;
    $message_suffix = "";

    // 2. Check for existing API Customer
    $stmt_check_api_customer = $pdo->prepare("SELECT id, sudo_customer_id, first_name, last_name, email, phone, dob FROM api_customers WHERE email = ?");
    $stmt_check_api_customer->execute([$email]);
    $existing_api_customer = $stmt_check_api_customer->fetch(PDO::FETCH_ASSOC);

    if ($existing_api_customer) {
        $api_customer_id = $existing_api_customer['id'];
        $sudo_customer_id = $existing_api_customer['sudo_customer_id'];
        $message_suffix = "Existing API customer found and details retrieved.";

        // If API customer exists but Sudo customer ID is missing, try to create it
        if (empty($sudo_customer_id)) {
            $customerData = [
                'type' => 'individual', 'status' => 'active', 'name' => $existing_api_customer['first_name'] . ' ' . $existing_api_customer['last_name'],
                'phoneNumber' => $existing_api_customer['phone'], 'emailAddress' => $existing_api_customer['email'],
                'individual' => [
                    'firstName' => $existing_api_customer['first_name'], 'lastName' => $existing_api_customer['last_name'],
                    'dob' => $existing_api_customer['dob'],
                    'identity' => ['type' => 'NIN', 'number' => '12345678901'], // Placeholder NIN
                    'documents' => [
                        'idFrontUrl' => $id_card_front_url, // Use passed mandatory URL
                        'idBackUrl' => $id_card_back_url,   // Use passed mandatory URL
                    ]
                ],
                'billingAddress' => [
                    'line1' => '123 Main Street', 'city' => 'Lagos', 'state' => 'Lagos',
                    'country' => 'NG', 'postalCode' => '100001'
                ]
            ];
            $customerResponse = callSudoApi('POST', $sudo_base_url . 'customers', $sudo_api_key, $customerData);
            if (!isset($customerResponse['data']['_id'])) {
                $errorMsg = is_array($customerResponse['message']) ? json_encode($customerResponse['message']) : ($customerResponse['message'] ?? 'Unknown Error');
                error_log("Failed to create Sudo customer for existing API customer. Sudo Response: " . $errorMsg);
                throw new Exception('Failed to create customer profile with card provider.');
            }
            $sudo_customer_id = $customerResponse['data']['_id'];
            $pdo->prepare("UPDATE api_customers SET sudo_customer_id = ? WHERE id = ?")->execute([$sudo_customer_id, $api_customer_id]);
            $message_suffix = "Existing API customer found, Sudo customer profile created.";
        }
    } else {
        // 3. Create New API Customer
        $message_suffix = "New API customer created.";
        
        $sql_insert_api_customer = "INSERT INTO api_customers (developer_id, first_name, last_name, email, phone, dob, id_card_front_url, id_card_back_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert_api_customer = $pdo->prepare($sql_insert_api_customer);
        
        // Store provided id_card_front_url/id_card_back_url directly in the database
        // Assuming the provided URLs are already the full paths you want to store.
        // If you need to store just filenames, you'll need to extract them here.
        if (!$stmt_insert_api_customer->execute([$authenticated_developer_id, $first_name, $last_name, $email, $phone, $dob, $id_card_front_url, $id_card_back_url])) {
            error_log("Failed to create new API customer account in database.");
            throw new Exception("Failed to create new API customer account.");
        }
        $api_customer_id = $pdo->lastInsertId();

        // 4. Create Sudo Customer for New API Customer
        $customerData = [
            'type' => 'individual', 'status' => 'active', 'name' => $first_name . ' ' . $last_name,
            'phoneNumber' => $phone, 'emailAddress' => $email,
            'individual' => [
                'firstName' => $first_name, 'lastName' => $last_name, 'dob' => $dob,
                'identity' => ['type' => 'NIN', 'number' => '12345678901'], // Placeholder NIN
                'documents' => [
                    'idFrontUrl' => $id_card_front_url, // Use passed mandatory URL
                    'idBackUrl' => $id_card_back_url,   // Use passed mandatory URL
                ]
            ],
            'billingAddress' => [
                'line1' => '123 Main Street', 'city' => 'Lagos', 'state' => 'Lagos',
                'country' => 'NG', 'postalCode' => '100001'
            ]
        ];
        $customerResponse = callSudoApi('POST', $sudo_base_url . 'customers', $sudo_api_key, $customerData);
        if (!isset($customerResponse['data']['_id'])) {
            $errorMsg = is_array($customerResponse['message']) ? json_encode($customerResponse['message']) : ($customerResponse['message'] ?? 'Unknown Error');
            error_log("Failed to create Sudo customer profile. Sudo Response: " . $errorMsg);
            throw new Exception('Failed to create customer profile with card provider.');
        }
        $sudo_customer_id = $customerResponse['data']['_id'];
        $pdo->prepare("UPDATE api_customers SET sudo_customer_id = ? WHERE id = ?")->execute([$sudo_customer_id, $api_customer_id]);
    }

    $pdo->commit();

    http_response_code(200);
    echo json_encode([
        "status" => "success",
        "message" => $message_suffix,
        "data" => [
            "api_customer_id" => $api_customer_id,
            "email" => $email,
            "first_name" => $first_name,
            "last_name" => $last_name,
            "sudo_customer_id" => $sudo_customer_id
        ]
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Log the detailed error for internal debugging
    error_log("API Customer Creation General Error: " . $e->getMessage());
    http_response_code(500);
    // Return a generic error message to the client
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred during customer creation. Please try again."]);
}

exit();