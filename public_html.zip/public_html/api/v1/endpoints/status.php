<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

http_response_code(200); // OK
echo json_encode([
    "status" => "success",
    "message" => "API is up and running!",
    "authenticated_developer_id" => $_REQUEST['authenticated_developer_id'] ?? null,
    "authenticated_api_key_id" => $_REQUEST['authenticated_api_key_id'] ?? null,
    "timestamp" => date('Y-m-d H:i:s')
]);
?>