<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Helper function to call the Sudo API (reused from other endpoints)
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => "error", "message" => "Only POST requests are allowed for this endpoint."]);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents("php://input"), true);

$card_id_to_withdraw = trim($input['card_id'] ?? '');
$amount_to_withdraw_usd = $input['amount_usd'] ?? null;

// Validate input
if (empty($card_id_to_withdraw)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing 'card_id' in request body."]);
    exit();
}
if (!is_numeric($amount_to_withdraw_usd) || (float)$amount_to_withdraw_usd <= 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or missing 'amount_usd'. Must be a positive number."]);
    exit();
}

$amount_to_withdraw_usd = (float)$amount_to_withdraw_usd;

// Authenticated Developer ID
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    // 1. Verify the card exists and belongs to a customer/user managed by this developer
    // ## SECURITY FIX: Replaced subquery with a JOIN to prevent SQL Injection ##
    $stmt_card = $pdo->prepare("
        SELECT 
            vc.id AS virtual_card_db_id, 
            vc.user_id, 
            vc.api_customer_id, 
            vc.account_id, /* This is the Sudo account_id for the card */
            vc.brand, 
            vc.maskedPan,
            u.email AS user_email,
            ac.email AS api_customer_email
        FROM virtual_cards vc
        LEFT JOIN users u ON vc.user_id = u.id
        LEFT JOIN api_customers ac ON vc.api_customer_id = ac.id
        LEFT JOIN developers d ON u.email = d.email
        WHERE vc.card_id = ? 
        AND (d.id = ? OR ac.developer_id = ?)
    ");
    $stmt_card->execute([$card_id_to_withdraw, $authenticated_developer_id, $authenticated_developer_id]);
    $card_info = $stmt_card->fetch(PDO::FETCH_ASSOC);

    if (!$card_info) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Card not found or not accessible."]);
        exit();
    }

    $sudo_card_account_id = $card_info['account_id']; // This is the source account for the transfer
    $target_user_id = $card_info['user_id'];
    $target_api_customer_id = $card_info['api_customer_id'];
    $card_brand = $card_info['brand'];
    $card_masked_pan = $card_info['maskedPan'];
    $target_customer_email = $card_info['user_email'] ?? $card_info['api_customer_email'];


    // 2. Fetch API Settings (Sudo credentials, funding source, fees, USD to XAF rate)
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings 
                                  WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'usd_to_xaf_rate', 'card_withdrawal_fixed_fee', 'card_withdrawal_percentage_fee')"); // Removed sudo_funding_source_id as it's not used in this specific transfer payload
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;
    $creditAccountId = $settings['sudo_account_id'] ?? null; // Rovicc's main credit account for Sudo (destination of funds)
    $usd_to_xaf_rate = (float)($settings['usd_to_xaf_rate'] ?? 645);
    
    // Assuming you have withdrawal fees configured in api_settings
    $withdrawal_fixed_fee_usd = (float)($settings['card_withdrawal_fixed_fee'] ?? 0); // Default fixed fee
    $withdrawal_percentage_fee = (float)($settings['card_withdrawal_percentage_fee'] ?? 0); // Default percentage fee (0-100)

    if (empty($sudo_api_key) || empty($sudo_base_url) || empty($creditAccountId)) { // fundingSourceId removed from check here too
        http_response_code(500);
        error_log("API Card Withdrawal Error: Sudo API configuration missing (API key, base URL, or credit account).");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred. Please contact support."]);
        exit();
    }

    // Calculate total amount to debit from card (withdrawal amount + fees)
    $percentage_fee_amount = $amount_to_withdraw_usd * ($withdrawal_percentage_fee / 100);
    $total_amount_from_card_usd = $amount_to_withdraw_usd + $withdrawal_fixed_fee_usd + $percentage_fee_amount;
    $amount_to_credit_developer_usd = $amount_to_withdraw_usd; // Developer receives the requested amount

    // 3. Get current card balance from Sudo to check for sufficient funds
    $card_balance_url = rtrim($sudo_base_url, '/') . '/accounts/' . $sudo_card_account_id . '/balance';
    $balance_response = callSudoApi('GET', $card_balance_url, $sudo_api_key);

    if (!isset($balance_response['data']['currentBalance'])) {
        error_log("Sudo API Balance Check Failed for card {$card_id_to_withdraw}. Response: " . json_encode($balance_response));
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to retrieve card balance from the provider. Please try again."]);
        exit();
    }
    $current_card_balance_usd = (float)$balance_response['data']['currentBalance'];

    if ($current_card_balance_usd < $total_amount_from_card_usd) {
        http_response_code(402); // Payment Required
        echo json_encode(["status" => "error", "message" => "Insufficient balance on card. Required: " . number_format($total_amount_from_card_usd, 2) . " USD (including fees). Card balance: " . number_format($current_card_balance_usd, 2) . " USD."]);
        exit();
    }


    // 4. Withdraw from Card via Sudo API using /accounts/transfer (MATCHING WORKING USER FLOW)
    // Funds move from card's Sudo account to Rovicc's main Sudo account
    $sudo_transfer_url = rtrim($sudo_base_url, '/') . '/accounts/transfer';
    
    // Generate a unique paymentReference for this transfer
    $tx_ref_transfer = "API-WITHDRAW-TX-" . ($target_user_id ?? $target_api_customer_id) . "-" . time();

    $withdraw_payload = [
        'debitAccountId' => $sudo_card_account_id,  // Source: The card's Sudo account
        'amount' => $total_amount_from_card_usd,      // Total amount to debit from card (including Sudo fees if Sudo takes them here)
        'narration' => "API Withdrawal from card " . ($card_masked_pan ?? $card_id_to_withdraw) . " to Rovicc main account",
        'paymentReference' => $tx_ref_transfer, // Unique reference for the transfer
        'creditAccountId' => $creditAccountId // Destination: Rovicc's main Sudo account
    ];

    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Attempting Sudo WITHDRAWAL API Call. URL: {$sudo_transfer_url}. Payload: " . json_encode($withdraw_payload));
    // --- ENHANCED LOGGING END ---

    $sudo_response = callSudoApi('POST', $sudo_transfer_url, $sudo_api_key, $withdraw_payload);

    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Sudo WITHDRAWAL API Raw Response: " . json_encode($sudo_response));
    // --- ENHANCED LOGGING END ---

    // Sudo transfer API returns a transfer object, not necessarily an '_id' on the direct response.
    if (!isset($sudo_response['data']['_id']) && !(isset($sudo_response['status']) && $sudo_response['status'] === 'success')) {
        $rawResponse = json_encode($sudo_response);
        $httpStatus = $sudo_response['statusCode'] ?? 'N/A';
        $errorMessage = $sudo_response['message'] ?? 'An unknown error occurred with the card provider during withdrawal transfer.';
        if (is_array($errorMessage)) {
            $errorMessage = implode(', ', $errorMessage);
        }
        error_log("Sudo API Card Withdrawal Transfer Failed: Status {$httpStatus}. Message: {$errorMessage}. Response: {$rawResponse}");
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to process card withdrawal with the provider. Please try again or contact support."]);
        exit();
    }
    
    $sudo_transfer_id = $sudo_response['data']['_id'] ?? ($sudo_response['data']['id'] ?? 'N/A');
    $sudo_transfer_status = $sudo_response['data']['status'] ?? 'N/A';


    // 5. Database Transaction: Credit Developer, Log Transaction
    $pdo->beginTransaction();
    try {
        // Credit authenticated developer's linked user account balance
        $stmt_credit_balance = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE email = (SELECT email FROM developers WHERE id = ?)");
        $stmt_credit_balance->execute([$amount_to_credit_developer_usd, $authenticated_developer_id]);

        // Log transaction
        $tx_ref_db = "API-WITHDRAW-" . ($target_user_id ?? $target_api_customer_id) . "-" . time(); // Using a different ref name for DB
        $sql_log_tx = "INSERT INTO transactions (user_id, api_customer_id, tx_ref, amount_usd, amount_xaf, status, payment_gateway, type, description, gateway_response) VALUES (?, ?, ?, ?, ?, 'completed', 'Sudo API', 'card_withdrawal', ?, ?)";
        $stmt_log_tx = $pdo->prepare($sql_log_tx);
        $stmt_log_tx->execute([
            $target_user_id,
            $target_api_customer_id,
            $tx_ref_db,
            $amount_to_withdraw_usd, // Log the amount effectively withdrawn
            $amount_to_withdraw_usd * $usd_to_xaf_rate, // Convert to XAF for logging
            "API Card Withdrawal from " . ($card_masked_pan ?? $card_id_to_withdraw) . " (Amount: $" . number_format($amount_to_withdraw_usd, 2) . ", Fees: $" . number_format($withdrawal_fixed_fee_usd + $percentage_fee_amount, 2) . ")",
            json_encode($sudo_response) // Log the full Sudo response
        ]);

        $pdo->commit();

        // Prepare success response
        http_response_code(200); // OK
        echo json_encode([
            "status" => "success",
            "message" => "Funds successfully withdrawn from card to developer's balance.",
            "data" => [
                "card_id" => $card_id_to_withdraw,
                "amount_withdrawn_usd" => $amount_to_withdraw_usd,
                "fees_usd" => $withdrawal_fixed_fee_usd + $percentage_fee_amount,
                "total_debited_from_card_usd" => $total_amount_from_card_usd,
                "transaction_ref" => $tx_ref_db, // Our internal transaction reference
                "sudo_transfer_id" => $sudo_transfer_id, // Sudo's transfer ID
                "sudo_transfer_status" => $sudo_transfer_status // Sudo's transfer status
            ]
        ]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("API Card Withdrawal DB Transaction Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "An internal database error occurred during withdrawal. Please try again."]);
    }

} catch (Exception $e) {
    error_log("API Card Withdrawal General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred during card withdrawal. Please try again."]);
}

exit();