<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Define API-specific card creation fee in USD
// This overrides the values set in api_settings for API-driven card creations.
define('API_CARD_CREATION_FEE_USD', 3.00);

// Helper function to call the Sudo API (copied from initiate_card_creation.php / get_card_balance.php)
if (!function_exists('callSudoApi')) { // Check if function already exists to prevent redeclaration errors
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => "error", "message" => "Only POST requests are allowed for this endpoint."]);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents("php://input"), true);

$card_brand = $input['card_brand'] ?? null;
$initial_funding_amount_usd = $input['initial_funding_amount_usd'] ?? null;
$target_customer_email = trim($input['customer_email'] ?? ''); // Optional target customer email
$target_api_customer_id = (int)($input['api_customer_id'] ?? 0); // Optional target api_customer_id

// Validate input
if (empty($card_brand) || !in_array(strtolower($card_brand), ['visa', 'mastercard'])) { // ## SECURITY FIX: Case-insensitive validation ##
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or missing 'card_brand'. Must be 'Visa' or 'MasterCard'."]);
    exit();
}
if (!is_numeric($initial_funding_amount_usd) || (float)$initial_funding_amount_usd < 3) { // Minimum initial funding of $3
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or missing 'initial_funding_amount_usd'. Must be a positive number and at least $3."]);
    exit();
}

$initial_funding_amount_usd = (float)$initial_funding_amount_usd;

// Authenticated Developer ID
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    // Determine the user_id of the authenticated developer's linked Rovicc account
    // This is the account from which money will be deducted and whose ID will be stored in virtual_cards.user_id.
    $stmt_payer_user = $pdo->prepare("SELECT id, email, balance FROM users WHERE email = (SELECT email FROM developers WHERE id = ?)");
    $stmt_payer_user->execute([$authenticated_developer_id]);
    $payer_user = $stmt_payer_user->fetch(PDO::FETCH_ASSOC);

    if (!$payer_user) {
        http_response_code(404);
        error_log("API Card Creation Error: No linked Rovicc user account found for developer ID: " . $authenticated_developer_id);
        echo json_encode(["status" => "error", "message" => "An internal account error occurred. Please contact support."]);
        exit();
    }
    $payer_user_id = $payer_user['id']; // This is the ID we'll store in virtual_cards.user_id
    $payer_user_balance = (float)$payer_user['balance'];


    // 1. Determine the target customer for card creation (the actual card owner)
    // This logic ensures we get the correct user/api_customer/sudo_customer_id based on priority
    
    $card_owner_user_id_for_tx = null; // This will be used for transactions.user_id if owner is a regular Rovicc user
    $card_owner_api_customer_id_for_tx = null; // This will be used for transactions.api_customer_id if owner is an API customer
    $target_sudo_customer_id = null;
    $target_customer_email_db = null;
    $target_customer_first_name = null;
    $target_customer_last_name = null;
    $target_customer_phone = null;
    $target_customer_dob = null;
    $target_customer_id_front = null;
    $target_customer_id_back = null;

    if ($target_api_customer_id > 0) {
        // Option A: Target by api_customer_id
        // ## SECURITY FIX: Added developer_id to the WHERE clause to prevent IDOR ##
        $stmt_api_customer = $pdo->prepare("SELECT id, sudo_customer_id, first_name, last_name, email, phone, dob, id_card_front_url, id_card_back_url FROM api_customers WHERE id = ? AND developer_id = ?");
        $stmt_api_customer->execute([$target_api_customer_id, $authenticated_developer_id]);
        $target_customer_data = $stmt_api_customer->fetch(PDO::FETCH_ASSOC);

        if (!$target_customer_data) {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "The specified API customer was not found or does not belong to you."]);
            exit();
        }
        $card_owner_api_customer_id_for_tx = $target_customer_data['id']; // This API customer is the owner for TX
        $target_sudo_customer_id = $target_customer_data['sudo_customer_id'];
        $target_customer_email_db = $target_customer_data['email'];
        $target_customer_first_name = $target_customer_data['first_name'];
        $target_customer_last_name = $target_customer_data['last_name'];
        $target_customer_phone = $target_customer_data['phone'];
        $target_customer_dob = $target_customer_data['dob'];
        $target_customer_id_front = $target_customer_data['id_card_front_url'];
        $target_customer_id_back = $target_customer_data['id_card_back_url'];
        
        // Check if this api_customer also exists in users table (optional linking for description/UI consistency)
        $stmt_linked_user = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt_linked_user->execute([$target_customer_email_db]);
        $linked_user_data = $stmt_linked_user->fetch(PDO::FETCH_ASSOC);
        if($linked_user_data) {
            $card_owner_user_id_for_tx = $linked_user_data['id']; // This regular user is the owner for TX
        }

    } elseif (!empty($target_customer_email)) {
        // Option B: Target by email (check api_customers first, then users)
        if (!filter_var($target_customer_email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "The provided customer email address is invalid."]);
            exit();
        }
        // ## SECURITY FIX: Added developer_id to the WHERE clause to prevent IDOR ##
        $stmt_api_customer = $pdo->prepare("SELECT id, sudo_customer_id, first_name, last_name, email, phone, dob, id_card_front_url, id_card_back_url FROM api_customers WHERE email = ? AND developer_id = ?");
        $stmt_api_customer->execute([$target_customer_email, $authenticated_developer_id]);
        $target_customer_data = $stmt_api_customer->fetch(PDO::FETCH_ASSOC);

        if ($target_customer_data) { // Found in api_customers
            $card_owner_api_customer_id_for_tx = $target_customer_data['id']; // This API customer is the owner for TX
            $target_sudo_customer_id = $target_customer_data['sudo_customer_id'];
            $target_customer_email_db = $target_customer_data['email'];
            $target_customer_first_name = $target_customer_data['first_name'];
            $target_customer_last_name = $target_customer_data['last_name'];
            $target_customer_phone = $target_customer_data['phone'];
            $target_customer_dob = $target_customer_data['dob'];
            $target_customer_id_front = $target_customer_data['id_card_front_url'];
            $target_customer_id_back = $target_customer_data['id_card_back_url'];
            
            // Check if this api_customer also exists in users table
            $stmt_linked_user = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt_linked_user->execute([$target_customer_email]);
            $linked_user_data = $stmt_linked_user->fetch(PDO::FETCH_ASSOC);
            if($linked_user_data) {
                $card_owner_user_id_for_tx = $linked_user_data['id']; // This regular user is the owner for TX
            }

        } else { // Not found in api_customers, check in regular users table
            $stmt_user = $pdo->prepare("SELECT id, sudo_customer_id, first_name, last_name, email, phone, dob, id_card_front, id_card_back FROM users WHERE email = ?");
            $stmt_user->execute([$target_customer_email]);
            $target_user_data = $stmt_user->fetch(PDO::FETCH_ASSOC);

            if (!$target_user_data) {
                http_response_code(404);
                echo json_encode(["status" => "error", "message" => "The specified customer was not found. Please ensure the customer exists or create them first."]);
                exit();
            }
            $card_owner_user_id_for_tx = $target_user_data['id']; // This regular user is the owner for TX
            $target_sudo_customer_id = $target_user_data['sudo_customer_id'];
            $target_customer_email_db = $target_user_data['email'];
            $target_customer_first_name = $target_user_data['first_name'];
            $target_customer_last_name = $target_user_data['last_name'];
            $target_customer_phone = $target_user_data['phone'];
            $target_customer_dob = $target_user_data['dob'];
            $target_customer_id_front = $target_user_data['id_card_front'];
            $target_customer_id_back = $target_user_data['id_card_back'];
        }
    } else {
        // Option C: Default to the authenticated developer's linked user account
        // In this case, the card owner IS the payer
        $card_owner_user_id_for_tx = $payer_user_id; // Card owner is the developer's linked user for TX
        
        $stmt_user = $pdo->prepare("SELECT sudo_customer_id, first_name, last_name, email, phone, dob, id_card_front, id_card_back FROM users WHERE id = ?");
        $stmt_user->execute([$card_owner_user_id_for_tx]);
        $user_data_default = $stmt_user->fetch(PDO::FETCH_ASSOC);

        if (!$user_data_default) {
            http_response_code(404);
            error_log("API Card Creation Error: Developer's linked user account not found for card ownership (ID: " . $card_owner_user_id_for_tx . ")");
            echo json_encode(["status" => "error", "message" => "An internal account error occurred for the card owner. Please contact support."]);
            exit();
        }
        $target_sudo_customer_id = $user_data_default['sudo_customer_id'];
        $target_customer_email_db = $user_data_default['email'];
        $target_customer_first_name = $user_data_default['first_name'];
        $target_customer_last_name = $user_data_default['last_name'];
        $target_customer_phone = $user_data_default['phone'];
        $target_customer_dob = $user_data_default['dob'];
        $target_customer_id_front = $user_data_default['id_card_front'];
        $target_customer_id_back = $user_data_default['id_card_back'];
        // $card_owner_api_customer_id_for_tx remains NULL as this is a regular user.
    }

    // Now, $card_owner_user_id_for_tx (card owner for TX), $card_owner_api_customer_id_for_tx (card owner for TX), and $target_sudo_customer_id are set.
    // $payer_user_id (payer) is always set to the developer's linked Rovicc user ID.


    // 2. Fetch API Settings (Sudo credentials, funding source, USD to XAF rate)
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings 
                                  WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'sudo_funding_source_id', 'usd_to_xaf_rate')");
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;
    $debitAccountId = $settings['sudo_account_id'] ?? null; // Rovicc's main debit account for Sudo
    $fundingSourceId = $settings['sudo_funding_source_id'] ?? null; // Rovicc's default funding source
    $usd_to_xaf_rate = (float)($settings['usd_to_xaf_rate'] ?? 645); // Default rate if not set

    // Calculate total cost (fixed API fee + requested funding)
    $total_cost_usd = API_CARD_CREATION_FEE_USD + $initial_funding_amount_usd;
    $total_cost_xaf = $total_cost_usd * $usd_to_xaf_rate;

    if (empty($sudo_api_key) || empty($sudo_base_url) || empty($debitAccountId) || empty($fundingSourceId)) {
        http_response_code(500);
        error_log("API Card Creation Error: Sudo API configuration missing (API key, base URL, debit account, or funding source).");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred. Please contact support."]);
        exit();
    }

    // 3. Check Authenticated Developer's Balance (Developer pays for the card)
    // The balance check must be against the developer's *own* linked Rovicc user account.
    if ($payer_user_balance < $total_cost_usd) {
        http_response_code(402); // Payment Required
        echo json_encode(["status" => "error", "message" => "Insufficient balance in developer's linked user account. Required: " . number_format($total_cost_usd, 2) . " USD. Current balance: " . number_format($payer_user_balance, 2) . " USD."]);
        exit();
    }

    // 4. Create/Validate Sudo Customer (for the target card owner)
    // This logic correctly uses an existing sudo_customer_id if available.
    if (empty($target_sudo_customer_id)) {
        // Prepare customer data for Sudo API call
        $customerData = [
            'type' => 'individual', 'status' => 'active', 'name' => $target_customer_first_name . ' ' . $target_customer_last_name,
            'phoneNumber' => $target_customer_phone, 'emailAddress' => $target_customer_email_db,
            'individual' => [
                'firstName' => $target_customer_first_name, 'lastName' => $target_customer_last_name,
                'dob' => $target_customer_dob ?? '2000-01-01T00:00:00.000Z', // Default DOB if not available
                'identity' => ['type' => 'NIN', 'number' => '12345678901'], // Placeholder NIN
                'documents' => [
                    'idFrontUrl' => $target_customer_id_front ? 'https://card.rovicc.com/kyc_documents/' . $target_customer_id_front : 'https://card.rovicc.com/kyc_documents/placeholder.jpg',
                    'idBackUrl' => $target_customer_id_back ? 'https://card.rovicc.com/kyc_documents/' . $target_customer_id_back : 'https://card.rovicc.com/kyc_documents/placeholder.jpg',
                ]
            ],
            'billingAddress' => [
                'line1' => '123 Main Street', 'city' => 'Lagos', 'state' => 'Lagos',
                'country' => 'NG', 'postalCode' => '100001'
            ]
        ];
        // Ensure that id_card_front/back URL for Sudo is correctly formed if it's a filename
        if (!filter_var($customerData['individual']['documents']['idFrontUrl'], FILTER_VALIDATE_URL)) {
             $customerData['individual']['documents']['idFrontUrl'] = 'https://card.rovicc.com/kyc_documents/' . $customerData['individual']['documents']['idFrontUrl'];
        }
        if (!filter_var($customerData['individual']['documents']['idBackUrl'], FILTER_VALIDATE_URL)) {
             $customerData['individual']['documents']['idBackUrl'] = 'https://card.rovicc.com/kyc_documents/' . $customerData['individual']['documents']['idBackUrl'];
        }

        $customerResponse = callSudoApi('POST', $sudo_base_url . 'customers', $sudo_api_key, $customerData);

        if (!isset($customerResponse['data']['_id'])) {
            $errorMsg = is_array($customerResponse['message']) ? json_encode($customerResponse['message']) : ($customerResponse['message'] ?? 'Unknown Error');
            error_log("Sudo Customer Creation Failed (from cards/create.php): " . $errorMsg);
            http_response_code(500); // Set status here as it's a critical Sudo error
            echo json_encode(["status" => "error", "message" => "Failed to provision customer profile with card provider."]);
            exit(); // Exit immediately after sending error response
        }
        $target_sudo_customer_id = $customerResponse['data']['_id'];
        
        // Update the Sudo customer ID in the respective database table (users or api_customers)
        if (!empty($card_owner_api_customer_id_for_tx)) {
            $pdo->prepare("UPDATE api_customers SET sudo_customer_id = ? WHERE id = ?")->execute([$target_sudo_customer_id, $card_owner_api_customer_id_for_tx]);
        } elseif (!empty($card_owner_user_id_for_tx)) {
            $pdo->prepare("UPDATE users SET sudo_customer_id = ? WHERE id = ?")->execute([$target_sudo_customer_id, $card_owner_user_id_for_tx]);
        }
    }


    // 5. Create Virtual Card via Sudo API
    $cardData = [
        'customerId' => $target_sudo_customer_id,
        'fundingSourceId' => $fundingSourceId,
        'debitAccountId' => $debitAccountId,
        'type' => 'virtual',
        'currency' => 'USD',
        'status' => 'active',
        'brand' => ucfirst(strtolower($card_brand)), // ## SECURITY FIX: Case-insensitive validation ##
        'issuerCountry' => 'USA',
        'amount' => $initial_funding_amount_usd, // Use requested funding amount
        'billingAddress' => [
            'line1' => '1007 N Orange St. 4th Floor', 'line2' => '', 'city' => 'Wilmington',
            'state' => 'Delaware', 'country' => 'US', 'postalCode' => '19801'
        ]
    ];
    $cardResponse = callSudoApi('POST', $sudo_base_url . 'cards', $sudo_api_key, $cardData);

    if (!isset($cardResponse['data']['_id'])) {
        $rawResponse = json_encode($cardResponse);
        $httpStatus = $cardResponse['statusCode'] ?? 'N/A';
        $errorMessage = $cardResponse['message'] ?? 'An unknown error occurred with the card provider.';
        if (is_array($errorMessage)) {
            $errorMessage = implode(', ', $errorMessage);
        }
        error_log("Sudo API Card Creation Failed: Status {$httpStatus}, Message: {$errorMessage}. Raw Response: {$rawResponse}");
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to create virtual card with the card provider. Please try again or contact support."]);
        exit();
    }
    $card = $cardResponse['data'];

    // 6. Database Transaction: Debit Authenticated Developer's User Balance, Insert Card, Log Transaction
    $pdo->beginTransaction();
    try {
        // Debit authenticated developer's linked user account balance
        $stmt_debit_balance = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?"); // Use payer_user id
        $stmt_debit_balance->execute([$total_cost_usd, $payer_user_id]);

        // Insert new card into virtual_cards table.
        // virtual_cards.user_id now stores the ID of the developer's linked Rovicc account (the payer).
        // virtual_cards.api_customer_id stores the ID of the API-created customer (the card owner, if applicable).
        $sql_insert_card = "INSERT INTO virtual_cards (user_id, api_customer_id, customer_id, card_id, account_id, business_id, funding_source_id, debit_account_id, card_type, brand, currency, status, issuer_country, maskedPan, last4, expiryMonth, expiryYear) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert_card = $pdo->prepare($sql_insert_card);
        $stmt_insert_card->execute([
            $payer_user_id,                 // User ID of the developer's linked Rovicc account (the payer)
            $card_owner_api_customer_id_for_tx, // API Customer ID (the card owner, can be NULL)
            $target_sudo_customer_id,
            $card['_id'], $card['account']['_id'] ?? null, $card['business'] ?? null,
            $fundingSourceId, $debitAccountId, 'virtual', $card['brand'], $card['currency'], $card['status'],
            $card['issuerCountry'], $card['maskedPan'] ?? null, $card['last4'] ?? null,
            $card['expiryMonth'] ?? null, $card['expiryYear'] ?? null
        ]);

        // Determine which ID to use for transaction logging (should be the card owner's ID for context)
        // If it's an API customer, use their ID. Otherwise, use the regular user ID.
        $transaction_owner_user_id = $card_owner_user_id_for_tx;
        $transaction_owner_api_customer_id = $card_owner_api_customer_id_for_tx;
        $transaction_description_email = $target_customer_email_db;

        // Log transaction (user_id and api_customer_id columns in transactions table reflect card owner for context)
        $tx_ref = "API-CARD-" . ($transaction_owner_user_id ?? $transaction_owner_api_customer_id) . "-" . time();
        $sql_log_tx = "INSERT INTO transactions (user_id, api_customer_id, tx_ref, amount_usd, amount_xaf, status, payment_gateway, type, description, gateway_response) VALUES (?, ?, ?, ?, ?, 'completed', 'Sudo API', 'card_creation', ?, ?)";
        $stmt_log_tx = $pdo->prepare($sql_log_tx);
        $stmt_log_tx->execute([
            $transaction_owner_user_id,    // Card owner (if regular user)
            $transaction_owner_api_customer_id, // Card owner (if API customer)
            $tx_ref, $total_cost_usd, $total_cost_xaf,
            "API Card Creation ({$card_brand}) for {$transaction_description_email} - Funded: $" . number_format($initial_funding_amount_usd, 2) . " (Paid by Dev User ID: {$payer_user_id})", // Enhanced description
            json_encode($cardResponse)
        ]);

        $pdo->commit();

        // Prepare success response
        http_response_code(201); // Created
        echo json_encode([
            "status" => "success",
            "message" => "Virtual card created successfully for " . $transaction_description_email . " (Paid by Dev User ID: " . $payer_user_id . ")",
            "data" => [
                "payer_user_id" => $payer_user_id, // Explicitly return the payer's user_id
                "card_owner_user_id" => $transaction_owner_user_id, // The actual Rovicc user ID of the card owner (can be null)
                "card_owner_api_customer_id" => $transaction_owner_api_customer_id, // The actual API customer ID of the card owner (can be null)
                "email" => $target_customer_email_db,
                "card_id" => $card['_id'],
                "brand" => $card['brand'],
                "masked_pan" => $card['maskedPan'] ?? null,
                "last_4_digits" => $card['last4'] ?? null,
                "expiry_month" => $card['expiryMonth'] ?? null,
                "expiry_year" => $card['expiryYear'] ?? null,
                "currency" => $card['currency'],
                "initial_funding" => $initial_funding_amount_usd,
                "total_cost_usd" => $total_cost_usd,
                "transaction_ref" => $tx_ref
            ]
        ]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("API Card Creation DB Transaction Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "An internal database error occurred during card creation. Please try again."]);
    }

} catch (Exception $e) {
    error_log("API Card Creation General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred during virtual card creation. Please try again."]);
}

exit();