<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Helper function to call the Sudo API (reused from other endpoints)
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => "error", "message" => "Only POST requests are allowed for this endpoint."]);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents("php://input"), true);

$card_id_to_fund = trim($input['card_id'] ?? '');
$amount_to_fund_usd = $input['amount_usd'] ?? null;

// Validate input
if (empty($card_id_to_fund)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing 'card_id' in request body."]);
    exit();
}
if (!is_numeric($amount_to_fund_usd) || (float)$amount_to_fund_usd <= 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or missing 'amount_usd'. Must be a positive number."]);
    exit();
}

$amount_to_fund_usd = (float)$amount_to_fund_usd;

// Authenticated Developer ID
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    // 1. Verify the card exists and belongs to a customer/user managed by this developer
    $stmt_card = $pdo->prepare("
        SELECT 
            vc.id AS virtual_card_db_id, 
            vc.user_id, 
            vc.api_customer_id, 
            vc.account_id, /* This is the Sudo account_id for the card */
            vc.brand, 
            vc.maskedPan,
            u.email AS user_email,
            ac.email AS api_customer_email,
            dev.id as developer_id,
            dev_user.id as developer_user_id,
            dev_user.balance as developer_balance
        FROM virtual_cards vc
        LEFT JOIN users u ON vc.user_id = u.id
        LEFT JOIN api_customers ac ON vc.api_customer_id = ac.id
        LEFT JOIN developers dev ON u.email = dev.email OR ac.developer_id = dev.id
        LEFT JOIN users dev_user ON dev.email = dev_user.email
        WHERE vc.card_id = ? AND dev.id = ?
    ");
    $stmt_card->execute([$card_id_to_fund, $authenticated_developer_id]);
    $card_info = $stmt_card->fetch(PDO::FETCH_ASSOC);

    if (!$card_info) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Card not found or not accessible by this developer."]);
        exit();
    }

    $sudo_account_id_to_fund = $card_info['account_id'];
    $target_user_id = $card_info['user_id'];
    $target_api_customer_id = $card_info['api_customer_id'];
    $card_masked_pan = $card_info['maskedPan'];
    $auth_dev_user_balance = (float)$card_info['developer_balance'];
    $developer_user_id = $card_info['developer_user_id'];


    // 2. Fetch API Settings
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'sudo_funding_source_id', 'usd_to_xaf_rate', 'card_funding_fixed_fee', 'card_funding_percentage_fee')");
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;
    $debitAccountId = $settings['sudo_account_id'] ?? null;
    $fundingSourceId = $settings['sudo_funding_source_id'] ?? null;
    $usd_to_xaf_rate = (float)($settings['usd_to_xaf_rate'] ?? 645);
    $funding_fixed_fee_usd = (float)($settings['card_funding_fixed_fee'] ?? 1.00);
    $funding_percentage_fee = (float)($settings['card_funding_percentage_fee'] ?? 1);

    if (empty($sudo_api_key) || empty($sudo_base_url) || empty($debitAccountId) || empty($fundingSourceId)) {
        http_response_code(500);
        error_log("API Card Funding Error: Sudo API configuration missing.");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred."]);
        exit();
    }

    // 3. Calculate total cost and check balance
    $percentage_fee_amount = $amount_to_fund_usd * ($funding_percentage_fee / 100);
    $total_cost_to_developer_usd = $amount_to_fund_usd + $funding_fixed_fee_usd + $percentage_fee_amount;

    if ($auth_dev_user_balance < $total_cost_to_developer_usd) {
        http_response_code(402);
        echo json_encode(["status" => "error", "message" => "Insufficient balance. Required: " . number_format($total_cost_to_developer_usd, 2) . " USD. Current balance: " . number_format($auth_dev_user_balance, 2) . " USD."]);
        exit();
    }
    
    // ## ROBUST TRANSACTION LOGIC STARTS HERE ##
    $tx_ref_db = "API-FUND-" . ($target_user_id ?? $target_api_customer_id) . "-" . time();
    $internal_tx_id = null;

    $pdo->beginTransaction();
    try {
        // Step 1: Debit the developer's balance first. Lock the row for update.
        $stmt_debit_balance = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?");
        $stmt_debit_balance->execute([$total_cost_to_developer_usd, $developer_user_id, $total_cost_to_developer_usd]);
        
        if ($stmt_debit_balance->rowCount() === 0) {
             throw new Exception("Failed to debit developer balance or insufficient funds during transaction.");
        }

        // Step 2: Log the transaction as 'pending'.
        $description = "API Card Funding for " . ($card_masked_pan ?? $card_id_to_fund) . " (Amount: $" . number_format($amount_to_fund_usd, 2) . ")";
        $sql_log_tx = "INSERT INTO transactions (user_id, api_customer_id, tx_ref, amount_usd, amount_xaf, status, payment_gateway, type, description) VALUES (?, ?, ?, ?, ?, 'pending', 'Sudo API', 'card_funding', ?)";
        $stmt_log_tx = $pdo->prepare($sql_log_tx);
        $stmt_log_tx->execute([
            $target_user_id,
            $target_api_customer_id,
            $tx_ref_db,
            $total_cost_to_developer_usd,
            $total_cost_to_developer_usd * $usd_to_xaf_rate,
            $description
        ]);
        $internal_tx_id = $pdo->lastInsertId();

        // Step 3: Commit the internal transaction. Our internal state is now consistent.
        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("API Card Funding DB Transaction Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "An internal database error occurred. The transaction has been safely rolled back."]);
        exit();
    }

    // Step 4: Now that the developer has been charged, attempt the external API call.
    $sudo_transfer_url = rtrim($sudo_base_url, '/') . '/accounts/transfer';
    $fund_payload = [
        'debitAccountId' => $debitAccountId,
        'amount' => $amount_to_fund_usd,
        'currency' => 'USD',
        'fundingSourceId' => $fundingSourceId,
        'narration' => "API Funding for card " . ($card_masked_pan ?? $card_id_to_fund),
        'paymentReference' => $tx_ref_db, // Use our internal ref for Sudo
        'creditAccountId' => $sudo_account_id_to_fund
    ];

    $sudo_response = callSudoApi('POST', $sudo_transfer_url, $sudo_api_key, $fund_payload);

    // Step 5: Update the transaction log with the outcome of the API call.
    $final_status = 'failed';
    if (isset($sudo_response['data']['_id']) || (isset($sudo_response['status']) && $sudo_response['status'] === 'success')) {
        $final_status = 'completed';
    }
    
    $stmt_update_tx = $pdo->prepare("UPDATE transactions SET status = ?, gateway_response = ? WHERE id = ?");
    $stmt_update_tx->execute([$final_status, json_encode($sudo_response), $internal_tx_id]);

    // Step 6: If the API call failed, we MUST refund the developer.
    if ($final_status === 'failed') {
        $pdo->beginTransaction();
        try {
            $stmt_refund = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt_refund->execute([$total_cost_to_developer_usd, $developer_user_id]);
            // Optionally, log the refund as a separate transaction for a clear audit trail.
            $pdo->commit();
        } catch(Exception $e) {
            $pdo->rollBack();
            // Critical error: The Sudo call failed AND the refund failed.
            // This requires manual intervention. Log this error very clearly.
            error_log("CRITICAL ERROR: Sudo call failed for tx_ref {$tx_ref_db} AND automatic refund to developer user ID {$developer_user_id} FAILED. MANUAL REFUND REQUIRED. Error: " . $e->getMessage());
        }
        
        $errorMessage = $sudo_response['message'] ?? 'Failed to process card funding with the provider.';
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => $errorMessage, "transaction_ref" => $tx_ref_db, "note" => "The charge has been reversed from your account."]);
        exit();
    }
    
    // Success: Respond to the user.
    http_response_code(200);
    echo json_encode([
        "status" => "success",
        "message" => "Virtual card funded successfully.",
        "data" => [
            "card_id" => $card_id_to_fund,
            "amount_funded_usd" => $amount_to_fund_usd,
            "total_cost_usd" => $total_cost_to_developer_usd,
            "transaction_ref" => $tx_ref_db,
            "sudo_transfer_id" => $sudo_response['data']['_id'] ?? 'N/A',
            "sudo_transfer_status" => $sudo_response['data']['status'] ?? 'N/A'
        ]
    ]);

} catch (Exception $e) {
    error_log("API Card Funding General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred during card funding."]);
}

exit();