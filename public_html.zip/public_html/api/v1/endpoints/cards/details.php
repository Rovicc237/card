<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Helper function to call the Sudo API (reused from other endpoints)
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => "error", "message" => "Only GET requests are allowed for this endpoint."]);
    exit();
}

// Get card_id from query parameter
$card_id = trim($_GET['card_id'] ?? '');

// Validate input
if (empty($card_id)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing 'card_id' query parameter."]);
    exit();
}

// Authenticated Developer ID
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    // 1. Verify the card exists and belongs to a customer/user managed by this developer
    $stmt_card = $pdo->prepare("
        SELECT 
            vc.id AS virtual_card_db_id,
            vc.user_id, 
            vc.api_customer_id, 
            vc.card_id, /* The Sudo card_id */
            vc.account_id, /* The Sudo account_id associated with the card */
            vc.brand, 
            vc.maskedPan,
            vc.last4,
            vc.expiryMonth,
            vc.expiryYear,
            vc.currency,
            vc.status,
            u.email AS user_email,
            ac.email AS api_customer_email
        FROM virtual_cards vc
        LEFT JOIN users u ON vc.user_id = u.id
        LEFT JOIN api_customers ac ON vc.api_customer_id = ac.id
        WHERE vc.card_id = ? 
        AND (
            u.email = (SELECT email FROM developers WHERE id = ?) OR
            ac.developer_id = ?
        )
    ");
    $stmt_card->execute([$card_id, $authenticated_developer_id, $authenticated_developer_id]);
    $card_info = $stmt_card->fetch(PDO::FETCH_ASSOC);

    if (!$card_info) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Card not found or not accessible."]);
        exit();
    }

    $rovicc_card_id = $card_info['card_id']; // This is the Sudo card ID
    $card_brand = $card_info['brand'];
    $card_masked_pan = $card_info['maskedPan'];


    // 2. Fetch API Settings (Sudo credentials, and Vault ID for secure display)
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings 
                                  WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_vault_id')"); // Added sudo_vault_id
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;
    $sudo_vault_id = $settings['sudo_vault_id'] ?? null; // Sudo Vault ID

    if (empty($sudo_api_key) || empty($sudo_base_url) || empty($sudo_vault_id)) {
        http_response_code(500);
        error_log("API Card Details Error: Card provider settings missing (API Key, Base URL, or Vault ID).");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred. Please contact support."]);
        exit();
    }
    
    // 3. Request a SECURE TOKEN for the card from Sudo API
    // This endpoint provides a temporary token to display sensitive details via SecureProxy/Hosted Fields
    $sudo_token_url = rtrim($sudo_base_url, '/') . '/cards/' . $rovicc_card_id . '/token';
    
    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Attempting Card Provider Token API Call. URL: {$sudo_token_url}");
    // --- ENHANCED LOGGING END ---

    $token_response = callSudoApi('GET', $sudo_token_url, $sudo_api_key);

    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Card Provider Token API Raw Response: " . json_encode($token_response));
    // --- ENHANCED LOGGING END ---

    if (isset($token_response['data']['token'])) {
        $secure_display_token = $token_response['data']['token'];

        http_response_code(200); // OK
        echo json_encode([
            "status" => "success",
            "message" => "Secure display token retrieved successfully.",
            "data" => [
                "card_id" => $rovicc_card_id,
                "masked_pan" => $card_info['maskedPan'],
                "brand" => $card_info['brand'],
                "expiry_month" => $card_info['expiryMonth'],
                "expiry_year" => $card_info['expiryYear'],
                "currency" => $card_info['currency'],
                "status" => $card_info['status'],
                "secure_display_token" => $secure_display_token, // The token for Sudo Hosted Fields
                "provider_vault_id" => $sudo_vault_id // The Vault ID needed to initialize Sudo Hosted Fields
            ],
            "security_note" => "Full PAN/CVV are displayed via SecureProxy/Hosted Fields using the token. They are NOT directly returned in this API response for security compliance."
        ]);
    } else {
        $rawResponse = json_encode($token_response);
        $httpStatus = $token_response['statusCode'] ?? 'N/A';
        $errorMessage = $token_response['message'] ?? 'An unknown error occurred while fetching secure display token.';
        if (is_array($errorMessage)) {
            $errorMessage = implode(', ', $errorMessage);
        }
        error_log("Card Provider Token Failed: Status {$httpStatus}. Message: {$errorMessage}. Response: {$rawResponse}");
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to retrieve secure card details from the provider. Please try again or contact support."]);
    }

} catch (Exception $e) {
    error_log("API Card Details General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred while retrieving secure card details. Please try again."]);
}

exit();