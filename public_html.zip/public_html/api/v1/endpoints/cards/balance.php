<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

// Helper function to call the Sudo API (reused from other endpoints)
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return ['error' => "cURL Error #: " . $err];
        }
        return json_decode($response, true);
    }
}

// Ensure it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => "error", "message" => "Only GET requests are allowed for this endpoint."]);
    exit();
}

// Get card_id from query parameter
$card_id = trim($_GET['card_id'] ?? '');

// Validate input
if (empty($card_id)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing 'card_id' query parameter."]);
    exit();
}

// Authenticated Developer ID
$authenticated_developer_id = $_REQUEST['authenticated_developer_id'];

try {
    // 1. Verify the card exists and belongs to a customer/user managed by this developer
    $stmt_card = $pdo->prepare("
        SELECT 
            vc.account_id, /* This is the Sudo account_id */
            vc.brand, 
            vc.maskedPan,
            u.email AS user_email,
            ac.email AS api_customer_email
        FROM virtual_cards vc
        LEFT JOIN users u ON vc.user_id = u.id
        LEFT JOIN api_customers ac ON vc.api_customer_id = ac.id
        WHERE vc.card_id = ? 
        AND (
            u.email = (SELECT email FROM developers WHERE id = ?) OR
            ac.developer_id = ?
        )
    ");
    $stmt_card->execute([$card_id, $authenticated_developer_id, $authenticated_developer_id]);
    $card_info = $stmt_card->fetch(PDO::FETCH_ASSOC);

    if (!$card_info) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Card not found or not accessible."]);
        exit();
    }

    $sudo_account_id = $card_info['account_id'];
    $card_brand = $card_info['brand'];
    $card_masked_pan = $card_info['maskedPan'];
    $target_customer_email = $card_info['user_email'] ?? $card_info['api_customer_email'];


    // 2. Fetch API Settings (Sudo credentials)
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings 
                                  WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $settings['sudo_api_key'] ?? null;
    $sudo_base_url = $settings['sudo_base_url'] ?? null;

    if (empty($sudo_api_key) || empty($sudo_base_url)) {
        http_response_code(500);
        error_log("API Card Balance Error: Sudo API settings missing (API key or base URL).");
        echo json_encode(["status" => "error", "message" => "An internal server configuration error occurred. Please contact support."]);
        exit();
    }
    
    // 3. Fetch balance from Sudo API
    // Sudo API endpoint for balance: /accounts/{accountId}/balance
    $sudo_balance_url = rtrim($sudo_base_url, '/') . '/accounts/' . $sudo_account_id . '/balance';
    
    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Attempting Sudo Balance API Call. URL: {$sudo_balance_url}");
    // --- ENHANCED LOGGING END ---

    $balance_response = callSudoApi('GET', $sudo_balance_url, $sudo_api_key);

    // --- ENHANCED LOGGING START ---
    error_log("DEBUG: Sudo Balance API Raw Response: " . json_encode($balance_response));
    // --- ENHANCED LOGGING END ---

    if (isset($balance_response['data']['currentBalance'])) {
        http_response_code(200); // OK
        echo json_encode([
            "status" => "success",
            "message" => "Card balance retrieved successfully.",
            "data" => [
                "card_id" => $card_id,
                "account_id" => $sudo_account_id,
                "brand" => $card_brand,
                "masked_pan" => $card_masked_pan,
                "current_balance_usd" => (float)$balance_response['data']['currentBalance'],
                "available_balance_usd" => (float)$balance_response['data']['availableBalance'] // Sudo also provides availableBalance
            ]
        ]);
    } else {
        $rawResponse = json_encode($balance_response);
        $httpStatus = $balance_response['statusCode'] ?? 'N/A';
        $errorMessage = $balance_response['message'] ?? 'An unknown error occurred while fetching card balance.';
        if (is_array($errorMessage)) {
            $errorMessage = implode(', ', $errorMessage);
        }
        error_log("Sudo API Card Balance Failed: Status {$httpStatus}. Message: {$errorMessage}. Response: {$rawResponse}");
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Failed to retrieve card balance from the provider. Please try again."]);
    }

} catch (Exception $e) {
    error_log("API Card Balance General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An unexpected error occurred while retrieving card balance. Please try again."]);
}

exit();