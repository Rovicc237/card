<?php
// This endpoint is included by public_html/api/index.php
// $pdo is available from db.php
// $authenticated_developer_id is available from middleware/auth.php

$developer_id = $_REQUEST['authenticated_developer_id'];

try {
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, email, company_name, website_url, created_at FROM developers WHERE id = ?");
    $stmt->execute([$developer_id]);
    $developer_info = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($developer_info) {
        // Remove sensitive information before sending
        unset($developer_info['password']); // Just in case it was accidentally fetched
        http_response_code(200);
        echo json_encode([
            "status" => "success",
            "message" => "Developer information retrieved successfully.",
            "data" => $developer_info
        ]);
    } else {
        http_response_code(404);
        // Log the detailed error for debugging, but provide a generic message to the client.
        error_log("API Error (developer_info): Authenticated developer not found for ID: " . $developer_id);
        echo json_encode(["status" => "error", "message" => "Developer information could not be retrieved."]);
    }
} catch (PDOException $e) {
    error_log("API Error (developer_info): " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "An internal server error occurred. Please try again later."]);
}
?>