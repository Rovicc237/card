<?php
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

$stmt = $pdo->prepare("
    SELECT mw.*, u.first_name, u.last_name, u.email 
    FROM manual_withdrawals mw
    JOIN users u ON mw.user_id = u.id
    WHERE mw.status = 'pending'
    ORDER BY mw.requested_at ASC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Manual Withdrawal Requests</h1>
            <p>Review and process pending withdrawal requests.</p>
        </div>
    </header>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?>"><?= htmlspecialchars($_SESSION['message']) ?></div>
        <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
    <?php endif; ?>

    <section class="users-table-section">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Amount (USD)</th>
                        <th>Mobile Money Number</th>
                        <th>Date Requested</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr><td colspan="5" style="text-align: center;">No pending withdrawal requests.</td></tr>
                    <?php else: ?>
                        <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?></td>
                            <td>$<?= number_format($request['amount'], 2) ?></td>
                            <td><?= htmlspecialchars($request['mobile_money_number']) ?></td>
                            <td><?= date("M j, Y, g:i a", strtotime($request['requested_at'])) ?></td>
                            <td style="text-align: center;">
                                <form action="processors/process_manual_withdrawal.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                    <button type="submit" name="action" value="approve" class="btn-action btn-view" style="background-color: #10b981;">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn-action btn-impersonate" style="background-color: #ef4444;">Reject</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/templates/footer.php'; ?>