document.addEventListener('DOMContentLoaded', function () {
    const emailForm = document.getElementById('email-form');
    const sendButton = document.getElementById('send-button');
    const progressContainer = document.getElementById('progress-container');
    const progressBarFill = document.getElementById('progress-bar-fill');
    const progressText = document.getElementById('progress-text');
    const statusLog = document.getElementById('status-log');

    // Logic for specific user search... (remains the same)
    const recipientTypeRadios = document.querySelectorAll('input[name="recipient_type"]');
    const specificUserContainer = document.getElementById('specific-user-container');
    const searchInput = document.getElementById('recipient-search');
    const searchResults = document.getElementById('search-results');
    const hiddenEmailInput = document.getElementById('recipient-email');
    const selectedDisplay = document.getElementById('selected-recipient-display');
    let searchTimeout;

    recipientTypeRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            specificUserContainer.style.display = this.value === 'specific' ? 'block' : 'none';
        });
    });

    searchInput.addEventListener('keyup', function () {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            if (this.value.trim().length < 2) {
                searchResults.style.display = 'none';
                return;
            }
            fetch(`search_users.php?term=${encodeURIComponent(this.value)}`)
                .then(response => response.json())
                .then(data => displayResults(data));
        }, 300);
    });

    function displayResults(users) {
        searchResults.innerHTML = '';
        if (users.length === 0) {
            searchResults.innerHTML = '<div class="no-results">No users found.</div>';
        } else {
            users.forEach(user => {
                const item = document.createElement('div');
                item.className = 'result-item';
                item.innerHTML = `<span class="result-name">${user.first_name} ${user.last_name}</span><span class="result-email">${user.email}</span>`;
                item.onclick = () => selectUser(user);
                searchResults.appendChild(item);
            });
        }
        searchResults.style.display = 'block';
    }

    window.selectUser = function (user) {
        hiddenEmailInput.value = user.email;
        selectedDisplay.innerHTML = `<span>${user.first_name} ${user.last_name}</span> <button type="button" onclick="clearSelection()">×</button>`;
        selectedDisplay.style.display = 'flex';
        searchResults.style.display = 'none';
    }

    window.clearSelection = function () {
        hiddenEmailInput.value = '';
        selectedDisplay.style.display = 'none';
        searchInput.value = '';
    }

    // --- FORM SUBMISSION LOGIC (UPDATED) ---
    emailForm.addEventListener('submit', function (e) {
        e.preventDefault();
        sendButton.disabled = true;
        sendButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Queuing Emails...';

        fetch('email.php', {
            method: 'POST',
            body: new FormData(emailForm)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.jobs && data.jobs.length > 0) {
                    document.getElementById('form-container').style.display = 'none';
                    progressContainer.style.display = 'block';
                    processQueue(data.jobs);
                } else {
                    alert('Error: ' + data.message);
                    sendButton.disabled = false;
                    sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Message';
                }
            });
    });

    function processQueue(jobs) {
        let sentCount = 0;
        const totalJobs = jobs.length;
        statusLog.innerHTML = '';

        async function processJob(jobId) {
            const formData = new FormData();
            formData.append('job_id', jobId);

            try {
                const response = await fetch('email_processor.php', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) {
                    throw new Error(`Server responded with status: ${response.status}`);
                }

                return await response.json();
            } catch (error) {
                console.error('Fetch Error:', error);
                return { success: false, message: `A critical network error occurred: ${error.message}` };
            }
        }

        async function run() {
            for (let i = 0; i < totalJobs; i++) {
                const result = await processJob(jobs[i]);
                sentCount++;
                updateProgress(sentCount, totalJobs, result.message, result.success);

                if (i < totalJobs - 1) {
                    await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
                }
            }
            sendButton.innerHTML = '<i class="fa-solid fa-check"></i> All Emails Processed!';
            progressText.textContent = '100%';
        }

        function updateProgress(count, total, message, isSuccess) {
            const percentage = Math.round((count / total) * 100);
            progressBarFill.style.width = percentage + '%';
            progressText.textContent = percentage + '%';

            const logEntry = document.createElement('div');
            logEntry.className = isSuccess ? 'log-success' : 'log-error';
            logEntry.textContent = `(${count}/${total}) ${message}`;
            statusLog.appendChild(logEntry);
            statusLog.scrollTop = statusLog.scrollHeight;
        }

        run();
    }
});