document.addEventListener('DOMContentLoaded', function () {
    const mobileToggle = document.getElementById('mobile-toggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');

    if (mobileToggle && sidebar) {
        // Toggle sidebar with button
        mobileToggle.addEventListener('click', function (event) {
            event.stopPropagation();
            sidebar.classList.toggle('active');
        });
    }

    // Close sidebar when clicking on the main content area
    if (mainContent && sidebar) {
        mainContent.addEventListener('click', function () {
            if (sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });
    }

    // --- NEW: Actions Dropdown Menu Logic ---
    document.querySelectorAll('.actions-menu-toggle').forEach(button => {
        button.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent the window click event from firing immediately

            // Close all other open menus
            document.querySelectorAll('.actions-menu').forEach(menu => {
                if (menu !== this.nextElementSibling) {
                    menu.style.display = 'none';
                    menu.previousElementSibling.classList.remove('active');
                }
            });

            // Toggle the current menu
            const menu = this.nextElementSibling;
            const is_active = menu.style.display === 'block';
            menu.style.display = is_active ? 'none' : 'block';
            this.classList.toggle('active', !is_active);
        });
    });

    // Close dropdowns if the user clicks outside of them
    window.addEventListener('click', function (event) {
        document.querySelectorAll('.actions-menu').forEach(menu => {
            menu.style.display = 'none';
            menu.previousElementSibling.classList.remove('active');
        });
    });
});