<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

function save_setting($pdo, $key, $value) {
    $sql = "INSERT INTO api_settings (setting_key, setting_value) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$key, $value]);
}

try {
    $pdo->beginTransaction();

    // Whitelist of all settings this script can update
    $allowed_keys = [
        'usd_to_xaf_rate', 'flutterwave_api_url', 'flutterwave_secret_key',
        'sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'sudo_vault_id',
        'sudo_funding_source_id', // --- [NEW] Added the new key to the whitelist ---
        'visa_creation_fee', 'visa_initial_funding', 
        'mastercard_creation_fee', 'mastercard_initial_funding',
        'card_funding_fixed_fee', 'card_funding_percentage_fee'
    ];

    foreach ($_POST as $key => $value) {
        if (in_array($key, $allowed_keys)) {
            // Skip updating password/key fields if they are submitted empty
            if (in_array($key, ['flutterwave_secret_key', 'sudo_api_key']) && empty(trim($value))) {
                continue;
            }
            
            $sanitized_value = trim($value);

            // Add specific validation for numeric and URL fields
            if (in_array($key, ['sudo_base_url', 'flutterwave_api_url'])) {
                if (!filter_var($sanitized_value, FILTER_VALIDATE_URL)) {
                    throw new Exception("The API URL for {$key} is not a valid URL.");
                }
            } elseif (in_array($key, [
                'usd_to_xaf_rate', 
                'visa_creation_fee', 'visa_initial_funding', 
                'mastercard_creation_fee', 'mastercard_initial_funding',
                'card_funding_fixed_fee', 'card_funding_percentage_fee',
                'referral_bonus_card_creation', 'referral_bonus_card_funding'
            ])) {
                if (!is_numeric($sanitized_value) || $sanitized_value < 0) {
                    throw new Exception("The value for {$key} must be a valid, non-negative number.");
                }
            }
            
            save_setting($pdo, $key, $sanitized_value);
        }
    }

    $pdo->commit();
    $_SESSION['message'] = "API, Rate, and Pricing settings updated successfully.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $_SESSION['message'] = "An error occurred: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("API/Pricing Settings Update Error: " . $e->getMessage());
}

header("Location: ../settings.php");
exit();
?>