<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

try {
    $notification_email = filter_input(INPUT_POST, 'notification_email', FILTER_VALIDATE_EMAIL);
    if (!$notification_email) {
        throw new Exception("Invalid email format provided for notifications.");
    }
    
    $sql = "INSERT INTO api_settings (setting_key, setting_value) VALUES ('notification_email', ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$notification_email]);
    
    $_SESSION['message'] = "General settings updated successfully.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    $_SESSION['message'] = "Error: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("General Settings Update Error: " . $e->getMessage());
}

header("Location: ../settings.php");
exit();
?>