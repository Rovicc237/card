<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// Correctly include PHPMailer library and the centralized SMTP configuration
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../config/smtp_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

$request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
$action = $_POST['action'] ?? '';
$admin_id = $_SESSION['admin_id'];

if (!$request_id || !in_array($action, ['approve', 'reject'])) {
    $_SESSION['message'] = "Invalid request.";
    $_SESSION['message_type'] = 'danger';
    header("Location: ../manual_withdrawals.php");
    exit();
}

try {
    $pdo->beginTransaction();

    $stmt_req = $pdo->prepare("SELECT * FROM manual_withdrawals WHERE id = ? AND status = 'pending' FOR UPDATE");
    $stmt_req->execute([$request_id]);
    $request = $stmt_req->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        throw new Exception("Withdrawal request not found or already processed.");
    }

    $stmt_user = $pdo->prepare("SELECT email, first_name FROM users WHERE id = ?");
    $stmt_user->execute([$request['user_id']]);
    $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if ($action === 'approve') {
        $stmt_update = $pdo->prepare("UPDATE manual_withdrawals SET status = 'approved', processed_at = NOW(), admin_id = ? WHERE id = ?");
        $stmt_update->execute([$admin_id, $request_id]);
        $_SESSION['message'] = "Withdrawal request #" . $request_id . " has been approved.";
        $_SESSION['message_type'] = 'success';
        
        // Send approval email
        $mail = get_mailer();
        $mail->addAddress($user['email'], $user['first_name']);
        $mail->Subject = 'Your Withdrawal Request has been Approved';
        $body = file_get_contents(__DIR__ . '/../../user/email_templates/withdrawal_approved.html');
        $body = str_replace('{{user_name}}', $user['first_name'], $body);
        $body = str_replace('{{amount}}', number_format($request['amount'], 2), $body);
        $mail->Body = $body;
        $mail->send();

    } elseif ($action === 'reject') {
        // Refund the amount to the user's balance
        $stmt_refund = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt_refund->execute([$request['amount'], $request['user_id']]);

        $stmt_update = $pdo->prepare("UPDATE manual_withdrawals SET status = 'rejected', processed_at = NOW(), admin_id = ? WHERE id = ?");
        $stmt_update->execute([$admin_id, $request_id]);
        $_SESSION['message'] = "Withdrawal request #" . $request_id . " has been rejected and the amount refunded to the user.";
        $_SESSION['message_type'] = 'success';

        // Send rejection email
        $mail = get_mailer();
        $mail->addAddress($user['email'], $user['first_name']);
        $mail->Subject = 'Your Withdrawal Request was Rejected';
        $body = file_get_contents(__DIR__ . '/../../user/email_templates/withdrawal_rejected.html');
        $body = str_replace('{{user_name}}', $user['first_name'], $body);
        $body = str_replace('{{amount}}', number_format($request['amount'], 2), $body);
        $mail->Body = $body;
        $mail->send();
    }
    
    $pdo->commit();

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $_SESSION['message'] = "An error occurred: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("Process manual withdrawal error: " . $e->getMessage());
}

header("Location: ../manual_withdrawals.php");
exit();