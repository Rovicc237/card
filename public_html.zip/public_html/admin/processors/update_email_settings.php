<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

function save_setting($pdo, $key, $value) {
    $sql = "INSERT INTO api_settings (setting_key, setting_value) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$key, $value]);
}

try {
    $pdo->beginTransaction();

    $settings_to_update = [
        'smtp_from_email' => filter_input(INPUT_POST, 'smtp_from_email', FILTER_VALIDATE_EMAIL),
        'smtp_from_name' => trim(filter_input(INPUT_POST, 'smtp_from_name', FILTER_SANITIZE_STRING)),
        'smtp_host' => trim(filter_input(INPUT_POST, 'smtp_host', FILTER_SANITIZE_STRING)),
        'smtp_port' => filter_input(INPUT_POST, 'smtp_port', FILTER_VALIDATE_INT),
        'smtp_encryption' => in_array($_POST['smtp_encryption'], ['tls', 'ssl', 'none']) ? $_POST['smtp_encryption'] : 'tls',
        'smtp_username' => trim(filter_input(INPUT_POST, 'smtp_username', FILTER_SANITIZE_STRING))
    ];

    foreach ($settings_to_update as $key => $value) {
        if ($value === false || $value === null) {
            throw new Exception("Invalid data submitted for {$key}.");
        }
        save_setting($pdo, $key, $value);
    }
    
    // Only update password if a new one is provided
    if (!empty(trim($_POST['smtp_password']))) {
        save_setting($pdo, 'smtp_password', trim($_POST['smtp_password']));
    }

    $pdo->commit();
    $_SESSION['message'] = "SMTP email settings have been updated successfully.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $_SESSION['message'] = "Error: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("SMTP Settings Update Error: " . $e->getMessage());
}

header("Location: ../settings.php");
exit();
?>