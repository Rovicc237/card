<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

function save_setting($pdo, $key, $value) {
    $sql = "INSERT INTO api_settings (setting_key, setting_value) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$key, $value]);
}

try {
    $pdo->beginTransaction();

    $settings_to_update = [
        'referral_bonus_card_creation' => filter_input(INPUT_POST, 'referral_bonus_card_creation', FILTER_VALIDATE_FLOAT),
        'referral_bonus_card_funding' => filter_input(INPUT_POST, 'referral_bonus_card_funding', FILTER_VALIDATE_FLOAT)
    ];

    foreach ($settings_to_update as $key => $value) {
        if ($value === false || $value < 0) {
            throw new Exception("Invalid data submitted for {$key}. Please enter a valid, non-negative number.");
        }
        save_setting($pdo, $key, $value);
    }

    $pdo->commit();
    $_SESSION['message'] = "Referral bonus settings have been updated successfully.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $_SESSION['message'] = "Error: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("Referral Settings Update Error: " . $e->getMessage());
}

header("Location: ../referral_settings.php");
exit();
?>