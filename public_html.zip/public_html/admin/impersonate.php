<?php
// public_html/admin/impersonate.php

session_start();
require_once __DIR__ . '/../../database/db.php';

// 1. Security Check: Ensure an admin is logged in and not already impersonating
if (!isset($_SESSION['admin_id']) || isset($_SESSION['original_admin_id'])) {
    header("Location: index.php");
    exit();
}

// 2. Get User ID from URL and validate
$user_id_to_impersonate = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
if (!$user_id_to_impersonate) {
    // Redirect back with an error if user_id is invalid or missing
    $_SESSION['message'] = "Invalid user ID provided for impersonation.";
    $_SESSION['message_type'] = 'danger';
    header("Location: dashboard.php");
    exit();
}

try {
    // 3. Fetch the user's data from the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND is_verified = 1");
    $stmt->execute([$user_id_to_impersonate]);
    $user = $stmt->fetch();

    if ($user) {
        // 4. Store original admin session details
        $_SESSION['original_admin_id'] = $_SESSION['admin_id'];
        $_SESSION['original_admin_username'] = $_SESSION['admin_username'];

        // 5. Unset current admin session variables
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_username']);

        // 6. Set the new session to the user's details
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['first_name'] = $user['first_name'];
        $_SESSION['last_name'] = $user['last_name'];
        $_SESSION['email'] = $user['email'];

        // 7. Redirect to the user's dashboard
        header("Location: ../user/dashboard.php");
        exit();
    } else {
        // User not found or not verified, redirect with error
        $_SESSION['message'] = "Could not find a verifiable user with that ID.";
        $_SESSION['message_type'] = 'danger';
        header("Location: dashboard.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Impersonation Error: " . $e->getMessage());
    $_SESSION['message'] = "A database error occurred during the impersonation attempt.";
    $_SESSION['message_type'] = 'danger';
    header("Location: dashboard.php");
    exit();
}