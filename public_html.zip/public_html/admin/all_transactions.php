<?php
// public_html/admin/all_transactions.php

// Page-specific variables
$page_title = 'All Transactions - Rovicc Admin';
$page_css = ['all-transactions.css']; // Using a new CSS file for styling

// Include main header and database connection
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Initialize message variables
$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

// --- Pagination Logic ---
$limit = 20; // Number of transactions per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// --- Fetch All Transactions ---
$transactions = [];
$total_transactions = 0;
$db_error = '';

try {
    // Count total transactions for pagination
    $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM transactions");
    $stmt_count->execute();
    $total_transactions = $stmt_count->fetchColumn();

    // Fetch transactions with user details
    $stmt_transactions = $pdo->prepare("
        SELECT 
            t.id, 
            t.tx_ref, 
            t.amount_usd, 
            t.amount_xaf, 
            t.status, 
            t.type,
            t.created_at,
            u.id AS user_id,
            u.first_name, 
            u.last_name, 
            u.email
        FROM 
            transactions t
        JOIN 
            users u ON t.user_id = u.id
        ORDER BY 
            t.created_at DESC
        LIMIT :limit OFFSET :offset
    ");
    $stmt_transactions->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt_transactions->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt_transactions->execute();
    $transactions = $stmt_transactions->fetchAll();

    $total_pages = ceil($total_transactions / $limit);

} catch (PDOException $e) {
    $db_error = "Database error: Could not load transactions. " . $e->getMessage();
    error_log("Admin All Transactions DB Error: " . $e->getMessage());
}

// Include the sidebar
require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>All Transactions</h1>
            <p>A complete log of all financial activities on the platform.</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle Menu">
            <i class="fa-solid fa-bars"></i>
        </button>
    </header>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($db_error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($db_error) ?></div>
    <?php else: ?>
        <section class="transactions-table-section">
            <h2>Transaction Log (<?= $total_transactions ?>)</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>User</th>
                            <th>Amount (USD)</th>
                            <th>Amount (XAF)</th>
                            <th>Date</th>
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transactions)): ?>
                            <tr><td colspan="8" style="text-align: center;">No transactions found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td><?= htmlspecialchars($transaction['tx_ref']) ?></td>
                                    <td>
                                        <span class="type-badge type-<?= strtolower(htmlspecialchars(str_replace('_', '-', $transaction['type']))) ?>">
                                            <?= htmlspecialchars(ucwords(str_replace('_', ' ', $transaction['type']))) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                            $status_class = 'status-default';
                                            if (in_array($transaction['status'], ['completed', 'successful'])) $status_class = 'status-completed';
                                            if ($transaction['status'] === 'pending') $status_class = 'status-pending';
                                            if ($transaction['status'] === 'failed') $status_class = 'status-failed';
                                        ?>
                                        <span class="status-badge <?= $status_class ?>">
                                            <?= htmlspecialchars(ucfirst($transaction['status'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_user.php?id=<?= $transaction['user_id'] ?>" class="user-link">
                                            <?= htmlspecialchars($transaction['first_name'] . ' ' . $transaction['last_name']) ?>
                                        </a>
                                    </td>
                                    <td>$<?= number_format($transaction['amount_usd'], 2) ?></td>
                                    <td><?= number_format($transaction['amount_xaf'], 2) ?> XAF</td>
                                    <td><?= date("M j, Y, g:i a", strtotime($transaction['created_at'])) ?></td>
                                    <td style="text-align: center;">
                                        <a href="view_user.php?id=<?= $transaction['user_id'] ?>" class="btn-action btn-view"><i class="fa-solid fa-eye"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($total_pages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?= $i ?>" class="<?= ($page == $i) ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</main>

<?php
// Include the main footer
require_once __DIR__ . '/templates/footer.php';
?>