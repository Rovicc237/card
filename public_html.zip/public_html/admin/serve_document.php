<?php
// public_html/admin/serve_document.php

session_start();

// Security: Only logged-in admins can access this script.
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    die('Forbidden: You do not have permission to access this file.');
}

require_once __DIR__ . '/../../database/db.php';

// Get the requested file path from the URL
$file_path = filter_input(INPUT_GET, 'file', FILTER_SANITIZE_STRING);

if (empty($file_path)) {
    http_response_code(400);
    die('Bad Request: No file specified.');
}

// Security: Prevent directory traversal attacks.
// This ensures the path doesn't contain '..' to navigate up the directory tree.
if (strpos($file_path, '..') !== false) {
    http_response_code(400);
    die('Bad Request: Invalid file path.');
}

// Construct the full, absolute path to the document
// The base directory is two levels up from the current script's directory.
$document_root = dirname(__DIR__, 2) . '/kyc_documents/';
$full_path = $document_root . $file_path;

// Check if the file exists and is readable
if (file_exists($full_path) && is_readable($full_path)) {
    // Determine the MIME type of the file to serve it correctly
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $finfo->file($full_path);

    // Set the appropriate content type header
    header('Content-Type: ' . $mime_type);
    
    // Set headers to display the file inline in the browser
    header('Content-Disposition: inline; filename="' . basename($full_path) . '"');
    
    // Output the file content
    readfile($full_path);
    exit;
} else {
    // File not found or not readable
    http_response_code(404);
    die('Not Found: The requested file could not be located.');
}