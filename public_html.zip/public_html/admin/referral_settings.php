<?php
// Page-specific variables
$page_title = 'Referral Settings - Rovicc Admin';
$page_css = ['email-form-professional.css']; // Reusing some styles

require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

// Fetch current referral settings for display
try {
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key LIKE 'referral_bonus_%'");
    $referral_settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    $card_creation_bonus = $referral_settings['referral_bonus_card_creation'] ?? '500';
    $card_funding_bonus = $referral_settings['referral_bonus_card_funding'] ?? '20';

} catch (PDOException $e) {
    $message = "Database error: Could not fetch referral settings.";
    $message_type = "danger";
    error_log("Referral Settings page DB error: " . $e->getMessage());
}

require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Referral Commission Settings</h1>
            <p>Set the commission amounts for user referrals.</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle"><i class="fa-solid fa-bars"></i></button>
    </header>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>" style="margin-bottom: 20px;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <section class="settings-section" style="max-width: 900px;">
        <div class="email-composer-card">
            <h2>Referral Bonuses</h2>
            <p>Set the referral bonus amounts in XAF that a referrer earns when their referred user performs an action.</p>
            <form action="processors/update_referral_settings.php" method="POST">
                <div class="form-group">
                    <label for="referral_bonus_card_creation">Bonus for Card Creation (XAF)</label>
                    <input type="number" id="referral_bonus_card_creation" name="referral_bonus_card_creation" value="<?= htmlspecialchars($card_creation_bonus) ?>" required>
                </div>
                <div class="form-group">
                    <label for="referral_bonus_card_funding">Bonus for Card Funding (%)</label>
                    <input type="number" id="referral_bonus_card_funding" name="referral_bonus_card_funding" value="<?= htmlspecialchars($card_funding_bonus) ?>" step="0.01" required>
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-gift"></i> Update Referral Bonuses</button>
            </form>
        </div>
    </section>
</main>
<?php
require_once __DIR__ . '/templates/footer.php';
?>