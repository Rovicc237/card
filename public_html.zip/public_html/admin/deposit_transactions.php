<?php
// public_html/admin/deposit_transactions.php

// Page-specific variables
$page_title = 'Deposit Transactions - Rovicc Admin';
$page_css = ['all-transactions.css']; // Reusing the new CSS for consistent styling

// Include main header and database connection
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Initialize message variables
$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

// --- Pagination Logic ---
$limit = 15; // Number of transactions per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// --- Fetch Deposit Transactions ---
$transactions = [];
$total_transactions = 0;
$db_error = '';

try {
    // Count total deposit transactions for pagination
    $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE type = 'deposit'");
    $stmt_count->execute();
    $total_transactions = $stmt_count->fetchColumn();

    // Fetch deposit transactions with user details
    $stmt_transactions = $pdo->prepare("
        SELECT 
            t.id, 
            t.tx_ref, 
            t.amount_usd, 
            t.amount_xaf, 
            t.status, 
            t.created_at,
            u.id AS user_id,
            u.first_name, 
            u.last_name, 
            u.email
        FROM 
            transactions t
        JOIN 
            users u ON t.user_id = u.id
        WHERE 
            t.type = 'deposit'
        ORDER BY 
            t.created_at DESC
        LIMIT :limit OFFSET :offset
    ");
    $stmt_transactions->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt_transactions->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt_transactions->execute();
    $transactions = $stmt_transactions->fetchAll();

    $total_pages = ceil($total_transactions / $limit);

} catch (PDOException $e) {
    $db_error = "Database error: Could not load transactions. " . $e->getMessage();
    error_log("Admin Deposit Transactions DB Error: " . $e->getMessage());
}

// Include the sidebar
require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Deposit Transactions</h1>
            <p>View all user deposit transactions and their details.</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle Menu">
            <i class="fa-solid fa-bars"></i>
        </button>
    </header>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($db_error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($db_error) ?></div>
    <?php else: ?>
        <section class="transactions-table-section">
            <h2>All Deposits (<?= $total_transactions ?>)</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Status</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Amount (USD)</th>
                            <th>Amount (XAF)</th>
                            <th>Date</th>
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transactions)): ?>
                            <tr><td colspan="8" style="text-align: center;">No deposit transactions found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td><?= htmlspecialchars($transaction['tx_ref']) ?></td>
                                    <td>
                                        <?php
                                            $status_class = 'status-default';
                                            if (in_array($transaction['status'], ['completed', 'successful', 'payment_successful'])) $status_class = 'status-completed';
                                            if ($transaction['status'] === 'pending') $status_class = 'status-pending';
                                            if ($transaction['status'] === 'failed') $status_class = 'status-failed';
                                        ?>
                                        <span class="status-badge <?= $status_class ?>">
                                            <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $transaction['status']))) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_user.php?id=<?= $transaction['user_id'] ?>" class="user-link">
                                            <?= htmlspecialchars($transaction['first_name'] . ' ' . $transaction['last_name']) ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['email']) ?></td>
                                    <td>$<?= number_format($transaction['amount_usd'], 2) ?></td>
                                    <td><?= number_format($transaction['amount_xaf'], 2) ?> XAF</td>
                                    <td><?= date("M j, Y, g:i a", strtotime($transaction['created_at'])) ?></td>
                                    <td style="text-align: center;">
                                        <div class="actions-menu-container">
                                            <button class="actions-menu-toggle">
                                                Actions <i class="fa-solid fa-caret-down"></i>
                                            </button>
                                            <div class="actions-menu">
                                                <a href="view_user.php?id=<?= $transaction['user_id'] ?>"><i class="fa-solid fa-eye"></i> View User</a>
                                                <a href="impersonate.php?user_id=<?= $transaction['user_id'] ?>"><i class="fa-solid fa-user-secret"></i> Impersonate</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($total_pages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?= $i ?>" class="<?= ($page == $i) ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</main>

<?php
// Include the main footer
require_once __DIR__ . '/templates/footer.php';
?>