<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once __DIR__ . '/../../../database/db.php';
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../../config/smtp_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$update_type = $_POST['update_type'] ?? '';
$amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
$reason = trim(filter_input(INPUT_POST, 'reason', FILTER_SANITIZE_STRING));
$send_email = isset($_POST['send_email']);

if (!$user_id || !in_array($update_type, ['add', 'subtract']) || !$amount || $amount <= 0 || empty($reason)) {
    $_SESSION['message'] = "Invalid data provided. Please fill out all fields correctly.";
    $_SESSION['message_type'] = 'danger';
    header("Location: update_balance.php?user_id=" . $user_id);
    exit();
}

try {
    $pdo->beginTransaction();

    // Get current user balance to prevent subtracting more than they have
    $stmt_user = $pdo->prepare("SELECT first_name, email, balance FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("User not found.");
    }

    $current_balance = $user['balance'];
    $new_balance = 0;
    $amount_display = '';

    if ($update_type === 'add') {
        $new_balance = $current_balance + $amount;
        $amount_display = "+$" . number_format($amount, 2);
    } else { // subtract
        if ($amount > $current_balance) {
            throw new Exception("Cannot subtract more than the user's current balance.");
        }
        $new_balance = $current_balance - $amount;
        $amount_display = "-$" . number_format($amount, 2);
    }

    // Update the user's balance
    $stmt_update = $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt_update->execute([$new_balance, $user_id]);
    
    // Log this manual transaction for record-keeping
    $tx_ref = 'MANUAL-' . strtoupper($update_type) . '-' . $user_id . '-' . time();
    $log_stmt = $pdo->prepare(
        "INSERT INTO transactions (user_id, tx_ref, amount_usd, status, type, description) VALUES (?, ?, ?, 'completed', 'manual_adjustment', ?)"
    );
    $log_stmt->execute([$user_id, $tx_ref, $amount, $reason]);
    
    $pdo->commit();
    
    // Send email if requested
    if ($send_email) {
        try {
            $mail = get_mailer();
            $mail->setFrom('mail@rovicc.com', 'Rovicc Support');
            $mail->addAddress($user['email'], $user['first_name']);
            $mail->isHTML(true);
            $mail->Subject = 'An Update Regarding Your Rovicc Account Balance';
            
            $template = file_get_contents(__DIR__ . '/../emails/update_balance_email_template.html');
            $body = str_replace('{{NAME}}', htmlspecialchars($user['first_name']), $template);
            $body = str_replace('{{AMOUNT_DISPLAY}}', $amount_display, $body);
            $body = str_replace('{{REASON}}', htmlspecialchars($reason), $body);
            $body = str_replace('{{NEW_BALANCE}}', number_format($new_balance, 2), $body);
            
            $mail->Body = $body;
            $mail->send();
            $_SESSION['message'] = "User balance updated successfully and a notification email has been sent.";
        } catch (Exception $e) {
            // Balance was updated, but email failed. Inform the admin.
            $_SESSION['message'] = "User balance updated, but the notification email could not be sent. Error: " . $e->getMessage();
            $_SESSION['message_type'] = 'warning';
            error_log("Update Balance Email Error: " . $e->getMessage());
        }
    } else {
        $_SESSION['message'] = "User balance updated successfully. No email was sent.";
    }

    $_SESSION['message_type'] = $_SESSION['message_type'] ?? 'success';

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['message'] = "An error occurred: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("Update Balance Error: " . $e->getMessage());
}

header("Location: ../view_user.php?id=" . $user_id);
exit();