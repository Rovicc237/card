<?php
session_start();
header('Content-Type: application/json');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require_once __DIR__ . '/../../database/db.php';

$term = $_GET['term'] ?? '';

// Prevent searching for very short terms to reduce server load
if (strlen($term) < 2) {
    echo json_encode([]);
    exit();
}

try {
    $search_term = '%' . $term . '%';
    // Search by first name, last name, full name, or email for verified users
    $sql = "SELECT id, email, first_name, last_name 
            FROM users 
            WHERE (CONCAT(first_name, ' ', last_name) LIKE ? OR email LIKE ?)
            AND is_verified = 1 
            ORDER BY first_name, last_name 
            LIMIT 10";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$search_term, $search_term]);
    $users = $stmt->fetchAll();
    
    echo json_encode($users);

} catch (PDOException $e) {
    error_log("Search user error: " . $e->getMessage());
    echo json_encode(['error' => 'Database query failed.']);
}
