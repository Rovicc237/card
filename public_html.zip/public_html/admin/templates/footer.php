<?php
// This footer file should be included at the bottom of every admin page.
?>
    </div> <!-- Close .admin-container -->

    <!-- Main Admin JavaScript -->
    <script src="js/admin-script.js"></script>

    <!-- Dynamically include page-specific javascript files if they exist -->
    <?php if (isset($page_js) && !empty($page_js)): ?>
        <?php foreach ((array)$page_js as $js_file): ?>
            <script src="js/<?= htmlspecialchars($js_file) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

</body>
</html>
