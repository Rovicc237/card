<?php
// This header file should be included at the top of every admin page.

// Prevent browser caching of admin pages
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// Start the session if it's not already started.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if an admin is logged in. If not, redirect to the login page.
// This check is crucial for securing your admin area.
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Set a default page title if one isn't provided by the including page.
$page_title = $page_title ?? 'Admin Panel - Rovicc';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    
    <link rel="stylesheet" href="css/admin-style.css">
    
    <?php if (isset($page_css) && !empty($page_css)): ?>
        <?php foreach ((array)$page_css as $css_file): ?>
            <link rel="stylesheet" href="css/<?= htmlspecialchars($css_file) ?>">
        <?php endforeach; ?>
    <?php endif; ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-container">