<?php
// This file contains the sidebar navigation.
// It should be included after the header.php file.

// Get the current page filename to set the 'active' class on the correct link.
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">R</div>
        <span>Rovicc Admin</span>
    </div>
    <nav>
        <ul>
            <li><a href="dashboard.php" class="<?= ($current_page == 'dashboard.php') ? 'active' : '' ?>"><i class="fa-solid fa-table-columns"></i> <span>Dashboard</span></a></li>
            <li><a href="users.php" class="<?= ($current_page == 'users.php' || $current_page == 'view_user.php') ? 'active' : '' ?>"><i class="fa-solid fa-users"></i> <span>Users</span></a></li>
            <li><a href="manual_withdrawals.php" class="<?= ($current_page == 'manual_withdrawals.php') ? 'active' : '' ?>"><i class="fa-solid fa-hand-holding-dollar"></i> <span>Pending Withdrawals</span></a></li>
            <li><a href="all_manual_withdrawals.php" class="<?= ($current_page == 'all_manual_withdrawals.php') ? 'active' : '' ?>"><i class="fa-solid fa-history"></i> <span>Withdrawal History</span></a></li>
            <li><a href="deposit_transactions.php" class="<?= ($current_page == 'deposit_transactions.php') ? 'active' : '' ?>"><i class="fa-solid fa-money-bill-transfer"></i> <span>Deposit Transactions</span></a></li>
            <li><a href="all_transactions.php" class="<?= ($current_page == 'all_transactions.php') ? 'active' : '' ?>"><i class="fa-solid fa-receipt"></i> <span>All Transactions</span></a></li>
            <li><a href="referral_settings.php" class="<?= ($current_page == 'referral_settings.php') ? 'active' : '' ?>"><i class="fa-solid fa-gift"></i> <span>Referral Settings</span></a></li>
            <li><a href="#"><i class="fa-solid fa-credit-card"></i> <span>Cards API</span></a></li>
            <li><a href="email-form.php" class="<?= ($current_page == 'email-form.php') ? 'active' : '' ?>"><i class="fa-solid fa-envelope"></i> <span>Send Email</span></a></li>
            <li><a href="settings.php" class="<?= ($current_page == 'settings.php') ? 'active' : '' ?>"><i class="fa-solid fa-cog"></i> <span>Settings</span></a></li>
            <li> <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span></a></li>
        </ul>
    </nav>
    <div class="sidebar-footer">
         <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span></a>
    </div>
</aside>