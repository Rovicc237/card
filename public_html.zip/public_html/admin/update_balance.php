<?php
// Page-specific variables
$page_title = 'Update User Balance - Rovicc Admin';

// CORRECTED: This now includes all necessary stylesheets for this specific page.
// The main 'admin-style.css' is loaded automatically by header.php.
$page_css = ['email-form-professional.css', 'update_balance.css']; 

// Include main header which also handles the database connection and session start
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

// --- Message Handling (from session) ---
$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

// --- Fetch User Data ---
$user_id = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
$user = null;

if ($user_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, first_name, last_name, email, balance FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Prepare a message to be displayed on the page
        $message = "Database error: Could not fetch user details.";
        $message_type = "danger";
        error_log("Update balance page DB error: " . $e->getMessage());
    }
}

// If no user was found, redirect back to the users list page with an error.
if (!$user) {
    $_SESSION['message'] = "User not found or an error occurred.";
    $_SESSION['message_type'] = 'danger';
    header("Location: ../users.php");
    exit();
}

// --- Include Sidebar ---
// This should come after the logic so it doesn't appear on redirect.
require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Update User Balance</h1>
            <p>Manually add or subtract funds from a user's account.</p>
        </div>
        <a href="../view_user.php?id=<?= htmlspecialchars($user_id) ?>" class="btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to User</a>
    </header>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>" style="margin-bottom: 20px; max-width: 700px; margin-left: auto; margin-right: auto;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <section class="settings-section">
        <div class="balance-update-card">
            <h2>Balance Adjustment for <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h2>
            <p>Current Balance: <strong>$<?= number_format($user['balance'], 2) ?></strong></p>
            
            <form action="process_update_balance.php" method="POST">
                <input type="hidden" name="user_id" value="<?= htmlspecialchars($user['id']) ?>">
                
                <div class="form-group">
                    <label for="update_type">Action</label>
                    <select id="update_type" name="update_type" required>
                        <option value="add">Add Funds to Account</option>
                        <option value="subtract">Subtract Funds from Account</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="amount">Amount (USD)</label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required placeholder="e.g., 10.50">
                </div>

                <div class="form-group">
                    <label for="reason">Reason for Adjustment</label>
                    <textarea id="reason" name="reason" rows="4" required placeholder="Provide a clear reason for this manual transaction (e.g., 'Refund for failed transaction', 'Promotional bonus'). This will be visible to the user if an email is sent."></textarea>
                </div>

                 <div class="form-group">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="send_email" name="send_email" value="1" checked>
                        <label class="form-check-label" for="send_email">
                            Notify user by email about this adjustment
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-save"></i> Update Balance</button>
            </form>
        </div>
    </section>
</main>
<?php
// --- Include Footer ---
require_once __DIR__ . '/templates/footer.php';
?>