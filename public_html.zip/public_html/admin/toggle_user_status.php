<?php
// public_html/admin/toggle_user_status.php

session_start();
require_once __DIR__ . '/../../database/db.php';

// Security: Only allow POST requests and check for admin session
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Sanitize and validate inputs
$user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);

if (!$user_id || !in_array($action, ['enable', 'disable'])) {
    $_SESSION['message'] = "Invalid action. Please try again.";
    $_SESSION['message_type'] = 'danger';
    header("Location: dashboard.php");
    exit();
}

try {
    $new_status = ($action === 'disable') ? 1 : 0;
    
    $stmt = $pdo->prepare("UPDATE users SET is_disabled = ? WHERE id = ?");
    $stmt->execute([$new_status, $user_id]);

    $_SESSION['message'] = "User account has been successfully " . ($action === 'disable' ? 'disabled.' : 'enabled.');
    $_SESSION['message_type'] = 'success';

} catch (PDOException $e) {
    $_SESSION['message'] = "A database error occurred. Could not update user status.";
    $_SESSION['message_type'] = 'danger';
    error_log("Toggle User Status Error: " . $e->getMessage());
}

header("Location: view_user.php?id=" . $user_id);
exit();