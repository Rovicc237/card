<?php
// public_html/admin/update_kyc.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

session_start();
require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../config/smtp_config.php';

// Security: Only allow POST requests and check for admin session
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Sanitize and validate inputs
$user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$kyc_status = filter_input(INPUT_POST, 'kyc_status', FILTER_SANITIZE_STRING);
$kyc_feedback = trim(filter_input(INPUT_POST, 'kyc_feedback', FILTER_SANITIZE_STRING));
$admin_id = $_SESSION['admin_id'];

if (!$user_id || !in_array($kyc_status, ['Approved', 'Rejected'])) {
    $_SESSION['message'] = "Invalid data provided. Please try again.";
    $_SESSION['message_type'] = 'danger';
    header("Location: view_user.php?id=" . $user_id);
    exit();
}

// Ensure feedback is provided for rejection
if ($kyc_status === 'Rejected' && empty($kyc_feedback)) {
    $_SESSION['message'] = "Feedback is required when rejecting KYC documents.";
    $_SESSION['message_type'] = 'danger';
    header("Location: view_user.php?id=" . $user_id);
    exit();
}


try {
    // Fetch user details for the email notification
    $stmt = $pdo->prepare("SELECT email, first_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception("User not found.");
    }

    // Start a transaction to ensure both DB update and email sending are treated as a single operation
    $pdo->beginTransaction();

    // Update the user's KYC status and feedback in the database
    $sql = "UPDATE users SET 
                kyc_status = ?, 
                kyc_feedback = ?, 
                kyc_reviewed_at = NOW(), 
                kyc_reviewed_by = ? 
            WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$kyc_status, $kyc_feedback, $admin_id, $user_id]);

    // --- Send Email Notification to User ---
    $mail = get_mailer();
    
    // --- UNCOMMENT THE LINE BELOW FOR DETAILED SMTP DEBUGGING ---
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;

    $mail->setFrom('mail@rovicc.com', 'Rovicc Support');
    $mail->addAddress($user['email'], $user['first_name']);
    $mail->isHTML(true);
    $mail->Subject = 'Update on Your KYC Verification';

    // Load and personalize the email template
    $template_path = __DIR__ . '/emails/kyc_feedback_template.html';
    if (!file_exists($template_path)) {
        throw new Exception("Email template file not found.");
    }
    $template = file_get_contents($template_path);
    
    // Replace placeholders with actual data
    $email_body = str_replace('{{NAME}}', htmlspecialchars($user['first_name']), $template);
    $email_body = str_replace('{{STATUS}}', $kyc_status, $email_body);
    $email_body = str_replace('{{STATUS_CLASS}}', strtolower($kyc_status), $email_body);
    $email_body = str_replace('{{FEEDBACK}}', nl2br(htmlspecialchars($kyc_feedback ?: 'No specific feedback was provided.')), $email_body);
    
    $mail->Body = $email_body;
    $mail->AltBody = "Hello " . $user['first_name'] . ",\n\nYour KYC status has been updated to: " . $kyc_status . ".\n\nFeedback from our team: " . ($kyc_feedback ?: 'N/A') . "\n\nThank you,\nThe Rovicc Team";
    
    $mail->send();

    // If both DB update and email were successful, commit the transaction
    $pdo->commit();

    $_SESSION['message'] = "KYC status has been updated and the user has been notified by email.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    // If anything fails, roll back the database transaction
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Provide a detailed error message for easier debugging
    $_SESSION['message'] = "A critical error occurred. The user was not notified. Please check the system logs. Error: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("KYC Update and Email Error: " . $e->getMessage());
}

header("Location: view_user.php?id=" . $user_id);
exit();