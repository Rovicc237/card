<?php
// Page-specific variables
$page_title = 'User Management - Rovicc Admin';

// We assume header.php starts the session
require_once __DIR__ . '/templates/header.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Include the sidebar
require_once __DIR__ . '/templates/sidebar.php';
?>

<style>
    .main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    #mobile-toggle {
        display: none; /* Hidden by default on desktop */
        background: #2a3f54;
        color: #ECF0F1;
        border: none;
        font-size: 24px;
        padding: 10px 15px;
        border-radius: 5px;
        cursor: pointer;
    }

    /* Styles for mobile devices */
    @media (max-width: 768px) {
        #mobile-toggle {
            display: block; /* Show the button on mobile */
        }

        /* This assumes your sidebar has an ID of #sidebar. */
        /* It will be hidden off-screen by default on mobile. */
        #sidebar {
            position: fixed;
            left: -250px; /* Start off-screen */
            top: 0;
            height: 100%;
            z-index: 1000;
            transition: left 0.3s ease-in-out;
        }

        /* This class will be added by JavaScript to show the sidebar */
        #sidebar.active {
            left: 0; /* Slide in */
        }
    }
</style>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>User Management</h1>
            <p>View, search, and manage all user accounts in real-time.</p>
        </div>
        <button id="mobile-toggle" aria-label="Toggle Menu">
            <i class="fa-solid fa-bars"></i>
        </button>
    </header>

    <div class="search-container" style="margin-bottom: 20px;">
        <form id="search-form" onsubmit="return false;">
            <input type="text" id="search-input" name="search" placeholder="Search by name or email..." style="padding: 10px; width: 300px; border-radius: 5px; border: 1px solid #ccc;">
        </form>
    </div>

    <section class="users-table-section">
        <h2>All Users (<span id="user-count">0</span>)</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>KYC Status</th>
                        <th>Verified</th>
                        <th>Disabled</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody id="users-table-body">
                    </tbody>
            </table>
        </div>
    </section>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const userTableBody = document.getElementById('users-table-body');
    const userCount = document.getElementById('user-count');
    
    // --- NEW: Mobile Navigation Logic ---
    const mobileToggleButton = document.getElementById('mobile-toggle');
    const sidebar = document.getElementById('sidebar'); // Assumes sidebar has id="sidebar"

    if (mobileToggleButton && sidebar) {
        mobileToggleButton.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    // --- End of new logic ---


    // Function to fetch and display users
    async function fetchUsers(searchTerm = '') {
        userTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Searching...</td></tr>';

        try {
            const response = await fetch(`api_search_users.php?search=${encodeURIComponent(searchTerm)}`);

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Server responded with status ${response.status}. Full response: <br><pre>${errorText}</pre>`);
            }

            const data = await response.json();

            if (data.success === false) {
                 throw new Error(`API Error: ${data.message} <br><pre>${data.error_details || ''}</pre>`);
            }

            userTableBody.innerHTML = '';
            userCount.textContent = data.users.length;

            if (data.users.length === 0) {
                userTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No users found.</td></tr>';
                return;
            }

            data.users.forEach(user => {
                const kycStatusClass = `status-badge kyc-status-${user.kyc_status.toLowerCase()}`;
                const kycStatusText = user.kyc_status.charAt(0).toUpperCase() + user.kyc_status.slice(1);
                const row = `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.first_name} ${user.last_name}</td>
                        <td>${user.email}</td>
                        <td>${user.phone || 'N/A'}</td>
                        <td><span class="${kycStatusClass}">${kycStatusText}</span></td>
                        <td>${user.is_verified ? 'Yes' : 'No'}</td>
                        <td>${user.is_disabled ? 'Yes' : 'No'}</td>
                        <td style="text-align: center;">
                            <a href="view_user.php?id=${user.id}" class="btn-action btn-view"><i class="fa-solid fa-eye"></i></a>
                            <a href="impersonate.php?user_id=${user.id}" class="btn-action btn-impersonate"><i class="fa-solid fa-user-secret"></i></a>
                        </td>
                    </tr>
                `;
                userTableBody.insertAdjacentHTML('beforeend', row);
            });

        } catch (error) {
            userCount.textContent = 0;
            const errorRow = `<tr><td colspan="8" style="text-align:left; color: red; padding: 15px;">
                <strong>Failed to load users.</strong><br>
                <p><strong>Error Details:</strong></p>
                <div>${error.message}</div>
            </td></tr>`;
            userTableBody.innerHTML = errorRow;
            console.error('Fetch error:', error);
        }
    }

    // Initial load of all users
    fetchUsers();

    // Listen for input in the search box
    searchInput.addEventListener('keyup', () => fetchUsers(searchInput.value));
});
</script>

<?php
// Include the main footer
require_once __DIR__ . '/templates/footer.php';
?>