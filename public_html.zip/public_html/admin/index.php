<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

$error = '';
$admin_exists = false;

try {
    $stmt = $pdo->query("SELECT id FROM admins LIMIT 1");
    if ($stmt->fetch()) {
        $admin_exists = true;
    }
} catch (PDOException $e) {
    die("Database error checking for admin.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($admin_exists) {
        // Handle Login
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            $error = "Username and password are required.";
        } else {
            try {
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
                $stmt->execute([$username]);
                $admin = $stmt->fetch();

                if ($admin && password_verify($password, $admin['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_username'] = $admin['username'];
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = "Invalid username or password.";
                }
            } catch (PDOException $e) {
                $error = "A database error occurred.";
                error_log($e->getMessage());
            }
        }
    } else {
        // Handle Registration
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if (empty($username) || empty($password) || empty($confirm_password)) {
            $error = "All fields are required.";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } else {
            try {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO admins (username, password) VALUES (?, ?)";
                $stmt = $pdo->prepare($sql);

                if ($stmt->execute([$username, $hashedPassword])) {
                    // Automatically log in the new admin
                    session_regenerate_id(true);
                    $_SESSION['admin_id'] = $pdo->lastInsertId();
                    $_SESSION['admin_username'] = $username;
                    header("Location: dashboard.php");
                    exit();
                }
            } catch (PDOException $e) {
                $error = "Database error: Could not register admin.";
                error_log($e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rovicc Admin</title>
    <link rel="stylesheet" href="css/admin-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="login-body">
    <div class="login-container">
        <div class="login-box">
            <div class="login-logo">R</div>
            <h2>Rovicc Admin</h2>
            <?php if (!$admin_exists): ?>
                <h3>Create Master Account</h3>
                <p>This will be the only administrative account.</p>
            <?php else: ?>
                <h3>Administrator Login</h3>
                <p>Please enter your credentials.</p>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <?php if (!$admin_exists): ?>
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn-login">Create Account</button>
                <?php else: ?>
                    <button type="submit" class="btn-login">Login</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>