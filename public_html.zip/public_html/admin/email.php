<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once __DIR__ . '/../../database/db.php';

$recipient_type = $_POST['recipient_type'] ?? '';
$specific_recipient_email = trim(filter_input(INPUT_POST, 'recipient_specific', FILTER_SANITIZE_EMAIL));
$subject = trim(filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING));
$message_body = trim($_POST['message'] ?? '');

if (empty($recipient_type) || empty($subject) || empty($message_body)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

try {
    $pdo->beginTransaction();
    $sql = "INSERT INTO email_queue (recipient_email, recipient_name, subject, message_body) VALUES (?, ?, ?, ?)";
    $stmt_queue = $pdo->prepare($sql);
    $job_ids = [];

    if ($recipient_type === 'specific') {
        $stmt_user = $pdo->prepare("SELECT first_name, last_name FROM users WHERE email = ?");
        $stmt_user->execute([$specific_recipient_email]);
        $user = $stmt_user->fetch();
        $recipient_name = $user ? trim($user['first_name'] . ' ' . $user['last_name']) : 'Valued User';
        
        $stmt_queue->execute([$specific_recipient_email, $recipient_name, $subject, $message_body]);
        $job_ids[] = $pdo->lastInsertId();
    } else {
        $stmt_users = $pdo->query("SELECT email, first_name, last_name FROM users WHERE is_verified = 1");
        $users = $stmt_users->fetchAll();
        
        foreach ($users as $user) {
            $recipient_name = trim($user['first_name'] . ' ' . $user['last_name']);
            $stmt_queue->execute([$user['email'], $recipient_name, $subject, $message_body]);
            $job_ids[] = $pdo->lastInsertId();
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => count($job_ids) . ' emails queued.', 'jobs' => $job_ids]);

} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    error_log("Email Queueing Error: " . $e->getMessage());
}
?>