<?php
// Set header immediately to guarantee a JSON response
header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// --- Centralized Error Handling ---
function send_json_error($message, $job_id = null, $log_message = null) {
    error_log("Email Processor Failure (Job ID: {$job_id}): " . ($log_message ?: $message));
    echo json_encode(['success' => false, 'message' => $message]);
    exit();
}

try {
    require_once __DIR__ . '/../../database/db.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
    require_once __DIR__ . '/../config/smtp_config.php';
} catch (Throwable $t) {
    send_json_error('A required system file is missing or has an error.', null, $t->getMessage());
}

session_start();
if (!isset($_SESSION['admin_id'])) {
    send_json_error('Unauthorized Access. Your session may have expired.');
}

$job_id = $_POST['job_id'] ?? null;
if (!$job_id) {
    send_json_error('Error: No job ID was provided to the processor.');
}

try {
    $stmt = $pdo->prepare("SELECT * FROM email_queue WHERE id = ? AND status = 'pending'");
    $stmt->execute([$job_id]);
    $job = $stmt->fetch();

    if ($job) {
        $mail = get_mailer();
        
        $mail->setFrom('mail@rovicc.com', 'Rovicc Admin');
        $mail->addAddress($job['recipient_email'], $job['recipient_name']);
        $mail->isHTML(true);
        $mail->Subject = $job['subject'];
        
        $template = file_get_contents(__DIR__ . '/emails/admin_general_template.html');
        $email_body = str_replace('{{NAME}}', htmlspecialchars($job['recipient_name']), $template);
        $email_body = str_replace('{{SUBJECT}}', htmlspecialchars($job['subject']), $email_body);
        $email_body = str_replace('{{MESSAGE_BODY}}', nl2br(htmlspecialchars($job['message_body'])), $email_body);
        
        $mail->Body = $email_body;
        $mail->AltBody = $job['message_body'];

        if ($mail->send()) {
            $update_stmt = $pdo->prepare("UPDATE email_queue SET status = 'sent', sent_at = NOW() WHERE id = ?");
            $update_stmt->execute([$job_id]);
            echo json_encode(['success' => true, 'message' => 'Sent to ' . htmlspecialchars($job['recipient_email'])]);
        } else {
            throw new Exception($mail->ErrorInfo);
        }
    } else {
        echo json_encode(['success' => true, 'message' => 'Job already processed or not found. Skipping.']);
    }

} catch (Exception $e) {
    // Mark the job as failed in the database
    $update_stmt = $pdo->prepare("UPDATE email_queue SET status = 'failed', error_message = ? WHERE id = ?");
    $update_stmt->execute([$e->getMessage(), $job_id]);
    send_json_error('Failed for ' . htmlspecialchars($job['recipient_email'] ?? 'unknown') . '. Error: ' . $e->getMessage(), $job_id);
}
?>