<?php

/**
 * Admin Dashboard
 * This script displays the main admin dashboard.
 * It dynamically fetches the Sudo API Key, Base URL, and Account ID from admin settings
 * to display the current Sudo account balance.
 *
 * Layout:
 * 1. Statistics Cards
 * 2. Pending Notifications
 * 3. Recent Users Table (linking to full user management)
 * 4. Recent Deposits Table (linking to full deposit transactions)
 */

// --- Page Setup ---
error_reporting(E_ALL);
ini_set('display_errors', 1); // Remember to turn this off for production

// Page-specific variables
$page_title = 'Admin Dashboard - Rovicc';

// --- Dependencies ---
// These files should handle session start, user authentication, and the database connection.
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php'; // Ensures $pdo is available

// --- Sudo Balance API Integration ---

/**
 * Fetches the balance for a specific account from the API.
 *
 * @param string $baseUrl   The base URL for the Sudo API endpoint.
 * @param string $accountId The ID of the account to fetch the balance for.
 * @param string $apiToken  The authorization token for the API.
 * @return string The API response as a JSON string, or an empty string on failure.
 */
function getAccountBalance(string $baseUrl, string $accountId, string $apiToken): string
{
    // Construct the full URL dynamically using the provided base URL.
    // rtrim removes any trailing slash from the base URL to prevent errors.
    $url = rtrim($baseUrl, '/') . "/accounts/{$accountId}/balance";

    // Initialize a cURL session.
    $ch = curl_init();

    // Set the options for the cURL session.
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_HTTPGET => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json",
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
    ]);

    // Execute the cURL session and get the response.
    $response = curl_exec($ch);

    // Check for cURL errors.
    if (curl_errno($ch)) {
        error_log('cURL Error in getAccountBalance: ' . curl_error($ch));
        return '';
    }

    // Close the cURL session to free up resources.
    curl_close($ch);

    // Return the response from the API.
    return $response;
}


// --- Main Execution Logic ---

// Initialize variables with default values.
$sudo_current_balance = 'N/A';
$sudo_api_key = null;
$sudo_base_url = null;
$sudo_account_id = null;

// **STEP 1: Fetch Admin-set API Key, Base URL, and Account ID from the Database**
try {
    // Fetch all three settings in one query for efficiency.
    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_account_id')");
    // Fetch into an associative array: ['setting_key' => 'setting_value']
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);

    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;
    $sudo_account_id = $api_settings['sudo_account_id'] ?? null;

} catch (PDOException $e) {
    // Handle database errors gracefully.
    error_log("Could not fetch Sudo API settings from database: " . $e->getMessage());
    $sudo_current_balance = 'DB Error';
}


// **STEP 2: Use the Fetched Settings to Get the Balance**
// Proceed only if ALL THREE settings have been successfully fetched.
if (!empty($sudo_api_key) && !empty($sudo_base_url) && !empty($sudo_account_id)) {

    // Call the function with all dynamic values.
    $balanceInfoJson = getAccountBalance($sudo_base_url, $sudo_account_id, $sudo_api_key);

    if (!empty($balanceInfoJson)) {
        // Decode the JSON response into a PHP associative array.
        $balanceData = json_decode($balanceInfoJson, true);

        // Check if the key exists and display the raw value.
        if (isset($balanceData['data']['currentBalance'])) {
            $sudo_current_balance = number_format($balanceData['data']['currentBalance'], 2);
        } else {
            $sudo_current_balance = 'API Error';
            error_log("Could not find 'currentBalance' in Sudo API response: " . $balanceInfoJson);
        }
    } else {
        $sudo_current_balance = 'Fetch Failed';
    }
} else if ($sudo_current_balance !== 'DB Error') {
    // This condition runs if any of the API settings are missing from the DB.
    $sudo_current_balance = 'Config Missing';
}


// --- Dashboard Data Fetching ---
try {
    // Fetch unread notifications
    $notifications_stmt = $pdo->query("SELECT n.id, n.message, n.link, u.first_name, u.last_name, n.created_at FROM admin_notifications n JOIN users u ON n.user_id = u.id WHERE n.is_read = 0 ORDER BY n.created_at DESC");
    $notifications = $notifications_stmt->fetchAll();

    // Fetch statistics for dashboard cards
    $total_users = $pdo->query("SELECT count(id) FROM users")->fetchColumn();
    $verified_users = $pdo->query("SELECT count(id) FROM users WHERE is_verified = 1")->fetchColumn();
    $unverified_users = $total_users - $verified_users;
    
    // UPDATED: Fetch total successful deposits using 'completed' status
    $total_deposits_usd = $pdo->query("SELECT SUM(amount_usd) FROM transactions WHERE type = 'deposit' AND status = 'completed'")->fetchColumn();
    $total_deposits_usd = $total_deposits_usd ?? 0; // Default to 0 if null

    // Fetch recent deposit transactions for the dashboard widget
    $recent_deposits_stmt = $pdo->prepare("
        SELECT 
            t.tx_ref, 
            t.amount_usd, 
            t.status, 
            t.created_at,
            u.first_name, 
            u.last_name
        FROM 
            transactions t
        JOIN 
            users u ON t.user_id = u.id
        WHERE 
            t.type = 'deposit'
        ORDER BY 
            t.created_at DESC
        LIMIT 5
    ");
    $recent_deposits_stmt->execute();
    $recent_deposits = $recent_deposits_stmt->fetchAll();


    // Fetch recent users for the dashboard widget
    $recent_users_stmt = $pdo->prepare("SELECT id, first_name, last_name, email, is_verified, kyc_status, documents_submitted_at, is_disabled FROM users ORDER BY created_at DESC LIMIT 5");
    $recent_users_stmt->execute();
    $recent_users = $recent_users_stmt->fetchAll();


} catch (PDOException $e) {
    error_log("Database error on dashboard: " . $e->getMessage());
    $notifications = [];
    $total_users = $verified_users = $unverified_users = 0;
    $total_deposits_usd = 0;
    $recent_deposits = [];
    $recent_users = [];
}

// --- Sidebar ---
require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Admin Dashboard</h1>
            <p>Welcome, <?= htmlspecialchars($_SESSION['admin_username'] ?? 'Admin') ?>!</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle Menu">
            <i class="fa-solid fa-bars"></i>
        </button>
    </header>
    
    <section class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #f3e8ff;"><i class="fa-solid fa-money-bill-wave" style="color: #9333ea;"></i></div>
            <div class="stat-info">
                <p>Sudo Balance</p>
                <span>$<?= htmlspecialchars($sudo_current_balance) ?></span>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #e0e7ff;"><i class="fa-solid fa-users" style="color: #4f46e5;"></i></div>
            <div class="stat-info">
                <p>Total Users</p>
                <span><?= htmlspecialchars($total_users) ?></span>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #d1fae5;"><i class="fa-solid fa-user-check" style="color: #059669;"></i></div>
            <div class="stat-info">
                <p>Verified Users</p>
                <span><?= htmlspecialchars($verified_users) ?></span>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #fee2e2;"><i class="fa-solid fa-user-times" style="color: #ef4444;"></i></div>
            <div class="stat-info">
                <p>Unverified Users</p>
                <span><?= htmlspecialchars($unverified_users) ?></span>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #ffe0b2;"><i class="fa-solid fa-money-bill-transfer" style="color: #ff9800;"></i></div>
            <div class="stat-info">
                <p>Total Deposits</p>
                <span>$<?= number_format($total_deposits_usd, 2) ?></span>
            </div>
        </div>
    </section>

    <?php if (!empty($notifications)): ?>
    <section class="notifications-section">
        <h3><i class="fa-solid fa-bell"></i> Pending Reviews</h3>
        <div class="notifications-list">
            <?php foreach ($notifications as $notification): ?>
            <a href="<?= htmlspecialchars($notification['link']) ?>&notification_id=<?= $notification['id'] ?>" class="notification-item">
                <div class="notification-icon"><i class="fa-solid fa-user-shield"></i></div>
                <div class="notification-content">
                    <p><?= htmlspecialchars($notification['message']) ?></p>
                    <small><?= date("M d, Y, g:i a", strtotime($notification['created_at'])) ?></small>
                </div>
                <div class="notification-arrow"><i class="fa-solid fa-chevron-right"></i></div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="users-table-section">
        <div class="section-header">
            <h2>Recent Users</h2>
            <a href="users.php" class="btn-back">View All Users <i class="fa-solid fa-arrow-right"></i></a>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>KYC Status</th>
                        <th>Last Submission</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recent_users)): ?>
                        <tr><td colspan="6" style="text-align: center;">No recent users found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recent_users as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['id']) ?></td>
                            <td><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td>
                                <span class="status-badge kyc-status-<?= strtolower(htmlspecialchars($user['kyc_status'])) ?>">
                                    <?= htmlspecialchars(ucfirst($user['kyc_status'])) ?>
                                </span>
                            </td>
                            <td><?= $user['documents_submitted_at'] ? date("M j, Y", strtotime($user['documents_submitted_at'])) : 'N/A' ?></td>
                            <td style="text-align: center;">
                                <div class="actions-menu-container">
                                    <button class="actions-menu-toggle">
                                        Actions <i class="fa-solid fa-caret-down"></i>
                                    </button>
                                    <div class="actions-menu">
                                        <a href="view_user.php?id=<?= $user['id'] ?>"><i class="fa-solid fa-eye"></i> View Details</a>
                                        <?php if ($user['is_verified'] && !$user['is_disabled']): ?>
                                            <a href="impersonate.php?user_id=<?= $user['id'] ?>"><i class="fa-solid fa-user-secret"></i> Impersonate</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="users-table-section">
        <h2>Recent Deposits</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>User</th>
                        <th>Amount (USD)</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recent_deposits)): ?>
                        <tr><td colspan="5" style="text-align: center;">No recent deposits found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recent_deposits as $deposit): ?>
                            <tr>
                                <td><?= htmlspecialchars($deposit['tx_ref']) ?></td>
                                <td><?= htmlspecialchars($deposit['first_name'] . ' ' . $deposit['last_name']) ?></td>
                                <td>$<?= number_format($deposit['amount_usd'], 2) ?></td>
                                <td>
                                    <?php
                                        $status_class = '';
                                        // UPDATED: Switch case now checks for 'completed'
                                        switch ($deposit['status']) {
                                            case 'completed':
                                                $status_class = 'status-verified';
                                                break;
                                            case 'pending':
                                                $status_class = 'status-unverified';
                                                break;
                                            case 'failed':
                                                $status_class = 'status-rejected';
                                                break;
                                            default:
                                                $status_class = '';
                                        }
                                    ?>
                                    <span class="status-badge <?= $status_class ?>">
                                        <?= htmlspecialchars(ucfirst($deposit['status'])) ?>
                                    </span>
                                </td>
                                <td><?= date("M j, Y, g:i a", strtotime($deposit['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: right; margin-top: 15px;">
            <a href="deposit_transactions.php" class="btn-back">View All Deposits <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </section>
</main>

<?php
// --- Footer ---
require_once __DIR__ . '/templates/footer.php';
?>