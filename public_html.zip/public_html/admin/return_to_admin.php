<?php
// public_html/admin/return_to_admin.php

session_start();

// 1. Security Check: Ensure this is an impersonation session
if (!isset($_SESSION['original_admin_id'])) {
    // If not impersonating, just send to the admin login
    header("Location: index.php");
    exit();
}

// 2. Restore the original admin session
$_SESSION['admin_id'] = $_SESSION['original_admin_id'];
$_SESSION['admin_username'] = $_SESSION['original_admin_username'];

// 3. Clear the user and impersonation-tracking session variables
unset($_SESSION['user_id']);
unset($_SESSION['first_name']);
unset($_SESSION['last_name']);
unset($_SESSION['email']);
unset($_SESSION['original_admin_id']);
unset($_SESSION['original_admin_username']);

// 4. Redirect back to the admin dashboard
header("Location: dashboard.php");
exit();