<?php
// --- ERROR REPORTING ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json');

// --- DATABASE CONNECTION ---
require_once __DIR__ . '/../../database/db.php';

// --- AUTHENTICATION CHECK ---
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication failed.']);
    exit();
}

// --- SQL QUERY EXECUTION ---
try {
    $search_term = trim($_GET['search'] ?? '');
    
    // Base SQL query
    $sql = "SELECT id, first_name, last_name, email, phone, kyc_status, is_verified, is_disabled FROM users";
    $params = [];

    // If there is a search term, add the WHERE clause and parameters
    if (!empty($search_term)) {
        // We use positional placeholders (?) to avoid parameter number errors
        $sql .= " WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ?";
        
        // We create one value and add it to the parameters array three times
        $search_value = '%' . $search_term . '%';
        $params = [$search_value, $search_value, $search_value];
    }

    $stmt = $pdo->prepare($sql);
    
    // Execute the statement with the correct number of parameters
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'users' => $users]);

} catch (PDOException $e) {
    // This will catch any remaining SQL errors
    http_response_code(500);
    echo json_encode([
        'success'       => false,
        'message'       => 'A Database Query Error occurred.',
        'error_details' => $e->getMessage()
    ]);
}
?>