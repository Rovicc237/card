<?php
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

$stmt = $pdo->prepare("
    SELECT mw.*, u.first_name, u.last_name, u.email, a.username as admin_username
    FROM manual_withdrawals mw
    JOIN users u ON mw.user_id = u.id
    LEFT JOIN admins a ON mw.admin_id = a.id
    ORDER BY mw.requested_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>All Withdrawal Requests</h1>
            <p>A complete history of all manual withdrawal requests.</p>
        </div>
    </header>

    <section class="users-table-section">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>User</th>
                        <th>Amount (USD)</th>
                        <th>Mobile Money Number</th>
                        <th>Status</th>
                        <th>Date Requested</th>
                        <th>Date Processed</th>
                        <th>Processed By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr><td colspan="8" style="text-align: center;">No withdrawal requests found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($requests as $request): ?>
                        <tr>
                            <td>#<?= htmlspecialchars($request['id']) ?></td>
                            <td><?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?></td>
                            <td>$<?= number_format($request['amount'], 2) ?></td>
                            <td><?= htmlspecialchars($request['mobile_money_number']) ?></td>
                            <td>
                                <?php
                                    $status_class = 'status-default';
                                    if ($request['status'] === 'approved') $status_class = 'status-verified';
                                    if ($request['status'] === 'pending') $status_class = 'status-unverified';
                                    if ($request['status'] === 'rejected') $status_class = 'status-rejected';
                                ?>
                                <span class="status-badge <?= $status_class ?>">
                                    <?= htmlspecialchars(ucfirst($request['status'])) ?>
                                </span>
                            </td>
                            <td><?= date("M j, Y, g:i a", strtotime($request['requested_at'])) ?></td>
                            <td><?= $request['processed_at'] ? date("M j, Y, g:i a", strtotime($request['processed_at'])) : 'N/A' ?></td>
                            <td><?= htmlspecialchars($request['admin_username'] ?? 'N/A') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/templates/footer.php'; ?>