<?php
// Page-specific variables
$page_title = 'View User Details - Rovicc Admin';
$page_css = ['view-user.css'];

// Include main header
require_once __DIR__ . '/templates/header.php';
// Include DB connection
require_once __DIR__ . '/../../database/db.php';

// Mark notification as read if an ID is provided
$notification_id = filter_input(INPUT_GET, 'notification_id', FILTER_VALIDATE_INT);
if ($notification_id) {
    try {
        $stmt = $pdo->prepare("UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND is_read = 0");
        $stmt->execute([$notification_id]);
    } catch (PDOException $e) {
        // Log error but don't stop the page from loading
        error_log("Failed to mark notification as read: " . $e->getMessage());
    }
}

// Get user ID from the URL
$user_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$user_id) {
    echo "<main class='main-content'><p class='alert alert-danger'>Invalid user ID provided.</p></main>";
    require_once __DIR__ . '/templates/footer.php';
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        echo "<main class='main-content'><p class='alert alert-danger'>No user found with this ID.</p></main>";
        require_once __DIR__ . '/templates/footer.php';
        exit();
    }
} catch (PDOException $e) {
    die("Database error: Could not fetch user data.");
    error_log($e->getMessage());
}

// Determine if the documents are a new submission (within the last 24 hours)
$is_new_submission = false;
if ($user['documents_submitted_at']) {
    $submission_time = new DateTime($user['documents_submitted_at']);
    $current_time = new DateTime();
    $interval = $current_time->diff($submission_time);
    if ($interval->days < 1) {
        $is_new_submission = true;
    }
}

// Include the sidebar
require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>User Details</h1>
            <p>Viewing profile for <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></p>
        </div>
        <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    </header>


    <div class="account-actions-card">
            <h3>Account Actions</h3>
            ...
            <a href="update_balance/update_balance.php?user_id=<?= $user['id'] ?>" class="btn-action btn-update-balance" style="background-color: #0ea5e9; margin-top: 10px; text-align: center; display: block;"><i class="fa-solid fa-wallet"></i> Update Balance</a>
        </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?>"><?= htmlspecialchars($_SESSION['message']) ?></div>
        <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
    <?php endif; ?>

    <section class="user-details-grid">
        <div class="profile-card">
            <div class="profile-picture">
                <?php if (!empty($user['profile_picture'])): ?>
                    <img src="serve_document.php?file=<?= urlencode($user['profile_picture']) ?>" alt="Profile Picture">
                <?php else: ?>
                    <i class="fa-solid fa-user-astronaut"></i>
                <?php endif; ?>
            </div>
            <h2 class="profile-name"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h2>
            <p class="profile-email"><?= htmlspecialchars($user['email']) ?></p>
            <div class="profile-status">
                <span class="status-badge <?= $user['is_verified'] ? 'status-verified' : 'status-unverified' ?>">
                    <?= $user['is_verified'] ? 'Account Verified' : 'Account Unverified' ?>
                </span>
                 <span class="status-badge kyc-status-<?= strtolower(htmlspecialchars($user['kyc_status'])) ?>">
                    KYC: <?= htmlspecialchars($user['kyc_status']) ?>
                </span>
            </div>
        </div>

        <div class="kyc-documents-card">
            <div class="card-header-flex">
                <h3>KYC Documents</h3>
                <?php if ($is_new_submission && $user['kyc_status'] === 'Pending'): ?>
                    <span class="new-submission-badge"><i class="fa-solid fa-star"></i> New Submission</span>
                <?php endif; ?>
            </div>
            <p>Review the documents submitted by the user.</p>
            <ul class="document-list">
                <li>
                    <i class="fa-solid fa-address-card"></i>
                    <span>ID Card (Front)</span>
                    <?php if (!empty($user['id_card_front'])): ?>
                        <a href="serve_document.php?file=<?= urlencode($user['id_card_front']) ?>" target="_blank" class="btn-view-doc">View</a>
                    <?php else: ?>
                        <span class="doc-missing">Not Provided</span>
                    <?php endif; ?>
                </li>
                <li>
                    <i class="fa-solid fa-address-card"></i>
                    <span>ID Card (Back)</span>
                    <?php if (!empty($user['id_card_back'])): ?>
                        <a href="serve_document.php?file=<?= urlencode($user['id_card_back']) ?>" target="_blank" class="btn-view-doc">View</a>
                    <?php else: ?>
                        <span class="doc-missing">Not Provided</span>
                    <?php endif; ?>
                </li>
                 <li>
                    <i class="fa-solid fa-camera"></i>
                    <span>Selfie Picture</span>
                    <?php if (!empty($user['profile_picture'])): ?>
                        <a href="serve_document.php?file=<?= urlencode($user['profile_picture']) ?>" target="_blank" class="btn-view-doc">View</a>
                    <?php else: ?>
                        <span class="doc-missing">Not Provided</span>
                    <?php endif; ?>
                </li>
            </ul>
        </div>

        <div class="account-actions-card">
            <h3>Account Actions</h3>
            <p>Enable or disable this user's account access.</p>
            <div class="action-status">
                Current Status: 
                <?php if ($user['is_disabled']): ?>
                    <span class="status-disabled">Disabled</span>
                <?php else: ?>
                    <span class="status-enabled">Enabled</span>
                <?php endif; ?>
            </div>
            <form action="toggle_user_status.php" method="POST" onsubmit="return confirm('Are you sure you want to <?= $user['is_disabled'] ? 'enable' : 'disable' ?> this account?');">
                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                <?php if ($user['is_disabled']): ?>
                    <input type="hidden" name="action" value="enable">
                    <button type="submit" class="btn-action btn-enable"><i class="fa-solid fa-check-circle"></i> Enable Account</button>
                <?php else: ?>
                    <input type="hidden" name="action" value="disable">
                    <button type="submit" class="btn-action btn-disable"><i class="fa-solid fa-ban"></i> Disable Account</button>
                <?php endif; ?>
            </form>
        </div>

        <div class="user-info-card">
             <h3>User Information</h3>
             <div class="info-grid">
                 <div><strong>Full Name:</strong><p><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></p></div>
                 <div><strong>Email Address:</strong><p><?= htmlspecialchars($user['email']) ?></p></div>
                 <div><strong>Phone Number:</strong><p><?= htmlspecialchars($user['phone']) ?></p></div>
                 <div><strong>Date of Birth:</strong><p><?= date("F j, Y", strtotime($user['dob'])) ?></p></div>
                 <div><strong>Account Created:</strong><p><?= date("F j, Y, g:i a", strtotime($user['created_at'])) ?></p></div>
                 <div><strong>Last Review By:</strong><p><?= htmlspecialchars($user['kyc_reviewed_by'] ?? 'N/A') ?></p></div>
             </div>
        </div>
        
        <div class="kyc-review-card">
            <h3>Admin KYC Review</h3>
            <?php if (!$user['is_verified']): ?>
                 <p class="alert alert-info">KYC review is only available for users who have verified their email address.</p>
            <?php elseif ($user['kyc_status'] === 'Pending'): ?>
                <div class="system-verified-notice">
                    <i class="fa-solid fa-shield-halved"></i>
                    This submission is awaiting your manual review and approval.
                </div>
                <form action="update_kyc.php" method="POST" class="kyc-review-form">
                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                    <div class="form-group">
                        <label>Update KYC Status</label>
                        <div class="status-selector">
                            <input type="radio" id="kyc-approve" name="kyc_status" value="Approved" required>
                            <label for="kyc-approve"><i class="fa-solid fa-check-circle"></i> Approve</label>
                            
                            <input type="radio" id="kyc-reject" name="kyc_status" value="Rejected" required>
                            <label for="kyc-reject"><i class="fa-solid fa-times-circle"></i> Reject</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="kyc-feedback">Feedback for User (Required for Rejection)</label>
                        <textarea id="kyc-feedback" name="kyc_feedback" placeholder="Provide clear reasons for rejection or a confirmation note. This will be visible to the user."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Review & Notify User</button>
                </form>
            <?php else: ?>
                 <div class="system-verified-notice" style="background-color: #f0f9ff; border-color: #bae6fd; color: #0c4a6e;">
                    <i class="fa-solid fa-info-circle"></i>
                    A review decision has already been made for this user (Status: <?= htmlspecialchars($user['kyc_status']) ?>). To make changes, please use the form below.
                </div>
                 <form action="update_kyc.php" method="POST" class="kyc-review-form" style="margin-top: 20px;">
                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                    <div class="form-group">
                        <label>Update KYC Status</label>
                        <div class="status-selector">
                            <input type="radio" id="kyc-approve-update" name="kyc_status" value="Approved" <?= $user['kyc_status'] == 'Approved' ? 'checked' : '' ?> required>
                            <label for="kyc-approve-update"><i class="fa-solid fa-check-circle"></i> Approve</label>
                            
                            <input type="radio" id="kyc-reject-update" name="kyc_status" value="Rejected" <?= $user['kyc_status'] == 'Rejected' ? 'checked' : '' ?> required>
                            <label for="kyc-reject-update"><i class="fa-solid fa-times-circle"></i> Reject</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="kyc-feedback-update">Feedback for User (Required for Rejection)</label>
                        <textarea id="kyc-feedback-update" name="kyc_feedback" placeholder="Provide clear reasons for rejection or a confirmation note. This will be visible to the user."><?= htmlspecialchars($user['kyc_feedback'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Review & Re-Notify User</button>
                </form>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php
// Include the main footer
require_once __DIR__ . '/templates/footer.php';
?>