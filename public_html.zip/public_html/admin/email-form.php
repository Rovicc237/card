<?php
// Page-specific variables
$page_title = 'Compose Email - Rovicc Admin';
$page_css = ['email-form-professional.css'];
$page_js = ['email-form-logic.js'];

require_once __DIR__ . '/templates/header.php';

$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Compose Email</h1>
            <p>Communicate with your users directly from the dashboard.</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle">
            <i class="fa-solid fa-bars"></i>
        </button>
    </header>

    <section class="settings-section">
        <div class="email-composer-card">
            
            <?php if ($message): ?>
                <div class="alert alert-<?= htmlspecialchars($message_type) ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <div id="form-container">
                <h2>New Message</h2>
                <p>The email will be sent from your configured admin address.</p>

                <form id="email-form" action="email.php" method="POST">
                    <div class="form-group">
                        <label>Choose Recipient(s)</label>
                        <div class="recipient-type-group">
                            <input type="radio" name="recipient_type" id="recipient-all" value="all" checked>
                            <label for="recipient-all"><i class="fa-solid fa-users"></i> All Verified Users</label>
                            
                            <input type="radio" name="recipient_type" id="recipient-specific" value="specific">
                            <label for="recipient-specific"><i class="fa-solid fa-user"></i> Specific User</label>
                        </div>
                    </div>

                    <div class="form-group" id="specific-user-container" style="display: none;">
                        <label for="recipient-search">Find a Specific User</label>
                        <div class="search-container">
                            <i class="fa-solid fa-search search-icon"></i>
                            <input type="text" id="recipient-search" placeholder="Search by name or email..." autocomplete="off">
                            <input type="hidden" name="recipient_specific" id="recipient-email">
                        </div>
                        <div id="search-results"></div>
                        <div id="selected-recipient-display" style="display: none;"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" required placeholder="Enter the email subject">
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" rows="12" required placeholder="Type your message here..."></textarea>
                    </div>

                    <button type="submit" class="btn-primary" id="send-button"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
                </form>
            </div>
            
            <div id="progress-container" style="display: none;">
                <h2 style="margin-bottom: 20px;">Sending Emails...</h2>
                <div class="progress-bar-wrapper">
                    <div class="progress-bar-fill" id="progress-bar-fill"></div>
                    <span id="progress-text">0%</span>
                </div>
                <div id="status-log" class="status-log"></div>
            </div>

        </div>
    </section>
</main>
<?php
// Include the main footer
require_once __DIR__ . '/templates/footer.php';
?>