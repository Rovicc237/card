<?php
// Page-specific variables
$page_title = 'Admin Settings - Rovicc';
$page_css = ['email-form-professional.css'];

require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/../../database/db.php';

$message = $_SESSION['message'] ?? '';
$message_type = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

// --- Fetch all current settings for display ---
try {
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings");
    $all_settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

    // General Settings
    $current_email = $all_settings['notification_email'] ?? '';

    // Card Provider API Settings
    $current_api_key = $all_settings['sudo_api_key'] ?? '';
    $current_base_url = $all_settings['sudo_base_url'] ?? '';
    $current_account_id = $all_settings['sudo_account_id'] ?? '';
    $current_vault_id = $all_settings['sudo_vault_id'] ?? '';
    // --- [NEW] Fetching the new setting ---
    $sudo_funding_source_id = $all_settings['sudo_funding_source_id'] ?? '';
    
    // Exchange Rate Setting
    $current_exchange_rate = $all_settings['usd_to_xaf_rate'] ?? '615';
    
    // Flutterwave Payment Gateway Settings
    $fw_secret_key = $all_settings['flutterwave_secret_key'] ?? '';
    $fw_api_url = $all_settings['flutterwave_api_url'] ?? 'https://api.flutterwave.com/v3/charges?type=mobile_money_franco';

    // Card Pricing Settings
    $visa_creation_fee = $all_settings['visa_creation_fee'] ?? '3600';
    $visa_initial_funding = $all_settings['visa_initial_funding'] ?? '2000';
    $mastercard_creation_fee = $all_settings['mastercard_creation_fee'] ?? '3300';
    $mastercard_initial_funding = $all_settings['mastercard_initial_funding'] ?? '2000';

    // Card Funding Fees
    $card_funding_fixed_fee = $all_settings['card_funding_fixed_fee'] ?? '1.00';
    $card_funding_percentage_fee = $all_settings['card_funding_percentage_fee'] ?? '2.00';
    
    // Referral Commissions
    $referral_bonus_card_creation = $all_settings['referral_bonus_card_creation'] ?? '500';
    $referral_bonus_card_funding = $all_settings['referral_bonus_card_funding'] ?? '0.5';

    // Email SMTP Settings
    $email_settings = [
        'smtp_host' => $all_settings['smtp_host'] ?? '',
        'smtp_port' => $all_settings['smtp_port'] ?? '587',
        'smtp_username' => $all_settings['smtp_username'] ?? '',
        'smtp_password' => $all_settings['smtp_password'] ?? '',
        'smtp_encryption' => $all_settings['smtp_encryption'] ?? 'tls',
        'smtp_from_email' => $all_settings['smtp_from_email'] ?? '',
        'smtp_from_name' => $all_settings['smtp_from_name'] ?? 'Rovicc'
    ];

} catch (PDOException $e) {
    $message = "Database error: Could not fetch settings. Please check the connection.";
    $message_type = "danger";
    error_log("Settings page DB error: " . $e->getMessage());
}

require_once __DIR__ . '/templates/sidebar.php';
?>

<main class="main-content">
    <header class="main-header">
        <div>
            <h1>Settings</h1>
            <p>Manage administrative settings for your application.</p>
        </div>
        <button class="mobile-toggle" id="mobile-toggle"><i class="fa-solid fa-bars"></i></button>
    </header>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>" style="margin-bottom: 20px;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <section class="settings-section" style="max-width: 900px; display: grid; grid-template-columns: 1fr; gap: 30px;">
        
        <div class="email-composer-card">
            <h2>General Settings</h2>
            <form action="processors/update_general_settings.php" method="POST">
                <div class="form-group">
                    <label for="notification_email">Admin Notification Email</label>
                    <input type="email" id="notification_email" name="notification_email" value="<?= htmlspecialchars($current_email) ?>" required>
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-save"></i> Save General Settings</button>
            </form>
        </div>

        <div class="email-composer-card">
            <h2>Currency & Exchange Rate</h2>
            <form action="processors/update_api_settings.php" method="POST">
                <div class="form-group">
                    <label for="usd_to_xaf_rate">USD to XAF Exchange Rate</label>
                    <input type="number" id="usd_to_xaf_rate" name="usd_to_xaf_rate" value="<?= htmlspecialchars($current_exchange_rate) ?>" step="any" required>
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-sync-alt"></i> Update Rate</button>
            </form>
        </div>

        <div class="email-composer-card">
            <h2>Card & Funding Fees</h2>
            <p>Set the fees for card creation and funding.</p>
            <form action="processors/update_api_settings.php" method="POST">
                <h4 style="margin-top: 20px; margin-bottom: 15px; border-bottom: 1px solid var(--border-color); padding-bottom: 10px;">Visa Card</h4>
                <div class="form-group">
                    <label for="visa_creation_fee">Visa Creation Fee (XAF)</label>
                    <input type="number" id="visa_creation_fee" name="visa_creation_fee" value="<?= htmlspecialchars($visa_creation_fee) ?>" required>
                </div>
                <div class="form-group">
                    <label for="visa_initial_funding">Visa Initial Funding (XAF)</label>
                    <input type="number" id="visa_initial_funding" name="visa_initial_funding" value="<?= htmlspecialchars($visa_initial_funding) ?>" required>
                </div>

                <h4 style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid var(--border-color); padding-bottom: 10px;">Mastercard</h4>
                <div class="form-group">
                    <label for="mastercard_creation_fee">Mastercard Creation Fee (XAF)</label>
                    <input type="number" id="mastercard_creation_fee" name="mastercard_creation_fee" value="<?= htmlspecialchars($mastercard_creation_fee) ?>" required>
                </div>
                <div class="form-group">
                    <label for="mastercard_initial_funding">Mastercard Initial Funding (XAF)</label>
                    <input type="number" id="mastercard_initial_funding" name="mastercard_initial_funding" value="<?= htmlspecialchars($mastercard_initial_funding) ?>" required>
                </div>

                <h4 style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid var(--border-color); padding-bottom: 10px;">Card Funding Fees</h4>
                <div class="form-group">
                    <label for="card_funding_fixed_fee">Fixed Funding Fee (USD)</label>
                    <input type="number" id="card_funding_fixed_fee" name="card_funding_fixed_fee" value="<?= htmlspecialchars($card_funding_fixed_fee) ?>" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="card_funding_percentage_fee">Percentage Funding Fee (%)</label>
                    <input type="number" id="card_funding_percentage_fee" name="card_funding_percentage_fee" value="<?= htmlspecialchars($card_funding_percentage_fee) ?>" step="0.01" required>
                </div>

                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-tags"></i> Update Pricing & Fees</button>
            </form>
        </div>
        
     

        <div class="email-composer-card">
            <h2>Payment Gateway (Flutterwave)</h2>
            <form action="processors/update_api_settings.php" method="POST">
                <div class="form-group">
                    <label for="flutterwave_api_url">Flutterwave API URL</label>
                    <input type="url" id="flutterwave_api_url" name="flutterwave_api_url" value="<?= htmlspecialchars($fw_api_url) ?>" required>
                </div>
                <div class="form-group">
                    <label for="flutterwave_secret_key">Flutterwave Secret Key</label>
                    <input type="password" id="flutterwave_secret_key" name="flutterwave_secret_key" placeholder="Enter new key or leave blank to keep existing">
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-key"></i> Save Gateway Settings</button>
            </form>
        </div>
        
        <div class="email-composer-card">
            <h2>Card Provider API (Sudo)</h2>
            <form action="processors/update_api_settings.php" method="POST">
                <div class="form-group">
                    <label for="sudo_base_url">API Base URL</label>
                    <input type="url" id="sudo_base_url" name="sudo_base_url" value="<?= htmlspecialchars($current_base_url) ?>" required>
                </div>
                <div class="form-group">
                    <label for="sudo_account_id">API Debit Account ID</label>
                    <input type="text" id="sudo_account_id" name="sudo_account_id" value="<?= htmlspecialchars($current_account_id) ?>" required>
                </div>
                <div class="form-group">
                    <label for="sudo_vault_id">API Vault ID</label>
                    <input type="text" id="sudo_vault_id" name="sudo_vault_id" value="<?= htmlspecialchars($current_vault_id) ?>" required>
                </div>
                <!-- [NEW FIELD ADDED HERE] -->
                <div class="form-group">
                    <label for="sudo_funding_source_id">API Funding Source ID</label>
                    <input type="text" id="sudo_funding_source_id" name="sudo_funding_source_id" value="<?= htmlspecialchars($sudo_funding_source_id) ?>" required>
                    <small>The funding source used for creating new cards.</small>
                </div>
                <div class="form-group">
                    <label for="sudo_api_key">API Key</label>
                    <textarea id="sudo_api_key" name="sudo_api_key" rows="4" placeholder="Enter new key or leave blank to keep existing"><?= htmlspecialchars($current_api_key) ?></textarea>
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-key"></i> Save API Settings</button>
            </form>
        </div>

        <div class="email-composer-card">
            <h2>Email Sending (SMTP) Settings</h2>
            <form action="processors/update_email_settings.php" method="POST">
                 <div class="form-group">
                    <label for="smtp_from_email">"From" Email Address</label>
                    <input type="email" id="smtp_from_email" name="smtp_from_email" value="<?= htmlspecialchars($email_settings['smtp_from_email']) ?>" required>
                </div>
                 <div class="form-group">
                    <label for="smtp_from_name">"From" Name</label>
                    <input type="text" id="smtp_from_name" name="smtp_from_name" value="<?= htmlspecialchars($email_settings['smtp_from_name']) ?>">
                </div>
                <hr style="margin: 20px 0;">
                <div class="form-group">
                    <label for="smtp_host">SMTP Host</label>
                    <input type="text" id="smtp_host" name="smtp_host" value="<?= htmlspecialchars($email_settings['smtp_host']) ?>" required>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label for="smtp_port">SMTP Port</label>
                        <input type="number" id="smtp_port" name="smtp_port" value="<?= htmlspecialchars($email_settings['smtp_port']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="smtp_encryption">Encryption</label>
                        <select id="smtp_encryption" name="smtp_encryption">
                            <option value="tls" <?= $email_settings['smtp_encryption'] == 'tls' ? 'selected' : '' ?>>TLS</option>
                            <option value="ssl" <?= $email_settings['smtp_encryption'] == 'ssl' ? 'selected' : '' ?>>SSL</option>
                            <option value="none" <?= $email_settings['smtp_encryption'] == 'none' ? 'selected' : '' ?>>None</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="smtp_username">SMTP Username</label>
                    <input type="text" id="smtp_username" name="smtp_username" value="<?= htmlspecialchars($email_settings['smtp_username']) ?>">
                </div>
                <div class="form-group">
                    <label for="smtp_password">SMTP Password</label>
                    <input type="password" id="smtp_password" name="smtp_password" placeholder="Enter new password or leave blank to keep existing">
                </div>
                <button type="submit" class="btn-primary" style="width: auto;"><i class="fa-solid fa-envelope"></i> Save Email Settings</button>
            </form>
        </div>

    </section>
</main>
<?php
require_once __DIR__ . '/templates/footer.php';
?>