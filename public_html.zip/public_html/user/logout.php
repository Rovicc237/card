<?php
// (public_html/user/logout.php)
session_start();

// Check if it's an admin impersonating
if (isset($_SESSION['original_admin_id'])) {
    // If so, redirect to the script that restores the admin session
    header("location: ../admin/return_to_admin.php");
    exit;
}

// Otherwise, perform a normal user logout
// Unset all of the session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to login page
header("location: login.php");
exit;
?>