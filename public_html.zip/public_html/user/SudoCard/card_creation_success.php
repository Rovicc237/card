<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['success_card_details'])) {
    header("Location: create_card.php");
    exit();
}
$card = $_SESSION['success_card_details'];
unset($_SESSION['success_card_details']); // Clean up session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Created Successfully! - Rovicc</title>
    <link rel="stylesheet" href="css/status_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="status-container">
        <div class="status-card">
            <div class="status-icon success"><i class="fas fa-check-circle"></i></div>
            <h1>Card Created Successfully!</h1>
            <p class="status-message">Your new virtual card is now active and ready to use.</p>
            <div class="data-box">
                <h3>Your New Card</h3>
                <ul>
                    <li><strong>Brand:</strong> <?= htmlspecialchars($card['brand']) ?></li>
                    <li><strong>Card Number:</strong> **** **** **** <?= htmlspecialchars($card['last4']) ?></li>
                    <li><strong>Expires:</strong> <?= htmlspecialchars($card['expiryMonth']) ?>/<?= htmlspecialchars($card['expiryYear']) ?></li>
                </ul>
            </div>
            <a href="../dashboard.php" class="btn btn-primary" style="margin-top: 30px;">Go to My Dashboard</a>
        </div>
    </div>
</body>
</html>