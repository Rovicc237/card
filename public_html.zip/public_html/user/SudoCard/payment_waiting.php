<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_GET['tx_ref'])) {
    header("Location: ../login.php");
    exit();
}
$tx_ref = htmlspecialchars($_GET['tx_ref']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Awaiting Payment - Rovicc</title>
    <link rel="stylesheet" href="css/status_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="status-container">
        <div class="status-card">
            <div class="status-icon"><i class="fas fa-spinner fa-spin"></i></div>
            <h1>Awaiting Payment</h1>
            <p class="status-message">Please authorize the payment on your phone. We are waiting for confirmation from your mobile money provider.</p>
            <p>Transaction Reference: <strong><?= $tx_ref ?></strong></p>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const tx_ref = '<?= $tx_ref ?>';
        let pollingInterval;
        let pollingAttempts = 0;
        const maxPollingAttempts = 36; // 36 * 5 seconds = 3 minutes timeout

        function checkPaymentStatus() {
            pollingAttempts++;
            if (pollingAttempts > maxPollingAttempts) {
                clearInterval(pollingInterval);
                window.location.href = `card_creation_failed.php?error=${encodeURIComponent('Payment confirmation timed out.')}`;
                return;
            }

            fetch(`check_card_payment_status.php?tx_ref=${tx_ref}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'SUCCESSFUL') {
                        clearInterval(pollingInterval);
                        // On success, redirect to the card creation script
                        window.location.href = `initiate_card_creation.php?tx_ref=${tx_ref}`;
                    } else if (data.status === 'FAILED') {
                        clearInterval(pollingInterval);
                        // On failure, redirect to the failed page with an error message
                        window.location.href = `card_creation_failed.php?error=${encodeURIComponent(data.message)}`;
                    }
                    // If status is 'PENDING', the interval continues
                })
                .catch(error => {
                    console.error('Polling Error:', error);
                });
        }
        
        // Start polling immediately
        pollingInterval = setInterval(checkPaymentStatus, 5000);
        checkPaymentStatus(); // And check once right away
    });
    </script>
</body>
</html>