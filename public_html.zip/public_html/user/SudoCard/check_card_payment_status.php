<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';
header('Content-Type: application/json');

// --- Tranzak API Helper Functions ---
function generateBearerToken() {
    $appId = 'ap5j1f9uddbea0'; 
    $appKey = 'PROD_C755B1274D1D4E2FB5338B680BE230BD';
    $url = 'https://dsapi.tranzak.me/auth/token';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1, CURLOPT_POSTFIELDS => json_encode(['appId' => $appId, 'appKey' => $appKey]),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) return null;
    curl_close($ch);
    $data = json_decode($response, true);
    return $data['data']['token'] ?? null;
}

function checkTranzakStatus($bearerToken, $requestId) {
    $url = 'https://dsapi.tranzak.me/xp021/v1/request/details?requestId=' . urlencode($requestId);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $bearerToken]
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) return null;
    curl_close($ch);
    return json_decode($response, true);
}


// =================================================================================
// MAIN STATUS CHECKING LOGIC
// =================================================================================
if (!isset($_SESSION['user_id']) || !isset($_GET['tx_ref'])) {
    echo json_encode(['status' => 'FAILED', 'message' => 'Authentication error.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$tx_ref = $_GET['tx_ref'];

try {
    $stmt_local = $pdo->prepare("SELECT * FROM transactions WHERE tx_ref = ? AND user_id = ?");
    $stmt_local->execute([$tx_ref, $user_id]);
    $transaction = $stmt_local->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        throw new Exception("Transaction not found.");
    }

    // If already successful, no need to check again.
    if ($transaction['status'] === 'payment_successful' || $transaction['status'] === 'completed') {
        echo json_encode(['status' => 'SUCCESSFUL']);
        exit();
    }
    
    if (empty($transaction['gateway_ref'])) {
        throw new Exception("Payment gateway reference is missing.");
    }

    $bearerToken = generateBearerToken();
    if (!$bearerToken) {
        throw new Exception("Could not authenticate with payment gateway.");
    }
    
    $api_result = checkTranzakStatus($bearerToken, $transaction['gateway_ref']);

    if (isset($api_result['success']) && $api_result['success'] === true) {
        $tranzak_status = $api_result['data']['status'] ?? 'UNKNOWN';

        if ($tranzak_status === 'SUCCESSFUL') {
            // Update our local status to 'payment_successful'
            $stmt_update_tx = $pdo->prepare("UPDATE transactions SET status = 'payment_successful', gateway_response = ? WHERE tx_ref = ? AND status = 'pending'");
            $stmt_update_tx->execute([json_encode($api_result['data']), $tx_ref]);
            echo json_encode(['status' => 'SUCCESSFUL']);
            
        } elseif (in_array($tranzak_status, ['FAILED', 'CANCELLED', 'EXPIRED'])) {
            $stmt_fail = $pdo->prepare("UPDATE transactions SET status = 'failed', gateway_response = ? WHERE tx_ref = ?");
            $stmt_fail->execute([json_encode($api_result['data']), $tx_ref]);
            echo json_encode(['status' => 'FAILED', 'message' => 'Payment was ' . strtolower($tranzak_status) . '.']);

        } else { // PENDING
            echo json_encode(['status' => 'PENDING']);
        }
    } else {
        // API call to Tranzak failed or returned an error
        echo json_encode(['status' => 'PENDING', 'message' => $api_result['errorMsg'] ?? 'Awaiting confirmation...']);
    }

} catch (Exception $e) {
    error_log("Card Payment Check Error for tx_ref {$tx_ref}: " . $e->getMessage());
    echo json_encode(['status' => 'FAILED', 'message' => 'A system error occurred while verifying the payment.']);
}