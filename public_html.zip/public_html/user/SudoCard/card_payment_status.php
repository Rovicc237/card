<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$tx_ref_for_checking = $_SESSION['tx_ref_for_card_payment'] ?? '';

// We keep the tx_ref in the session until the process is fully complete
// and only unset it upon successful card creation or final failure.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Creation Status - Rovicc</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="css/status_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <main class="main-content" style="padding: 0; display: flex; align-items: center; justify-content: center;">
            <div class="status-container">
                <div class="status-card" id="status-card">
                    
                    <div id="polling-view">
                        <div class="status-icon"><i class="fas fa-spinner fa-spin"></i></div>
                        <h1>Awaiting Payment</h1>
                        <p class="status-message">Please authorize the payment on your phone. We are waiting for confirmation from your mobile money provider.</p>
                    </div>

                    <div id="creating-view" style="display: none;">
                        <div class="status-icon success"><i class="fas fa-check-circle"></i></div>
                        <h1>Payment Confirmed!</h1>
                        <p class="status-message">We are now securely generating your new virtual card. This will only take a moment...</p>
                        <div class="status-icon" style="margin-top: 20px;"><i class="fas fa-cogs fa-spin"></i></div>
                    </div>

                    <div id="success-view" style="display: none;">
                        <div class="status-icon success"><i class="fas fa-check-circle"></i></div>
                        <h1>Card Created Successfully!</h1>
                        <p class="status-message">Your new card is ready. You can manage it from your dashboard.</p>
                        <div class="data-box" id="card-details-box"></div>
                        <a href="../dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                    </div>

                    <div id="error-view" style="display: none;">
                        <div class="status-icon error"><i class="fas fa-times-circle"></i></div>
                        <h1 id="error-title">Process Failed</h1>
                        <div class="data-box">
                            <h3>Error Details</h3>
                            <pre id="error-details"></pre>
                        </div>
                        <a href="create_card.php" class="btn btn-primary">Try Again</a>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const tx_ref = '<?= $tx_ref_for_checking ?>';
        if (!tx_ref) {
            showError('Invalid Session', 'No transaction reference found. Please start the process again.');
            return;
        }

        let pollingInterval;
        let pollingAttempts = 0;
        const maxPollingAttempts = 36; // 36 * 5 seconds = 3 minutes timeout

        // Start polling for payment status immediately
        pollingInterval = setInterval(checkPaymentStatus, 5000);
        checkPaymentStatus(); // Check once right away

        function checkPaymentStatus() {
            pollingAttempts++;
            if (pollingAttempts > maxPollingAttempts) {
                clearInterval(pollingInterval);
                showError('Payment Timed Out', 'We did not receive a payment confirmation in time. Please check your transaction history or try again.');
                return;
            }

            fetch(`check_card_payment_status.php?tx_ref=${tx_ref}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'SUCCESSFUL') {
                        clearInterval(pollingInterval);
                        startCardCreation();
                    } else if (data.status === 'FAILED') {
                        clearInterval(pollingInterval);
                        showError('Payment Failed', data.message || 'The payment failed or was canceled by your provider.');
                    }
                    // If status is PENDING, the interval will just continue.
                })
                .catch(error => {
                    console.error('Polling Error:', error);
                    // Don't stop polling on a single network error, but you could add a counter for consecutive errors
                });
        }

        function startCardCreation() {
            // Update UI to show that creation is in progress
            document.getElementById('polling-view').style.display = 'none';
            document.getElementById('creating-view').style.display = 'block';

            // Make the call to the unified creation script
            fetch('initiate_card_creation.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `tx_ref=${tx_ref}`
            })
            .then(response => response.json())
            .then(data => {
                // Hide the "creating" view
                document.getElementById('creating-view').style.display = 'none';

                if (data.success) {
                    showSuccess(data.card);
                } else {
                    showError('Card Creation Failed', data.message);
                }
            })
            .catch(error => {
                console.error('Creation Error:', error);
                showError('Critical Error', 'A network error occurred during the final step. Please contact support and provide this reference: ' + tx_ref);
            });
        }

        function showSuccess(card) {
            const cardDetailsHtml = `
                <ul>
                    <li><strong>Brand:</strong> ${card.brand}</li>
                    <li><strong>Last 4 Digits:</strong> **** **** **** ${card.last4}</li>
                    <li><strong>Expires:</strong> ${card.expiryMonth}/${card.expiryYear}</li>
                </ul>
            `;
            document.getElementById('card-details-box').innerHTML = cardDetailsHtml;
            document.getElementById('success-view').style.display = 'block';
        }

        function showError(title, message) {
            document.getElementById('polling-view').style.display = 'none';
            document.getElementById('creating-view').style.display = 'none';
            document.getElementById('error-title').textContent = title;
            document.getElementById('error-details').textContent = message;
            document.getElementById('error-view').style.display = 'block';
        }
    });
    </script>
</body>
</html>