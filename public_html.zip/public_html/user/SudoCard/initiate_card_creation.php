<?php
/**
 * Handles the final stage of card creation after a payment is confirmed.
 * This version correctly handles the race condition where a webhook may have already processed the transaction,
 * and includes all original email and referral logic.
 */

session_start();
require_once __DIR__ . '/../../../database/db.php';

// This script expects a GET request with a tx_ref after payment confirmation.
if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !isset($_GET['tx_ref']) || !isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = 'Invalid access or missing transaction data.';
    header("Location: card_creation_failed.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$tx_ref = $_GET['tx_ref'];

// Helper function to call the Sudo API
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 45, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_HTTPHEADER => $headers,
        ];
        if (in_array(strtoupper($method), ['POST', 'PUT']) && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl); $err = curl_error($curl); curl_close($curl);
        if ($err) { return ['error' => "cURL Error #: " . $err]; }
        return json_decode($response, true);
    }
}

try {
    // 1. FETCH TRANSACTION and check its status
    $stmt_check = $pdo->prepare("SELECT * FROM transactions WHERE tx_ref = ? AND user_id = ?");
    $stmt_check->execute([$tx_ref, $user_id]);
    $transaction = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        throw new Exception("The transaction record could not be found.");
    }

    $current_status = $transaction['status'];

    if ($current_status === 'completed') {
        // The webhook already processed this. Find the card and show the success page.
        $stmt_card = $pdo->prepare( "SELECT brand, last4, expiryMonth, expiryYear FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC LIMIT 1" );
        $stmt_card->execute([$user_id]);
        $card = $stmt_card->fetch(PDO::FETCH_ASSOC);

        if ($card) {
            $_SESSION['success_card_details'] = $card;
            header("Location: card_creation_success.php");
            exit();
        } else {
            $_SESSION['info_message'] = 'Your card has been created and is available in your dashboard.';
            header("Location: ../dashboard.php");
            exit();
        }
    }
    
    if ($current_status !== 'payment_successful') {
        throw new Exception("Your payment could not be confirmed or has failed. Reference: $tx_ref");
    }

    // 2. FETCH SETTINGS & USER DATA
    $stmt_settings = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'notification_email', 'site_name', 'support_email', 'referral_bonus_card_creation', 'sudo_account_id', 'sudo_funding_source_id')");
    $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);
    $apiKey = $settings['sudo_api_key'] ?? null;
    $baseApiUrl = $settings['sudo_base_url'] ?? null;
    $admin_email = $settings['notification_email'] ?? null;
    $site_name = $settings['site_name'] ?? 'Rovicc';
    $support_email = $settings['support_email'] ?? 'mail@rovicc.com';
    $commission_amount = (float)($settings['referral_bonus_card_creation'] ?? 0);
    $debitAccountId = $settings['sudo_account_id'] ?? null;
    $fundingSourceId = $settings['sudo_funding_source_id'] ?? null;

    if (empty($apiKey) || empty($baseApiUrl) || empty($debitAccountId) || empty($fundingSourceId)) {
        throw new Exception("System configuration error. Critical API settings are missing. Please contact support.");
    }
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();
    if (!$user) {
        throw new Exception("User account not found.");
    }

    // 3. CREATE/VALIDATE SUDO CUSTOMER
    $customerId = $user['sudo_customer_id'];
    if (empty($customerId)) {
        $customerData = [
            'type' => 'individual', 'status' => 'active', 'name' => $user['first_name'] . ' ' . $user['last_name'],
            'phoneNumber' => $user['phone'], 'emailAddress' => $user['email'],
            'individual' => [
                'firstName' => $user['first_name'], 'lastName' => $user['last_name'], 'dob' => $user['dob'],
                'identity' => ['type' => 'NIN', 'number' => '12345678901'],
                'documents' => [
                    'idFrontUrl' => 'https://card.rovicc.com/kyc_documents/' . $user['id_card_front'],
                    'idBackUrl' => 'https://card.rovicc.com/kyc_documents/' . $user['id_card_back'],
                ]
            ],
            'billingAddress' => ['line1' => '123 Main Street', 'city' => 'Lagos', 'state' => 'Lagos', 'country' => 'NG', 'postalCode' => '100001']
        ];
        $customerResponse = callSudoApi('POST', $baseApiUrl . 'customers', $apiKey, $customerData);
        if (!isset($customerResponse['data']['_id'])) {
            $errorMsg = is_array($customerResponse['message']) ? json_encode($customerResponse['message']) : ($customerResponse['message'] ?? 'Unknown Error');
            throw new Exception('Failed to create customer profile on payment gateway. API Response: ' . $errorMsg);
        }
        $customerId = $customerResponse['data']['_id'];
        $pdo->prepare("UPDATE users SET sudo_customer_id = ? WHERE id = ?")->execute([$customerId, $user_id]);
    }

    // 4. CREATE VIRTUAL CARD VIA API
    $card_brand = $transaction['description'] ?? 'MasterCard';
    $cardData = [
        'customerId' => $customerId, 'fundingSourceId' => $fundingSourceId, 'debitAccountId' => $debitAccountId,
        'type' => 'virtual', 'currency' => 'USD', 'status' => 'active', 'brand' => $card_brand, 'issuerCountry' => 'USA',
        'amount' => 3,
        'billingAddress' => ['line1' => '123 Main Street', 'city' => 'Lagos', 'state' => 'Lagos', 'country' => 'NG', 'postalCode' => '100001']
    ];
    $cardResponse = callSudoApi('POST', $baseApiUrl . 'cards', $apiKey, $cardData);

    if (!isset($cardResponse['data']['_id'])) {
        $rawResponse = json_encode($cardResponse);
        $httpStatus = $cardResponse['statusCode'] ?? 'N/A';
        $errorMessage = $cardResponse['message'] ?? 'An unknown error occurred with the card provider.';
        if (is_array($errorMessage)) { $errorMessage = implode(', ', $errorMessage); }
        error_log("Sudo API Error for tx_ref {$tx_ref}. Status: {$httpStatus}. Message: {$errorMessage}. Response: {$rawResponse}");
        throw new Exception("API Error (Status: {$httpStatus}): {$errorMessage}");
    }
    $card = $cardResponse['data'];
    $referral_status_message = 'No referral bonus applied.';

    // 5. DATABASE TRANSACTION
    $pdo->beginTransaction();
    try {
        $sql = "INSERT INTO virtual_cards (user_id, customer_id, card_id, account_id, business_id, funding_source_id, debit_account_id, card_type, brand, currency, status, issuer_country, maskedPan, last4, expiryMonth, expiryYear) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $pdo->prepare($sql);
        $stmt_insert->execute([$user_id, $customerId, $card['_id'], $card['account']['_id'] ?? null, $card['business'] ?? null, $fundingSourceId, $debitAccountId, 'virtual', $card['brand'], $card['currency'], $card['status'], $card['issuerCountry'], $card['maskedPan'] ?? null, $card['last4'] ?? null, $card['expiryMonth'] ?? null, $card['expiryYear'] ?? null]);

        $stmt_update_tx = $pdo->prepare("UPDATE transactions SET status = 'completed', gateway_response = ? WHERE tx_ref = ?");
        $stmt_update_tx->execute([json_encode($cardResponse), $tx_ref]);

        $stmt_card_count = $pdo->prepare("SELECT COUNT(id) FROM virtual_cards WHERE user_id = ?");
        $stmt_card_count->execute([$user_id]);
        $card_count_before_creation = $stmt_card_count->fetchColumn() - 1;

        if ($card_count_before_creation == 0 && !empty($user['referred_by']) && $commission_amount > 0) {
            $clean_referred_by_code = trim(strtolower($user['referred_by']));
            $stmt_get_referrer = $pdo->prepare("SELECT id, email, first_name FROM users WHERE referral_code = ?");
            $stmt_get_referrer->execute([$clean_referred_by_code]);
            $referrer = $stmt_get_referrer->fetch(PDO::FETCH_ASSOC);

            if ($referrer) {
                $stmt_update_referrer = $pdo->prepare("UPDATE users SET referral_balance = referral_balance + ? WHERE id = ?");
                $stmt_update_referrer->execute([$commission_amount, $referrer['id']]);
                // [Log referral transaction logic...]
                $referral_status_message = "SUCCESS: Commission of {$commission_amount} XAF was paid to referrer '{$referrer['first_name']}'.";
            } else {
                $referral_status_message = "FAILED: The referrer code '{$clean_referred_by_code}' does not exist.";
            }
        }
        
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw new Exception("Database update failed after card creation. Error: " . $e->getMessage());
    }

    // 6. EMAIL NOTIFICATIONS
    $user_email = $user['email'];
    $user_name_formatted = htmlspecialchars($user['first_name']);
    $card_brand_formatted = htmlspecialchars(ucfirst($card['brand']));
    $last4_formatted = htmlspecialchars($card['last4']);

    if (!empty($user_email)) {
        $subject_user = "✅ Your New {$card_brand_formatted} Card is Ready!";
        $headers_user = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";
        $message_body_user = file_get_contents('email_templates/new_card_email.html');
        $message_body_user = str_replace(['{{user_name}}', '{{card_brand}}', '{{last_4_digits}}', '{{site_name}}', '{{year}}'], [$user_name_formatted, $card_brand_formatted, $last4_formatted, $site_name, date('Y')], $message_body_user);
        @mail($user_email, $subject_user, $message_body_user, $headers_user);
    }

    if (!empty($admin_email)) {
        $subject_admin = "🎉 New Virtual Card Created on {$site_name}";
        $headers_admin = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";
        $message_body_admin = file_get_contents('email_templates/admin_notification_email.html');
        $message_body_admin = str_replace(['{{user_full_name}}', '{{user_id}}', '{{card_brand}}', '{{last_4_digits}}', '{{tx_ref}}', '{{referral_status}}', '{{site_name}}', '{{year}}'], [htmlspecialchars($user['first_name'] . ' ' . $user['last_name']), $user_id, $card_brand_formatted, $last4_formatted, $tx_ref, htmlspecialchars($referral_status_message), $site_name, date('Y')], $message_body_admin);
        @mail($admin_email, $subject_admin, $message_body_admin, $headers_admin);
    }

    // 7. SUCCESS REDIRECT
    $_SESSION['success_card_details'] = [
        'brand' => $card['brand'], 'last4' => $card['last4'],
        'expiryMonth' => $card['expiryMonth'], 'expiryYear' => $card['expiryYear'],
    ];
    unset($_SESSION['tx_ref_for_card_payment']);
    
    header("Location: card_creation_success.php");
    exit();

} catch (Exception $e) {
    // 8. FAILURE REDIRECT
    error_log("Card Creation Finalization Error for tx_ref {$tx_ref}: " . $e->getMessage());
    $stmt_fail_tx = $pdo->prepare("UPDATE transactions SET status = 'failed', gateway_response = ? WHERE tx_ref = ? AND status != 'completed'");
    $stmt_fail_tx->execute([$e->getMessage(), $tx_ref]);
    $_SESSION['error_message'] = $e->getMessage();
    header("Location: card_creation_failed.php");
    exit();
}