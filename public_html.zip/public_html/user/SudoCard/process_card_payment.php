<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// --- Tranzak API Helper Functions ---
function generateBearerToken() {
    $appId = 'ap5j1f9uddbea0'; // Your Tranzak App ID
    $appKey = 'PROD_C755B1274D1D4E2FB5338B680BE230BD'; // Your Tranzak App Key
    $url = 'https://dsapi.tranzak.me/auth/token';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1, CURLOPT_POSTFIELDS => json_encode(['appId' => $appId, 'appKey' => $appKey]),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) throw new Exception('API Token cURL Error: '.curl_error($ch));
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode($response, true);
    if ($httpCode !== 200 || !($data['success']??false) || empty($data['data']['token'])) {
        throw new Exception('Failed to generate Tranzak API token.');
    }
    return $data['data']['token'];
}

function createMobileMoneyCharge($bearerToken, $payload) {
    $url = 'https://dsapi.tranzak.me/xp021/v1/request/create-mobile-wallet-charge';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1, CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer '.$bearerToken]
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) throw new Exception('API Charge cURL Error: '.curl_error($ch));
    curl_close($ch);
    return json_decode($response, true);
}

// --- NEW HELPER FUNCTION TO FORMAT PHONE NUMBER ---
function formatPhoneNumber($number) {
    // Remove common characters like +, spaces, etc.
    $number = preg_replace('/[\s+]/', '', $number);
    // Check if the number already starts with 237
    if (substr($number, 0, 3) === '237') {
        return $number; // It's already in the correct format
    }
    // Otherwise, prepend 237
    return '237' . $number;
}


// =================================================================================
// MAIN PROCESSING LOGIC
// =================================================================================
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$card_brand = $_POST['card_brand'];
$amount_xaf = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
$phone_number_raw = filter_input(INPUT_POST, 'phone_number', FILTER_SANITIZE_STRING);

// --- USE THE NEW FORMATTING FUNCTION ---
$phone_number_formatted = formatPhoneNumber($phone_number_raw);

if (!$card_brand || !$amount_xaf || !$phone_number_formatted) {
    $_SESSION['error_message'] = 'Invalid card creation request. Please fill all fields.';
    header("Location: card_creation_failed.php");
    exit();
}

try {
    $pdo->beginTransaction();

    $stmt_rate = $pdo->prepare("SELECT setting_value FROM api_settings WHERE setting_key = 'usd_to_xaf_rate'");
    $stmt_rate->execute();
    $usd_to_xaf_rate = floatval($stmt_rate->fetchColumn() ?: 615);
    $amount_usd = $usd_to_xaf_rate > 0 ? round($amount_xaf / $usd_to_xaf_rate, 2) : 0;

    $tx_ref = "ROVICC-CARD-" . $user_id . "-" . time();

    // Log the initial transaction attempt
    $sql_log = "INSERT INTO transactions (user_id, tx_ref, amount_usd, amount_xaf, status, payment_gateway, type, description) VALUES (?, ?, ?, ?, 'pending', 'tranzak', 'card_creation', ?)";
    $stmt_log = $pdo->prepare($sql_log);
    $stmt_log->execute([$user_id, $tx_ref, $amount_usd, $amount_xaf, $card_brand]);
    $transaction_id = $pdo->lastInsertId();

    // Call Tranzak API
    $bearerToken = generateBearerToken();
    $payload = [
        'amount' => $amount_xaf,
        'currencyCode' => "XAF",
        'description' => "Payment for Rovicc Virtual Card",
        'mchTransactionRef' => $tx_ref,
        'mobileWalletNumber' => $phone_number_formatted, // Use the formatted number
        'returnUrl' => "https://card.rovicc.com/user/SudoCard/create_card.php" // A neutral return URL
    ];
    $api_response = createMobileMoneyCharge($bearerToken, $payload);

    if (isset($api_response['success']) && $api_response['success'] === true && !empty($api_response['data']['requestId'])) {
        $requestId = $api_response['data']['requestId'];
        
        // Store the gateway reference ID for status checking
        $stmt_update = $pdo->prepare("UPDATE transactions SET gateway_ref = ? WHERE id = ?");
        $stmt_update->execute([$requestId, $transaction_id]);

        $pdo->commit();

        // Redirect to the universal waiting page
        header("Location: payment_waiting.php?tx_ref=" . $tx_ref);
        exit();

    } else {
        throw new Exception($api_response['errorMsg'] ?? 'The payment gateway declined the request.');
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Card Payment Initiation Error: " . $e->getMessage());
    $_SESSION['error_message'] = $e->getMessage();
    header("Location: card_creation_failed.php");
    exit();
}