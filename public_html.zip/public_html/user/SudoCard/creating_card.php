<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get the transaction reference from the session, which was set upon successful payment
$tx_ref = $_SESSION['tx_ref_for_card_payment'] ?? '';
if (empty($tx_ref)) {
    // If there's no tx_ref, they shouldn't be here.
    header("Location: create_card.php");
    exit();
}
// Unset the session variable so this page can't be reloaded with the same ref
unset($_SESSION['tx_ref_for_card_payment']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creating Your Virtual Card - Rovicc</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="css/status_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar can be included here if desired -->
        <main class="main-content" style="padding: 0; display: flex; align-items: center; justify-content: center;">
            <div class="status-container">
                <div class="status-card" id="status-card">
                    
                    <!-- Initial State: In Progress -->
                    <div id="progress-view">
                        <div class="status-icon"><i class="fas fa-cogs fa-spin"></i></div>
                        <h1>Creating Your Card</h1>
                        <p class="status-message">Your payment was successful! We are now securely generating your new virtual card. Please do not close this window.</p>
                    </div>

                    <!-- Success State: Loaded via JS -->
                    <div id="success-view" style="display: none;">
                        <div class="status-icon success"><i class="fas fa-check-circle"></i></div>
                        <h1>Card Created Successfully!</h1>
                        <p class="status-message" id="success-message"></p>
                        <div class="data-box" id="card-details-box"></div>
                        <a href="../dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                    </div>

                    <!-- Error State: Loaded via JS -->
                    <div id="error-view" style="display: none;">
                        <div class="status-icon error"><i class="fas fa-times-circle"></i></div>
                        <h1>Creation Failed</h1>
                        <p class="status-message">We're sorry, but we encountered an issue while creating your card.</p>
                        <div class="data-box">
                            <h3>Error Details</h3>
                            <pre id="error-details"></pre>
                        </div>
                        <a href="create_card.php" class="btn btn-primary">Try Again</a>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const tx_ref = '<?= $tx_ref ?>';

        // This function is called immediately to start the card creation process
        function createCard() {
            fetch('initiate_card_creation.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `tx_ref=${tx_ref}`
            })
            .then(response => response.json())
            .then(data => {
                // Hide the progress view
                document.getElementById('progress-view').style.display = 'none';

                if (data.success) {
                    // Show success view
                    document.getElementById('success-message').textContent = data.message;
                    const cardDetailsHtml = `
                        <ul>
                            <li><strong>Brand:</strong> ${data.card.brand}</li>
                            <li><strong>Last 4 Digits:</strong> **** **** **** ${data.card.last4}</li>
                            <li><strong>Expires:</strong> ${data.card.expiryMonth}/${data.card.expiryYear}</li>
                            <li><strong>Status:</strong> ${data.card.status}</li>
                        </ul>
                        <p style="text-align: center; margin-top: 20px;">You can now manage your card from the 'My Cards' section.</p>
                    `;
                    document.getElementById('card-details-box').innerHTML = cardDetailsHtml;
                    document.getElementById('success-view').style.display = 'block';
                } else {
                    // Show error view
                    document.getElementById('error-details').textContent = data.message;
                    document.getElementById('error-view').style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Creation Error:', error);
                document.getElementById('progress-view').style.display = 'none';
                document.getElementById('error-details').textContent = 'A critical network error occurred. Please check your connection and contact support if the problem persists.';
                document.getElementById('error-view').style.display = 'block';
            });
        }

        // Start the process
        createCard();
    });
    </script>
</body>
</html>
