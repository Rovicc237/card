<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

try {
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();

    if (!$user) {
        session_destroy();
        header("Location: ../login.php");
        exit();
    }
    
    // Fetch all card pricing settings from the database
    $stmt_prices = $pdo->query("SELECT setting_key, setting_value FROM api_settings 
                              WHERE setting_key IN ('visa_creation_fee', 'visa_initial_funding', 
                                                    'mastercard_creation_fee', 'mastercard_initial_funding')");
    $prices = $stmt_prices->fetchAll(PDO::FETCH_KEY_PAIR);

    $visa_creation_fee = $prices['visa_creation_fee'] ?? 3600;
    $visa_initial_funding = $prices['visa_initial_funding'] ?? 2000;
    $visa_total = $visa_creation_fee + $visa_initial_funding;

    $mastercard_creation_fee = $prices['mastercard_creation_fee'] ?? 3300;
    $mastercard_initial_funding = $prices['mastercard_initial_funding'] ?? 2000;
    $mastercard_total = $mastercard_creation_fee + $mastercard_initial_funding;

} catch (PDOException $e) {
    die("Database error: Could not fetch card pricing information.");
}

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Virtual Card - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="../dashboard.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../dashboard.php" class="<?= ($current_page == 'dashboard.php') ? 'active' : '' ?>"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="create_card.php" class="<?= (in_array($current_page, ['create_card.php', 'payment_page.php', 'card_payment_status.php'])) ? 'active' : '' ?>"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="../deposit/deposit.php" class="<?= ($current_page == 'deposit.php') ? 'active' : '' ?>"><i class="fa-solid fa-money-bill-transfer"></i> Deposit</a></li>
                    <li><a href="../deposit_history.php" class="<?= ($current_page == 'deposit_history.php') ? 'active' : '' ?>"><i class="fa-solid fa-clock-rotate-left"></i> Deposit History</a></li>
                    <li><a href="../transactions.php" class="<?= ($current_page == 'transactions.php') ? 'active' : '' ?>"><i class="fa-solid fa-receipt"></i> Card Transactions</a></li>
                  
                
                    <li><a href="../referral.php" class="<?= ($current_page == 'referral.php') ? 'active' : '' ?>"><i class="fa-solid fa-users"></i> Referrals</a></li>
                    <li><a href="#"><i class="fa-solid fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <ul>
                    <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Create New Virtual Card</h1>
                    <p>Select a card type to generate your new virtual card.</p>
                </div>
                <a href="../dashboard.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <section class="card-selection-container">
                <div class="card-option visa-card">
                    <form action="payment_page.php" method="POST" style="display: contents;">
                        <input type="hidden" name="card_brand" value="Visa">
                        <input type="hidden" name="amount" value="<?= $visa_total ?>">
                        
                        <div>
                            <div class="card-brand"><i class="fab fa-cc-visa"></i><span>Visa</span></div>
                            <p>Widely accepted, secure, and reliable for all your online purchases.</p>
                        </div>
                        <div>
                            <div class="card-details">
                                <div class="detail-item"><span class="detail-label">Creation Fee</span><span class="detail-value"><?= number_format($visa_creation_fee) ?> XAF</span></div>
                                <div class="detail-item"><span class="detail-label">Initial Funding</span><span class="detail-value"><?= number_format($visa_initial_funding) ?> XAF</span></div>
                                <div class="detail-item"><span class="detail-label">Total</span><span class="total-value"><?= number_format($visa_total) ?> XAF</span></div>
                            </div>
                            <button type="submit" class="create-card-btn">Select Visa Card <i class="fa-solid fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>

                <div class="card-option mastercard-card">
                     <form action="payment_page.php" method="POST" style="display: contents;">
                        <input type="hidden" name="card_brand" value="MasterCard">
                        <input type="hidden" name="amount" value="<?= $mastercard_total ?>">
                        
                        <div>
                            <div class="card-brand">
                                <svg class="mastercard-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 78 48">
                                    <circle fill="#EB001B" cx="24" cy="24" r="24"/><circle fill="#F79E1B" cx="54" cy="24" r="24" opacity=".95"/>
                                </svg>
                                <span>Mastercard</span>
                            </div>
                            <p>Globally recognized with robust security features for peace of mind.</p>
                        </div>
                        <div>
                            <div class="card-details">
                                <div class="detail-item"><span class="detail-label">Creation Fee</span><span class="detail-value"><?= number_format($mastercard_creation_fee) ?> XAF</span></div>
                                <div class="detail-item"><span class="detail-label">Initial Funding</span><span class="detail-value"><?= number_format($mastercard_initial_funding) ?> XAF</span></div>
                                <div class="detail-item"><span class="detail-label">Total</span><span class="total-value"><?= number_format($mastercard_total) ?> XAF</span></div>
                            </div>
                            <button type="submit" class="create-card-btn">Select Mastercard <i class="fa-solid fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
            </section>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>