<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$error_message = 'An unknown error occurred. Please contact support.';
if (isset($_GET['error'])) {
    $error_message = htmlspecialchars($_GET['error']);
} elseif (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clean up session
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Creation Failed - Rovicc</title>
    <link rel="stylesheet" href="css/status_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="status-container">
        <div class="status-card error">
            <div class="status-icon error"><i class="fas fa-times-circle"></i></div>
            <h1>Process Failed</h1>
            <p class="status-message">We're sorry, but we were unable to create your card at this time.</p>
            <div class="data-box">
                <h3>Error Details</h3>
                <pre><?= $error_message ?></pre>
            </div>
            <a href="create_card.php" class="btn btn-primary" style="margin-top: 30px;">Try Again</a>
        </div>
    </div>
</body>
</html>