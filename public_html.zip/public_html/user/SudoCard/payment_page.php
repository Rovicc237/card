<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: create_card.php");
    exit();
}

$card_brand = $_POST['card_brand'];
$amount = $_POST['amount'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Payment - Rovicc</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="../deposit/css/deposit.css"> 
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><a href="../dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="create_card.php" class="active"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="../transactions.php"><i class="fa-solid fa-receipt"></i> Transactions</a></li>
                    <li><a href="../referral.php"><i class="fa-solid fa-users"></i> Referrals</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>

        <main class="main-content">
            <header class="main-header">
                <div class="header-title">
                    <h1>Confirm Your Purchase</h1>
                    <p>Enter your payment details to create your <?= htmlspecialchars($card_brand) ?> card.</p>
                </div>
            </header>

            <section class="deposit-section">
                <div class="deposit-form-container">
                    <div class="xaf-display">
                        <label>You are about to pay</label>
                        <div id="xaf-amount-display"><?= number_format($amount) ?> XAF</div>
                    </div>
                    <form action="process_card_payment.php" method="POST">
                        <input type="hidden" name="card_brand" value="<?= htmlspecialchars($card_brand) ?>">
                        <input type="hidden" name="amount" value="<?= htmlspecialchars($amount) ?>">
                        
                        <div class="form-group">
                            <label for="phone_number">Mobile Money Number</label>
                            <input type="tel" id="phone_number" name="phone_number" placeholder="e.g., 676244204" required>
                        </div>
                        <div class="form-group">
                            <label for="network">Network</label>
                            <select id="network" name="network" required>
                                <option value="MTN">MTN</option>
                                <option value="ORANGE">Orange</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Pay Now</button>
                    </form>
                </div>
            </section>
        </main>
    </div>
</body>
</html>