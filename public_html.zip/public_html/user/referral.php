<?php
session_start();
// All necessary includes
require_once __DIR__ . '/../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// Fetch user data, including the referral code
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$firstName = htmlspecialchars($user['first_name'] ?? 'User');
$referral_code = htmlspecialchars($user['referral_code']);
// Construct the referral link
$referral_link = "https://rovicc.com/user/signup.php?ref=" . urlencode($referral_code);

// Fetch referred users
$stmt_referred = $pdo->prepare("SELECT first_name, last_name, created_at FROM users WHERE referred_by = ? ORDER BY created_at DESC");
$stmt_referred->execute([$referral_code]);
$referred_users = $stmt_referred->fetchAll();
$referral_count = count($referred_users);

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refer a Friend - Rovicc</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/referral.css">
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
      <?php include 'templates/sidebar.php'; ?>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                </div>
                 <a href="dashboard.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <div class="referral-grid">
                <section class="referral-section">
                    <div class="referral-header">
                        <div class="icon-wrapper">R</div>
                        <h2>Invite Friends, Get Rewards</h2>
                        <p>Share your unique referral code or link with friends. When they sign up, you both get rewarded!</p>
                    </div>

                    <div class="referral-box">
                        <label for="referral-code-input">Your Referral Code</label>
                        <div class="input-group">
                            <input type="text" id="referral-code-input" value="<?= $referral_code ?>" readonly>
                            <button class="copy-btn" data-clipboard-target="#referral-code-input">
                                <i class="fa-solid fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>

                    <div class="referral-box">
                        <label for="referral-link-input">Your Referral Link</label>
                        <div class="input-group">
                            <input type="text" id="referral-link-input" value="<?= $referral_link ?>" readonly>
                            <button class="copy-btn" data-clipboard-target="#referral-link-input">
                                <i class="fa-solid fa-link"></i> Copy
                            </button>
                        </div>
                    </div>
                    
                    <div class="copy-feedback" id="copy-feedback-message"></div>

                    <div class="referral-sharing">
                        <p>Or share directly on:</p>
                        <div class="social-share-buttons">
                            <a href="https://wa.me/?text=<?= urlencode('Join me on Rovicc! Use my referral link to sign up: ' . $referral_link) ?>" target="_blank" class="social-share-btn btn-whatsapp"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($referral_link) ?>" target="_blank" class="social-share-btn btn-facebook"><i class="fa-brands fa-facebook-f"></i> Facebook</a>
                            <a href="https://twitter.com/intent/tweet?text=<?= urlencode('Join me on Rovicc! Use my referral link to sign up: ') ?>&url=<?= urlencode($referral_link) ?>" target="_blank" class="social-share-btn btn-twitter"><i class="fa-brands fa-twitter"></i> Twitter</a>
                        </div>
                    </div>
                </section>
                
                <section class="referral-stats-section">
                    <div class="stats-header">
                        <h3><i class="fa-solid fa-chart-bar"></i> Your Referrals</h3>
                        <div class="stats-count">
                            Total: <span><?= $referral_count ?></span>
                        </div>
                    </div>
                    <div class="referred-users-list">
                        <table>
                            <thead>
                                <tr>
                                    <th>User's Full Name</th>
                                    <th>Date Joined</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($referral_count > 0): ?>
                                    <?php foreach ($referred_users as $referred_user): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($referred_user['first_name'] . ' ' . $referred_user['last_name']) ?></td>
                                            <td><?= date("F j, Y", strtotime($referred_user['created_at'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="2" class="no-referrals">You haven't referred anyone yet!</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </main>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Standard dashboard script for sidebar toggle
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }

        // Clipboard copy functionality
        const copyButtons = document.querySelectorAll('.copy-btn');
        const feedbackMessage = document.getElementById('copy-feedback-message');

        copyButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetSelector = this.getAttribute('data-clipboard-target');
                const targetInput = document.querySelector(targetSelector);

                if (targetInput) {
                    targetInput.select();
                    targetInput.setSelectionRange(0, 99999); // For mobile devices

                    try {
                        document.execCommand('copy');
                        feedbackMessage.textContent = 'Copied to clipboard!';
                        feedbackMessage.classList.add('visible');

                        // Change button text temporarily
                        const originalText = this.innerHTML;
                        this.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';

                        setTimeout(() => {
                            feedbackMessage.classList.remove('visible');
                             this.innerHTML = originalText;
                        }, 2000);
                    } catch (err) {
                        feedbackMessage.textContent = 'Failed to copy!';
                        feedbackMessage.style.color = 'var(--danger)';
                        feedbackMessage.classList.add('visible');
                         setTimeout(() => {
                            feedbackMessage.classList.remove('visible');
                            feedbackMessage.style.color = 'var(--success)';
                        }, 2000);
                    }
                }
            });
        });
    });
    </script>
</body>
</html>