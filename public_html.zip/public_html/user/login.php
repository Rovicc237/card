<?php
session_start();

// If a user is already logged in, redirect them to the dashboard.
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Get any error message from the session and then clear it
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once __DIR__ . '/../../database/db.php';

    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Email and password are required.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // First, verify the password is correct
                if (password_verify($password, $user['password'])) {
                    
                    // Check if the account is disabled
                    if ($user['is_disabled'] == 1) {
                        header("Location: account_disabled.php");
                        exit();
                    }
                    
                    if ($user['is_verified'] == 1) {
                        // All checks passed, start the session
                        session_regenerate_id(true);
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['first_name'] = $user['first_name'];
                        $_SESSION['last_name'] = $user['last_name'];
                        $_SESSION['email'] = $user['email'];
                        
                        header("Location: dashboard.php");
                        exit();
                    } else {
                        // User exists but is not email-verified
                        $_SESSION['signup_email'] = $user['email'];
                        header("Location: check-email.php");
                        exit();
                    }
                } else {
                    // Password is incorrect
                    $_SESSION['error'] = "The password you entered is incorrect. Please try again.";
                }
            } else {
                // No user found with that email address
                $_SESSION['error'] = "No account found with this email address. If you you had an account, please contact us on WhatsApp at +237 676 244 204 with your email address for assistance. Otherwise, you can <a href='signup.php'>create an account</a>.";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "A database error occurred. Please try again later.";
            error_log($e->getMessage());
        }
    }
    // Redirect back to login page to show the error
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rovicc</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
    .whatsapp-help {
        text-align: center;
        margin-top: 20px;
        padding: 15px;
        background-color: #e6f7e9;
        border: 1px solid #c7e8ca;
        border-radius: 8px;
    }
    .whatsapp-help a {
        font-size: 2.5rem;
        color: #25D366;
        text-decoration: none;
        transition: transform 0.2s;
        display: inline-block;
    }
    .whatsapp-help a:hover {
        transform: scale(1.1);
    }
    .whatsapp-help p {
        margin: 10px 0 0;
        color: #386641;
        font-size: 0.9rem;
        line-height: 1.4;
    }
    </style>
</head>
<body class="auth-body">
    <div id="alert-container"></div>
    
    <main class="auth-container">
        <div class="auth-panel">
            <div class="auth-form-side">
                <div class="auth-form-wrapper">
                    <a href="../index.php" class="auth-logo">
                        <span class="logo-icon">R</span>
                        <span>ROVICC</span>
                    </a>
                    <h3>Welcome Back</h3>
                    <p class="auth-sub-text">Please enter your details to sign in.</p>

                    <form action="login.php" method="POST" class="auth-form">
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <div class="input-wrapper">
                                <i class="fa-solid fa-envelope form-icon"></i>
                                <input type="email" id="email" name="email" placeholder="you@example.com" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <div class="input-wrapper">
                                <i class="fa-solid fa-lock form-icon"></i>
                                <input type="password" id="password" name="password" placeholder="••••••••••••" required>
                            </div>
                        </div>
                        <div class="form-options">
                            <div class="form-remember">
                                <input type="checkbox" id="remember" name="remember">
                                <label for="remember">Remember me</label>
                            </div>
                            <a href="forgot-password.php" class="forgot-password">Forgot Password?</a>
                        </div>
                        <button type="submit" class="btn btn-primary btn-large auth-button">Sign In</button>
                    </form>

                    <div class="whatsapp-help">
                        <a href="https://wa.me/237676244204" target="_blank">
                            <i class="fa-brands fa-whatsapp"></i>
                        </a>
                        <p>
                            Used the old system? Contact us on WhatsApp to restore your account.
                        </p>
                    </div>

                    <div class="social-auth-divider">
                        <span>OR</span>
                    </div>
                    <div class="social-auth-buttons">
                        <button class="btn btn-secondary social-btn"><i class="fa-brands fa-google"></i> Sign in with Google</button>
                    </div>
                    <p class="auth-switch-text">Don't have an account? <a href="signup.php">Sign Up</a></p>
                </div>
            </div>
            <div class="auth-image-side">
                <div class="auth-image-content">
                    <h2>Secure Your Digital Wallet</h2>
                    <p>Experience the next generation of financial security and freedom with Rovicc.</p>
                </div>
            </div>
        </div>
    </main>
    <script src="../js/script.js" defer></script>
     <script>
    // This PHP block will inject the session error message into the JavaScript
    <?php if ($error): ?>
    document.addEventListener('DOMContentLoaded', function() {
        showAlert('<?= addslashes($error) ?>', 'error');
    });
    <?php endif; ?>
    </script>
</body>
</html>