<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    exit('Unauthorized');
}

// Get card ID from query parameter
$cardId = $_GET['card_id'] ?? null;
if (!$cardId) {
    header('HTTP/1.1 400 Bad Request');
    exit('Card ID is required');
}

try {
    // Verify the card belongs to the user
    $stmt = $pdo->prepare("SELECT * FROM virtual_cards WHERE card_id = ? AND user_id = ?");
    $stmt->execute([$cardId, $_SESSION['user_id']]);
    $card = $stmt->fetch();

    if (!$card) {
        header('HTTP/1.1 403 Forbidden');
        exit('Card not found or access denied');
    }

    // Get API settings
    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;

    if (!$sudo_api_key || !$sudo_base_url) {
        header('HTTP/1.1 500 Internal Server Error');
        exit('API configuration error');
    }

    // Fetch transactions from Sudo API
    $toDate = date('c');
    $fromDate = date('c', strtotime('-2 years'));
    $page = 0;
    $limit = 1000;

    $queryParams = http_build_query([
        'page' => $page,
        'limit' => $limit,
        'fromDate' => $fromDate,
        'toDate' => $toDate
    ]);
    $requestUrl = rtrim($sudo_base_url, '/') . '/cards/' . $cardId . '/transactions?' . $queryParams;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $requestUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $sudo_api_key,
        "Content-Type: application/json"
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
              <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th class="amount-header">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="4" style="text-align: center; color: var(--danger);">cURL Error: ' . htmlspecialchars($curlError) . '</td></tr>
                    </tbody>
                </table>
              </div>';
        exit();
    }

    if ($httpCode != 200) {
        echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
              <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th class="amount-header">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="4" style="text-align: center; color: var(--danger);">API Error: Received HTTP code ' . $httpCode . '</td></tr>
                    </tbody>
                </table>
              </div>';
        exit();
    }

    $response_data = json_decode($response, true);
    if (!isset($response_data['data'])) {
        echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
              <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th class="amount-header">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="4" style="text-align: center;">No recent transactions found.</td></tr>
                    </tbody>
                </table>
              </div>';
        exit();
    }

    $all_transactions = $response_data['data'];
    usort($all_transactions, function($a, $b) {
        return strtotime($b['createdAt']) - strtotime($a['createdAt']);
    });
    $transactions = array_slice($all_transactions, 0, 5);

    // Generate complete HTML for transactions section
    echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
          <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="amount-header">Amount</th>
                    </tr>
                </thead>
                <tbody>';

    foreach ($transactions as $transaction) {
        $transactionName = $transaction['merchant']['name'] ?? 'N/A';
        $amount = $transaction['amount'] ?? 0;
        $currency = $transaction['currency'] ?? '';
        $formattedAmount = number_format(abs($amount), 2);
        
        $utc_date = $transaction['createdAt'] ?? null;
        $formattedDate = 'N/A';
        if ($utc_date) {
            $date = new DateTime($utc_date);
            $date->setTimezone(new DateTimeZone('Africa/Douala'));
            $formattedDate = $date->format('M j, Y, g:i A');
        }
        $status = $transaction['type'] ?? 'unknown';
        $statusClass = 'status-' . htmlspecialchars(strtolower($status));
        
        $isDebit = $amount < 0;
        $amountClass = $isDebit ? 'amount-debit' : 'amount-credit';
        $amountPrefix = $isDebit ? '-' : '+';
        $iconClass = $isDebit ? 'fa-arrow-down' : 'fa-arrow-up';
        $iconBgColor = $isDebit ? '#fddbde' : '#d1fae5';
        $iconColor = $isDebit ? '#f43f5e' : '#10b981';
        ?>
        <tr>
            <td data-label="Description">
                <div class="desc-cell">
                    <div class="desc-icon" style="background-color: <?= $iconBgColor ?>; color: <?= $iconColor ?>;"><i class="fa-solid <?= $iconClass ?>"></i></div>
                    <span><?= htmlspecialchars($transactionName) ?></span>
                </div>
            </td>
            <td data-label="Date"><?= htmlspecialchars($formattedDate) ?></td>
            <td data-label="Status"><span class="status-pill <?= $statusClass ?>"><?= htmlspecialchars(ucfirst($status)) ?></span></td>
            <td data-label="Amount" class="<?= $amountClass ?>"><?= $amountPrefix ?>$<?= $formattedAmount ?> <?= htmlspecialchars($currency) ?></td>
        </tr>
        <?php
    }

    echo '</tbody>
        </table>
      </div>';

} catch (PDOException $e) {
    error_log("Transaction Fetch Error: " . $e->getMessage());
    echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
          <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="amount-header">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td colspan="4" style="text-align: center; color: var(--danger);">Database error occurred</td></tr>
                </tbody>
            </table>
          </div>';
} catch (Exception $e) {
    error_log("General Error in get_card_transactions: " . $e->getMessage());
    echo '<div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
          <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="amount-header">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td colspan="4" style="text-align: center; color: var(--danger);">An error occurred</td></tr>
                </tbody>
            </table>
          </div>';
}
?>