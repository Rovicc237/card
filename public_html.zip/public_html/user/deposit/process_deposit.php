<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// --- Helper function to generate a Tranzak Bearer Token ---
function generateBearerToken() {
    // For production, consider storing these securely and fetching them from api_settings
    $appId = 'ap5j1f9uddbea0'; // Your Tranzak App ID
    $appKey = 'PROD_C755B1274D1D4E2FB5338B680BE230BD'; // Your Tranzak App Key
    $url = 'https://dsapi.tranzak.me/auth/token';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => json_encode(['appId' => $appId, 'appKey' => $appKey]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    $response = curl_exec($ch);
    if (curl_errno($ch)) throw new Exception('API Token Generation cURL Error: ' . curl_error($ch));
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($response, true);
    if ($httpCode !== 200 || !($data['success'] ?? false) || empty($data['data']['token'])) {
        throw new Exception('Failed to generate Tranzak API token. Response: ' . $response);
    }
    return $data['data']['token'];
}

// --- Helper function to create the mobile money charge ---
function createMobileMoneyCharge($bearerToken, $payload) {
    $url = 'https://dsapi.tranzak.me/xp021/v1/request/create-mobile-wallet-charge';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $bearerToken
        ]
    ]);
    $response = curl_exec($ch);
    if (curl_errno($ch)) throw new Exception('API Charge cURL Error: ' . curl_error($ch));
    curl_close($ch);
    return json_decode($response, true);
}

// --- NEW HELPER FUNCTION TO FORMAT PHONE NUMBER ---
function formatPhoneNumber($number) {
    // Remove common characters like +, spaces, etc.
    $number = preg_replace('/[\s+]/', '', $number);

    // Check if the number already starts with 237
    if (substr($number, 0, 3) === '237') {
        return $number; // It's already in the correct format
    }

    // Otherwise, prepend 237
    return '237' . $number;
}


// =================================================================================
// MAIN DEPOSIT PROCESSING LOGIC
// =================================================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: deposit.php");
    exit();
}

if (!isset($_SESSION['user_id'])) {
    $_SESSION['deposit_feedback'] = ['status' => 'error', 'message' => 'You must be logged in to make a deposit.'];
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$amount_usd = filter_input(INPUT_POST, 'amount_usd', FILTER_VALIDATE_FLOAT);
$phone_number_raw = filter_input(INPUT_POST, 'phone_number', FILTER_SANITIZE_STRING);

// --- USE THE NEW FORMATTING FUNCTION ---
$phone_number_formatted = formatPhoneNumber($phone_number_raw);


if (!$amount_usd || $amount_usd < 1 || !$phone_number_formatted) {
    $_SESSION['deposit_feedback'] = ['status' => 'error', 'message' => 'Please enter a valid amount and phone number.'];
    header("Location: deposit.php");
    exit();
}

try {
    $pdo->beginTransaction();

    $stmt_user = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if (!$user) throw new Exception("User not found.");

    $stmt_rate = $pdo->prepare("SELECT setting_value FROM api_settings WHERE setting_key = 'usd_to_xaf_rate'");
    $stmt_rate->execute();
    $usd_to_xaf_rate = floatval($stmt_rate->fetchColumn() ?: 615);

    $tx_ref = "RVCC-TRZ-" . $user_id . "-" . time();
    $amount_xaf = ceil($amount_usd * $usd_to_xaf_rate);

    $stmt_insert_tx = $pdo->prepare(
        "INSERT INTO transactions (user_id, tx_ref, amount_usd, amount_xaf, status, payment_gateway, type)
         VALUES (?, ?, ?, ?, 'pending', 'tranzak', 'deposit')"
    );
    $stmt_insert_tx->execute([$user_id, $tx_ref, $amount_usd, $amount_xaf]);
    $transaction_id = $pdo->lastInsertId();

    $bearerToken = generateBearerToken();
    $payload = [
        'amount' => $amount_xaf,
        'currencyCode' => "XAF",
        'description' => "Rovicc Account Deposit",
        'mchTransactionRef' => $tx_ref,
        'mobileWalletNumber' => $phone_number_formatted, // Use the formatted number
        'returnUrl' => "https://sandbox.rovicc.com/user/deposit/deposit.php"
    ];
    $api_response = createMobileMoneyCharge($bearerToken, $payload);

    if (isset($api_response['success']) && $api_response['success'] === true && !empty($api_response['data']['requestId'])) {
        $requestId = $api_response['data']['requestId'];

        $stmt_update = $pdo->prepare("UPDATE transactions SET gateway_ref = ? WHERE id = ?");
        $stmt_update->execute([$requestId, $transaction_id]);

        $pdo->commit();

        $_SESSION['deposit_check_data'] = ['tx_ref' => $tx_ref];
        header("Location: deposit.php");
        exit();

    } else {
        throw new Exception($api_response['errorMsg'] ?? 'The payment gateway declined the request. Please check the number and try again.');
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log("Deposit Error for user {$user_id}: " . $e->getMessage());
    $_SESSION['deposit_feedback'] = ['status' => 'error', 'message' => $e->getMessage()];
    header("Location: deposit.php");
    exit();
}