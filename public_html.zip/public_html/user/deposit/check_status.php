<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../../database/db.php';

// --- Helper function to generate a Tranzak Bearer Token ---
function generateBearerToken() {
    $appId = 'ap5j1f9uddbea0'; 
    $appKey = 'PROD_C755B1274D1D4E2FB5338B680BE230BD';
    $url = 'https://dsapi.tranzak.me/auth/token';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => json_encode(['appId' => $appId, 'appKey' => $appKey]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) return null;
    curl_close($ch);
    $data = json_decode($response, true);
    return $data['data']['token'] ?? null;
}

// --- Helper function to check transaction status ---
function checkTranzakStatus($bearerToken, $requestId) {
    $url = 'https://dsapi.tranzak.me/xp021/v1/request/details?requestId=' . urlencode($requestId);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $bearerToken]
    ]);
    $response = curl_exec($ch);
    if(curl_errno($ch)) return null;
    curl_close($ch);
    return json_decode($response, true);
}

// --- Helper function for sending deposit emails ---
function sendDepositEmails($pdo, $user_id, $transaction_details) {
    // Prevent sending duplicate emails
    if ($transaction_details['email_sent'] === 'yes') {
        return;
    }

    try {
        $keys = ['site_name', 'support_email', 'notification_email'];
        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $stmt_settings = $pdo->prepare("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ($placeholders)");
        $stmt_settings->execute($keys);
        $settings = $stmt_settings->fetchAll(PDO::FETCH_KEY_PAIR);

        $stmt_user = $pdo->prepare("SELECT first_name, last_name, email FROM users WHERE id = ?");
        $stmt_user->execute([$user_id]);
        $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

        if (!$user) return;

        $site_name = htmlspecialchars($settings['site_name'] ?? 'Rovicc');
        $support_email = $settings['support_email'] ?? 'mail@rovicc.com';
        $admin_email = $settings['notification_email'] ?? '';
        
        $amount_formatted = number_format($transaction_details['amount_usd'], 2);
        $tx_ref = htmlspecialchars($transaction_details['tx_ref']);
        $date_formatted = date('F j, Y, g:i a');

        // --- Send User Email ---
        $headers_user = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";
        $subject_user = "✅ Deposit Successful - Transaction Receipt";
        $body_user_template = file_get_contents(__DIR__ . '/email_template/deposit_receipt_user.html');
        $body_user = str_replace(['{{first_name}}', '{{amount}}', '{{tx_ref}}', '{{date}}', '{{year}}', '{{site_name}}'], [htmlspecialchars($user['first_name']), $amount_formatted, $tx_ref, $date_formatted, date('Y'), $site_name], $body_user_template);
        @mail($user['email'], $subject_user, $body_user, $headers_user);

        // --- Send Admin Email ---
        if (!empty($admin_email)) {
            $headers_admin = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";
            $subject_admin = "📢 New Deposit Received: \${$amount_formatted}";
            $body_admin_template = file_get_contents(__DIR__ . '/email_template/deposit_receipt_admin.html');
            $body_admin = str_replace(['{{first_name}}', '{{last_name}}', '{{user_id}}', '{{amount}}', '{{tx_ref}}', '{{date}}'], [htmlspecialchars($user['first_name']), htmlspecialchars($user['last_name']), $user_id, $amount_formatted, $tx_ref, $date_formatted], $body_admin_template);
            @mail($admin_email, $subject_admin, $body_admin, $headers_admin);
        }
        
        // Mark email as sent to prevent duplicates
        $stmt_email_sent = $pdo->prepare("UPDATE transactions SET email_sent = 'yes' WHERE id = ?");
        $stmt_email_sent->execute([$transaction_details['id']]);

    } catch (Exception $e) {
        error_log("Email Sending Error for tx_ref {$transaction_details['tx_ref']}: " . $e->getMessage());
    }
}


// =================================================================================
// MAIN STATUS CHECKING LOGIC
// =================================================================================

if (!isset($_SESSION['user_id']) || !isset($_GET['tx_ref'])) {
    echo json_encode(['status' => 'FAILED', 'message' => 'Invalid request session.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$tx_ref = $_GET['tx_ref'];

try {
    $stmt_local = $pdo->prepare("SELECT * FROM transactions WHERE tx_ref = ? AND user_id = ?");
    $stmt_local->execute([$tx_ref, $user_id]);
    $transaction = $stmt_local->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) throw new Exception("Local transaction record not found.");
    if ($transaction['status'] === 'completed') {
        echo json_encode(['status' => 'SUCCESSFUL']);
        exit();
    }
    if (empty($transaction['gateway_ref'])) throw new Exception("Payment gateway reference is missing for this transaction.");

    $bearerToken = generateBearerToken();
    if (!$bearerToken) throw new Exception("Could not authenticate with payment gateway.");
    
    $api_result = checkTranzakStatus($bearerToken, $transaction['gateway_ref']);

    if (isset($api_result['success']) && $api_result['success'] === true) {
        $tranzak_status = $api_result['data']['status'] ?? 'UNKNOWN';

        if ($tranzak_status === 'SUCCESSFUL' && $transaction['status'] === 'pending') {
            $pdo->beginTransaction();
            try {
                // Update user's balance
                $stmt_balance = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $stmt_balance->execute([$transaction['amount_usd'], $user_id]);

                // Update transaction status
                $stmt_update_tx = $pdo->prepare("UPDATE transactions SET status = 'completed', gateway_response = ? WHERE id = ?");
                $stmt_update_tx->execute([json_encode($api_result['data']), $transaction['id']]);
                
                $pdo->commit();

                // --- TRIGGER EMAIL NOTIFICATIONS ---
                // We pass the full transaction details to the function
                sendDepositEmails($pdo, $user_id, $transaction);

                echo json_encode(['status' => 'SUCCESSFUL']);

            } catch (Exception $e) {
                $pdo->rollBack();
                throw new Exception("Database update failed during transaction completion. " . $e->getMessage());
            }

        } elseif (in_array($tranzak_status, ['FAILED', 'CANCELLED', 'EXPIRED'])) {
            $stmt_fail = $pdo->prepare("UPDATE transactions SET status = 'failed', gateway_response = ? WHERE id = ?");
            $stmt_fail->execute([json_encode($api_result['data']), $transaction['id']]);
            echo json_encode(['status' => 'FAILED', 'message' => 'Payment was ' . strtolower($tranzak_status) . '.']);

        } else { // PENDING, PAYMENT_IN_PROGRESS, etc.
            echo json_encode(['status' => 'PENDING']);
        }
    } else {
        throw new Exception($api_result['errorMsg'] ?? 'Could not get transaction status from gateway.');
    }

} catch (Exception $e) {
    error_log("Status Check Error for tx_ref {$tx_ref}: " . $e->getMessage());
    echo json_encode(['status' => 'FAILED', 'message' => 'A system error occurred while verifying the payment.']);
}