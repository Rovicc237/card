<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

try {
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();

    if (!$user) {
        session_destroy();
        header("Location: ../login.php");
        exit();
    }
    
    $stmt_rate = $pdo->prepare("SELECT setting_value FROM api_settings WHERE setting_key = 'usd_to_xaf_rate'");
    $stmt_rate->execute();
    $usd_to_xaf_rate = floatval($stmt_rate->fetchColumn() ?: 615);

} catch (PDOException $e) {
    error_log("Database Error on Deposit Page: " . $e->getMessage());
    die("A critical database error occurred. Please try again later.");
}

$feedback = $_SESSION['deposit_feedback'] ?? null;
unset($_SESSION['deposit_feedback']);

$deposit_check_data = $_SESSION['deposit_check_data'] ?? null;
unset($_SESSION['deposit_check_data']);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Funds - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="css/deposit.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><a href="../dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="../SudoCard/create_card.php"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="deposit.php" class="active"><i class="fa-solid fa-money-bill-transfer"></i> Deposit</a></li>
                    <li><a href="../deposit_history.php"><i class="fa-solid fa-clock-rotate-left"></i> Deposit History</a></li>
                    <li><a href="../transactions.php"><i class="fa-solid fa-receipt"></i> Card Transactions</a></li>
                    <li><a href="../fund_card.php"><i class="fa-solid fa-dollar-sign"></i> Fund Card</a></li>
                    <li><a href="../referral.php"><i class="fa-solid fa-users"></i> Referrals</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Secure Deposit</h1>
                    <p>Fund your Rovicc account via Mobile Money.</p>
                </div>
                <a href="../dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </header>

            <section class="deposit-section">
                <div class="deposit-grid" id="deposit-grid">
                    <div class="deposit-form-container" id="deposit-form-container">
                        <?php if ($feedback): ?>
                            <div class="alert alert-<?= htmlspecialchars($feedback['status']) ?>"><?= htmlspecialchars($feedback['message']) ?></div>
                        <?php endif; ?>
                        
                        <form action="process_deposit.php" method="POST" id="deposit-form">
                            <div class="form-group">
                                <label for="amount_usd">Amount to Deposit (USD)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" id="amount_usd" name="amount_usd" placeholder="e.g., 10.00" min="1" step="0.01" required>
                                </div>
                            </div>
                            <div class="xaf-display">
                                <label>You Will Pay (Approximately)</label>
                                <div id="xaf-amount-display">0 XAF</div>
                            </div>
                            <div class="form-group">
                                <label for="phone_number">Mobile Money Number</label>
                                <input type="tel" id="phone_number" name="phone_number" value="<?= htmlspecialchars($user['phone_number'] ?? '') ?>" placeholder="e.g., 676244204" required>
                            </div>
                            <div class="form-group">
                                <label for="network">Network</label>
                                <select id="network" name="network" required>
                                    <option value="MTN_ORANGE">MTN / Orange</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Initiate Deposit</button>
                        </form>
                    </div>

                    <div class="status-panel" id="status-panel" style="display: none;">
                        <h3>Transaction In Progress</h3>
                        <p>A confirmation prompt has been sent to your phone. Please enter your PIN to authorize the payment.</p>
                        <div class="status-visual">
                            <div class="status-icon" id="status-icon"><i class="fas fa-spinner fa-spin"></i></div>
                        </div>
                        <ul class="status-steps">
                            <li id="step-initiate" class="status-step active"><i class="fas fa-check-circle"></i> Payment Initiated</li>
                            <li id="step-confirm" class="status-step"><i class="fas fa-spinner fa-spin"></i> Awaiting Your Confirmation</li>
                            <li id="step-complete" class="status-step"><i class="fas fa-spinner fa-spin"></i> Finalizing Transaction</li>
                        </ul>
                        <div id="status-message" style="margin-top: 20px; color: #ffc107; font-weight: 500;"></div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const amountUsdInput = document.getElementById('amount_usd');
        const xafAmountDisplay = document.getElementById('xaf-amount-display');
        const usdToXafRate = <?= json_encode(floatval($usd_to_xaf_rate)) ?>;

        amountUsdInput.addEventListener('input', function() {
            const usdAmount = parseFloat(this.value) || 0;
            const xafAmount = Math.ceil(usdAmount * usdToXafRate);
            xafAmountDisplay.textContent = xafAmount.toLocaleString('fr-CM') + ' XAF';
        });

        const depositCheckData = <?= json_encode($deposit_check_data) ?>;
        let pollingInterval;

        if (depositCheckData && depositCheckData.tx_ref) {
            const formContainer = document.getElementById('deposit-form-container');
            const statusPanel = document.getElementById('status-panel');
            const statusIcon = document.getElementById('status-icon');
            const statusMessage = document.getElementById('status-message');
            const steps = {
                confirm: document.getElementById('step-confirm'),
                complete: document.getElementById('step-complete'),
            };

            formContainer.style.display = 'none';
            statusPanel.style.display = 'block';

            function updateStep(stepElement, icon, text) {
                stepElement.classList.add('active');
                stepElement.querySelector('i').className = `fas fa-${icon}`;
                stepElement.childNodes[1].nodeValue = ` ${text}`;
            }

            function checkPaymentStatus(tx_ref) {
                statusMessage.textContent = 'Verifying payment, please wait...';
                fetch(`check_status.php?tx_ref=${tx_ref}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'SUCCESSFUL') {
                            clearInterval(pollingInterval);
                            updateStep(steps.confirm, 'check-circle', 'Payment Confirmed');
                            updateStep(steps.complete, 'check-circle', 'Balance Updated!');
                            statusIcon.className = 'status-icon success';
                            statusIcon.innerHTML = '<i class="fas fa-check"></i>';
                            statusMessage.textContent = 'Success! Redirecting to dashboard...';
                            setTimeout(() => window.location.href = '../dashboard.php?deposit=success', 2500);

                        } else if (data.status === 'FAILED') {
                            clearInterval(pollingInterval);
                            updateStep(steps.confirm, 'times-circle', 'Payment Failed or Cancelled');
                            document.getElementById('step-complete').style.opacity = '0.3';
                            statusIcon.className = 'status-icon failed';
                            statusIcon.innerHTML = '<i class="fas fa-times"></i>';
                            statusMessage.textContent = data.message || 'The transaction failed. Redirecting...';
                            setTimeout(() => window.location.href = 'deposit.php', 4000);

                        } else { // PENDING
                            statusMessage.textContent = 'Awaiting your confirmation on your phone...';
                        }
                    })
                    .catch(error => {
                        console.error('Status Check Error:', error);
                        statusMessage.textContent = 'Could not verify payment status. Please wait.';
                    });
            }

            pollingInterval = setInterval(() => checkPaymentStatus(depositCheckData.tx_ref), 5000);
            checkPaymentStatus(depositCheckData.tx_ref); // Initial check
        }
    });
    </script>
</body>
</html>