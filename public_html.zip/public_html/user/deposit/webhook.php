<?php
// This script listens for server-to-server notifications from Tranzak.
error_reporting(E_ALL);
ini_set('display_errors', 0); // Never display errors publicly
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/webhook_log.log'); // Log errors to a file for debugging

require_once __DIR__ . '/../../../database/db.php';

// --- 1. Get the Webhook Payload ---
$payload = file_get_contents("php://input");
file_put_contents(__DIR__ . '/webhook_log.log', "--- Webhook Received: " . date('Y-m-d H:i:s') . " ---\n" . $payload . "\n\n", FILE_APPEND);

if (empty($payload)) {
    http_response_code(400); // Bad Request
    error_log("Webhook Error: Empty payload received.");
    exit();
}

// --- 2. Security: Verify the Webhook Signature ---
// Fetch the signature from the request header. Tranzak uses 'x-tranzak-signature'.
$tranzak_signature = $_SERVER['HTTP_X_TRANZAK_SIGNATURE'] ?? '';

// This is your secret key provided by Tranzak.
$webhook_secret = 'Ao3qIYj=qa>NmMSN<uaz1nT(lMUaiCAz.$Q';

// Verify that the signature is not empty and matches the expected hash.
if (empty($tranzak_signature) || !hash_equals(hash_hmac('sha256', $payload, $webhook_secret), $tranzak_signature)) {
    http_response_code(401); // Unauthorized
    error_log("Webhook Error: Invalid Signature. Provided Signature: " . $tranzak_signature);
    exit("Unauthorized");
}

// --- 3. Process the Verified Data ---
$data = json_decode($payload, true);
$event_type = $data['event'] ?? '';
$request_id = $data['data']['requestId'] ?? null;
$tranzak_status = $data['data']['status'] ?? null;

if ($event_type === 'request.completed' && $request_id) {
    try {
        $pdo->beginTransaction();

        // Find the transaction using the gateway's reference ID, which we stored earlier
        $stmt_find = $pdo->prepare("SELECT * FROM transactions WHERE gateway_ref = ? FOR UPDATE");
        $stmt_find->execute([$request_id]);
        $transaction = $stmt_find->fetch(PDO::FETCH_ASSOC);

        // Process only if the transaction exists and is still marked as 'pending'
        if ($transaction && $transaction['status'] === 'pending') {
            
            if ($tranzak_status === 'SUCCESSFUL') {
                // Credit the user's account
                $stmt_balance = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $stmt_balance->execute([$transaction['amount_usd'], $transaction['user_id']]);
                
                // Mark the transaction as 'completed'
                $stmt_update_tx = $pdo->prepare("UPDATE transactions SET status = 'completed', gateway_response = ? WHERE id = ?");
                $stmt_update_tx->execute([$payload, $transaction['id']]);

                error_log("SUCCESS: Webhook credited user {$transaction['user_id']} for tx_ref: {$transaction['tx_ref']}");

            } elseif (in_array($tranzak_status, ['FAILED', 'CANCELLED', 'EXPIRED'])) {
                // Mark the transaction as 'failed' so the user knows what happened
                $stmt_fail = $pdo->prepare("UPDATE transactions SET status = 'failed', gateway_response = ? WHERE id = ?");
                $stmt_fail->execute([$payload, $transaction['id']]);
                error_log("INFO: Webhook marked tx_ref {$transaction['tx_ref']} as FAILED.");
            }
        } elseif ($transaction && $transaction['status'] !== 'pending') {
            // This means the browser-side polling already handled it. That's fine.
            error_log("INFO: Webhook received for an already processed tx_ref: {$transaction['tx_ref']}");
        } else {
            error_log("WARNING: Webhook received for a non-existent transaction with request_id: {$request_id}");
        }
        
        $pdo->commit();

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("CRITICAL: Webhook DB Error for request_id {$request_id}: " . $e->getMessage());
        http_response_code(500); // Tell Tranzak something went wrong on our end
        exit("Internal Server Error");
    }
}

// --- 4. Acknowledge Receipt ---
// Always send a 200 OK response to Tranzak to let them know we received the webhook.
// If we don't, they will keep sending it, which could lead to issues.
http_response_code(200);
echo "Webhook Acknowledged.";
exit();