<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

// --- Security: Redirect if not logged in ---
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// --- Initialize variables ---
$message = '';
$message_type = '';
$user = null;
$card = null;
$all_user_cards = [];
// Use the card_id from POST if form is submitted, otherwise from GET for initial page load
$selected_card_id = $_POST['card_id'] ?? $_GET['card_id'] ?? null;

try {
    // --- Fetch User, their cards, and all system settings ---
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // If user not found, destroy session and redirect to login
        session_destroy();
        header("Location: ../login.php");
        exit();
    }

    // Fetch all cards belonging to the user
    $stmt_cards = $pdo->prepare("SELECT card_id, brand, last4, status FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC");
    $stmt_cards->execute([$user_id]);
    $all_user_cards = $stmt_cards->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch necessary API settings from the database
    $setting_keys = ['sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'card_funding_fixed_fee', 'card_funding_percentage_fee', 'referral_bonus_card_funding', 'site_name', 'support_email', 'notification_email'];
    $placeholders = implode(',', array_fill(0, count($setting_keys), '?'));
    $stmt_api = $pdo->prepare("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ($placeholders)");
    $stmt_api->execute($setting_keys);
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);

    // Assign settings to variables with sane defaults
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;
    $sudo_account_id = $api_settings['sudo_account_id'] ?? null;
    $card_funding_fixed_fee = (float)($api_settings['card_funding_fixed_fee'] ?? 0);
    $card_funding_percentage_fee = (float)($api_settings['card_funding_percentage_fee'] ?? 0);
    $funding_commission_fixed_amount = (float)($api_settings['referral_bonus_card_funding'] ?? 0);
    $site_name = htmlspecialchars($api_settings['site_name'] ?? 'Rovicc');
    $support_email = htmlspecialchars($api_settings['support_email'] ?? 'support@rovicc.com');
    $admin_email_address = htmlspecialchars($api_settings['notification_email'] ?? '');

    // Determine which card is selected to show details for
    if ($selected_card_id && !empty($all_user_cards)) {
        $stmt_card = $pdo->prepare("SELECT * FROM virtual_cards WHERE user_id = ? AND card_id = ? LIMIT 1");
        $stmt_card->execute([$user_id, $selected_card_id]);
        $card = $stmt_card->fetch(PDO::FETCH_ASSOC);
    } elseif (!empty($all_user_cards)) {
        // If no card is selected (e.g., first page load), default to the most recent one
        $selected_card_id = $all_user_cards[0]['card_id'];
        $stmt_card = $pdo->prepare("SELECT * FROM virtual_cards WHERE card_id = ? LIMIT 1");
        $stmt_card->execute([$selected_card_id]);
        $card = $stmt_card->fetch(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    $message = "A critical database error occurred. Please contact support.";
    $message_type = 'danger';
    // Log the detailed error for the admin, but show a generic message to the user.
    error_log("Fund Card Page Load DB Error: " . $e->getMessage());
}

// --- Reusable function to call the Sudo API ---
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $curl = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 45, // Increased timeout for reliability
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers
        ];
        if (($method === 'POST' || $method === 'PUT') && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            // Log cURL errors for debugging
            error_log("Sudo API cURL Error: " . $err);
            return ['error' => "API communication error. Please try again later."];
        }
        return json_decode($response, true);
    }
}

// --- SECURE FORM SUBMISSION HANDLING ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && $user && $card) {
    // Sanitize and validate the amount from the user.
    $amount_to_fund = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);

    // Calculate fees based on the validated amount.
    $percentage_fee_amount = $amount_to_fund * ($card_funding_percentage_fee / 100);
    $total_fees = $card_funding_fixed_fee + $percentage_fee_amount;
    $total_deduction_from_balance = $amount_to_fund + $total_fees;
    
    $transaction_id = null; // To hold the ID of our new transaction record.
    $paymentReference = 'FUND-CARD-' . $user_id . '-' . time(); // Unique reference for this attempt.

    // --- Initial validation before starting the transaction ---
    if (!$amount_to_fund || $amount_to_fund < 1.00) {
        $message = "Please enter a valid amount to fund (minimum $1.00).";
        $message_type = 'danger';
    } elseif ($amount_to_fund > 50.00) { // SERVER-SIDE VALIDATION ADDED HERE
        $message = "You cannot fund more than $50.00 at a time.";
        $message_type = 'danger';
    } elseif ($total_deduction_from_balance > $user['balance']) {
        $message = "Insufficient balance. You need $" . number_format($total_deduction_from_balance, 2) . " but only have $" . number_format($user['balance'], 2) . ".";
        $message_type = 'danger';
    } else {
        // --- CORE TRANSACTION LOGIC (DEBIT-FIRST) ---
        try {
            $pdo->beginTransaction();

            // 1. LOCK THE USER'S ROW to prevent race conditions.
            $stmt_lock_user = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
            $stmt_lock_user->execute([$user_id]);
            $currentUserBalance = $stmt_lock_user->fetchColumn();

            // 2. RE-VERIFY BALANCE inside the transaction to be absolutely sure.
            if ($total_deduction_from_balance > $currentUserBalance) {
                throw new Exception("Your balance is insufficient for this transaction.");
            }

            // 3. DEBIT THE USER'S BALANCE from their account.
            $stmt_debit = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt_debit->execute([$total_deduction_from_balance, $user_id]);

            // 4. CREATE A TRANSACTION RECORD with a 'pending' status.
            $stmt_insert_tx = $pdo->prepare("INSERT INTO transactions (user_id, tx_ref, amount_usd, status, payment_gateway, type, description) VALUES (?, ?, ?, 'pending', 'Sudo Internal', 'card_funding', ?)");
            $description = "Attempting to fund card ending in " . $card['last4'] . " (Fee: $" . number_format($total_fees, 2) . ")";
            $stmt_insert_tx->execute([$user_id, $paymentReference, $amount_to_fund, $description]);
            $transaction_id = $pdo->lastInsertId();

            // 5. COMMIT the database changes.
            $pdo->commit();

            // --- EXTERNAL API CALL (Happens only after local debit is successful) ---
            $api_call_succeeded = false;
            try {
                // Activate card if it's inactive
                if ($card['status'] === 'inactive') {
                    $activation_url = rtrim($sudo_base_url, '/') . '/cards/' . $card['card_id'];
                    $activation_payload = ['status' => 'active'];
                    $activation_response = callSudoApi('PUT', $activation_url, $sudo_api_key, $activation_payload);
                    if (!isset($activation_response['data']['_id'])) {
                        throw new Exception("Could not activate the card before funding. The funding process has been safely cancelled.");
                    }
                    $pdo->prepare("UPDATE virtual_cards SET status = 'active' WHERE card_id = ?")->execute([$card['card_id']]);
                    $card['status'] = 'active';
                }

                // Call the funding API
                $apiUrl = rtrim($sudo_base_url, '/') . '/accounts/transfer';
                $payload = [
                    'debitAccountId' => $sudo_account_id,
                    'amount' => $amount_to_fund,
                    'narration' => 'Fund card ' . $card['last4'],
                    'paymentReference' => $paymentReference,
                    'creditAccountId' => $card['account_id']
                ];
                $response = callSudoApi('POST', $apiUrl, $sudo_api_key, $payload);

                if (isset($response['data']['_id'])) {
                    $api_call_succeeded = true;
                } else {
                    throw new Exception('Card funding failed at the provider: ' . ($response['message'] ?? 'Unknown API error'));
                }

            } catch (Exception $api_ex) {
                // --- REVERSAL LOGIC ---
                error_log("API Call Failed for tx_ref {$paymentReference}: " . $api_ex->getMessage());
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$total_deduction_from_balance, $user_id]);
                $pdo->prepare("UPDATE transactions SET status = 'failed', description = CONCAT(description, ' - REVERSED') WHERE id = ?")->execute([$transaction_id]);
                $message = "An external error occurred. Your transaction has been safely reversed and your balance is unchanged. Please try again later.";
                $message_type = 'danger';
            }

            // --- POST-API SUCCESS LOGIC ---
            if ($api_call_succeeded) {
                // Update the transaction from 'pending' to 'successful'
                $pdo->prepare("UPDATE transactions SET status = 'successful' WHERE id = ?")->execute([$transaction_id]);

                $message = "Successfully funded your card with $" . number_format($amount_to_fund, 2) . ".";
                $message_type = 'success';
                $user['balance'] -= $total_deduction_from_balance; // Refresh user balance for display

                $referral_fund_status_message = ''; // For admin email
                // Handle referral bonus
                if (!empty($user['referred_by']) && $funding_commission_fixed_amount > 0) {
                    try {
                        $clean_referred_by_code = trim(strtolower($user['referred_by']));
                        $stmt_get_referrer = $pdo->prepare("SELECT id, email, first_name FROM users WHERE referral_code = ?");
                        $stmt_get_referrer->execute([$clean_referred_by_code]);
                        $referrer = $stmt_get_referrer->fetch(PDO::FETCH_ASSOC);

                        if ($referrer) {
                            $pdo->prepare("UPDATE users SET referral_balance = referral_balance + ? WHERE id = ?")->execute([$funding_commission_fixed_amount, $referrer['id']]);
                            $ref_tx_ref = 'REF-FUND-' . $user_id . '-' . time();
                            $pdo->prepare("INSERT INTO transactions (user_id, tx_ref, amount_usd, status, payment_gateway, type, description) VALUES (?, ?, ?, 'successful', 'Internal', 'referral_bonus', ?)")->execute([$referrer['id'], $ref_tx_ref, $funding_commission_fixed_amount, "Bonus from " . htmlspecialchars($user['first_name']) . "'s card funding"]);
                            
                            $referral_fund_status_message = "SUCCESS: Commission of $" . number_format($funding_commission_fixed_amount, 2) . " paid to referrer '" . htmlspecialchars($referrer['first_name']) . "'.";

                            // Email to Referrer
                            if (!empty($referrer['email'])) {
                                $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";
                                $subject_ref = "💰 You've Received a Funding Commission!";
                                $body_ref = @file_get_contents(__DIR__ . '/email_templates/funding_commission_referrer.html');
                                if($body_ref) {
                                    $body_ref = str_replace('{{referrer_name}}', htmlspecialchars($referrer['first_name']), $body_ref);
                                    $body_ref = str_replace('{{user_name}}', htmlspecialchars($user['first_name']), $body_ref);
                                    $body_ref = str_replace('{{commission_amount}}', number_format($funding_commission_fixed_amount, 2), $body_ref);
                                    $body_ref = str_replace('{{site_name}}', $site_name, $body_ref);
                                    $body_ref = str_replace('{{year}}', date('Y'), $body_ref);
                                    @mail($referrer['email'], $subject_ref, $body_ref, $headers);
                                }
                            }
                        } else {
                             $referral_fund_status_message = "SKIPPED: Referrer code '{$clean_referred_by_code}' not found.";
                        }
                    } catch(Exception $ref_ex) {
                        error_log("Referral commission failed for tx_ref {$paymentReference}: " . $ref_ex->getMessage());
                        $referral_fund_status_message = "ERROR: Referral commission failed to process.";
                    }
                } else {
                    $referral_fund_status_message = "SKIPPED: User was not referred or funding commission is set to zero.";
                }
                
                // --- SEND USER AND ADMIN EMAILS ---
                $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";

                // 1. To User Funding the Card
                if(!empty($user['email'])) {
                    $subject_user = "✅ Card Funded Successfully";
                    $body_user = @file_get_contents(__DIR__ . '/email_templates/card_funded_user.html');
                    if($body_user) {
                        $body_user = str_replace('{{user_name}}', htmlspecialchars($user['first_name']), $body_user);
                        $body_user = str_replace('{{amount_funded}}', number_format($amount_to_fund, 2), $body_user);
                        $body_user = str_replace('{{card_details}}', strtoupper(htmlspecialchars($card['brand'])) . " **** " . htmlspecialchars($card['last4']), $body_user);
                        $body_user = str_replace('{{site_name}}', $site_name, $body_user);
                        $body_user = str_replace('{{year}}', date('Y'), $body_user);
                        @mail($user['email'], $subject_user, $body_user, $headers);
                    }
                }

                // 2. To Admin
                if (!empty($admin_email_address)) {
                    $subject_admin = "✅ Card Funded: $" . number_format($amount_to_fund, 2);
                    $body_admin = @file_get_contents(__DIR__ . '/email_templates/card_funded_admin.html');
                    if($body_admin) {
                        $body_admin = str_replace('{{user_full_name}}', htmlspecialchars($user['first_name'] . ' ' . $user['last_name']), $body_admin);
                        $body_admin = str_replace('{{user_id}}', $user_id, $body_admin);
                        $body_admin = str_replace('{{amount_funded}}', number_format($amount_to_fund, 2), $body_admin);
                        $body_admin = str_replace('{{card_details}}', strtoupper(htmlspecialchars($card['brand'])) . " **** " . htmlspecialchars($card['last4']), $body_admin);
                        $body_admin = str_replace('{{tx_ref}}', $paymentReference, $body_admin);
                        $body_admin = str_replace('{{referral_status}}', htmlspecialchars($referral_fund_status_message), $body_admin);
                        $body_admin = str_replace('{{site_name}}', $site_name, $body_admin);
                        $body_admin = str_replace('{{year}}', date('Y'), $body_admin);
                        @mail($admin_email_address, $subject_admin, $body_admin, $headers);
                    }
                }
            }

        } catch (Exception $e) {
            // This catches errors from the main DB transaction (e.g., insufficient funds after lock)
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $message = "An error occurred: " . $e->getMessage();
            $message_type = 'danger';
            error_log("Fund Card POST Error for user {$user_id}: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Card - <?= htmlspecialchars($site_name) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        :root { --primary: #5A54D8; --primary-light: #f0f0ff; --white: #fff; --background: #f7f8fc; --border-color: #e9ecf2; --text-dark: #0D1022; --text-light: #6c757d; --radius: 12px; --success: #10b981; --danger: #ef4444; }
        body { font-family: 'Poppins', sans-serif; }
        .main-content { background-color: var(--background); }
        .fund-card-container { max-width: 500px; margin: 2rem auto; }
        .form-wrapper { background: var(--white); padding: 2.5rem; border-radius: var(--radius); box-shadow: 0 10px 25px rgba(13, 16, 34, 0.06); }
        .balance-box { background-color: var(--primary-light); border: 1px solid var(--primary); color: var(--primary); padding: 1rem; border-radius: var(--radius); text-align: center; margin-bottom: 1.5rem; }
        .balance-box .label { font-size: 0.9rem; opacity: 0.8; }
        .balance-box .amount { font-size: 2rem; font-weight: 700; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { font-weight: 500; margin-bottom: 0.5rem; display: block; }
        .input-group { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: var(--radius); transition: border-color 0.2s; }
        .input-group:focus-within { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(90, 84, 216, 0.1); }
        .input-group .icon { padding: 0 1rem; font-size: 1.2rem; color: var(--text-light); }
        .input-group input, .input-group select { border: none; outline: none; padding: 1rem; width: 100%; background: transparent; font-size: 1.1rem; appearance: none; -webkit-appearance: none; }
        .fee-summary { font-size: 0.85rem; color: var(--text-light); text-align: center; margin-top: 1rem; height: 1.2em; transition: all 0.2s; }
        .btn-primary { background-color: var(--primary); color: var(--white); width: 100%; padding: 1rem; font-size: 1.1rem; font-weight: 600; border-radius: var(--radius); margin-top: 1.5rem; transition: background-color 0.2s; cursor: pointer; border: none; }
        .btn-primary:hover:not(:disabled) { background-color: #4540ae; }
        .btn-primary:disabled { background-color: #a5a2e8; cursor: not-allowed; }
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius); border: 1px solid transparent; }
        .alert-success { background-color: #d1fae5; color: #065f46; border-color: #6ee7b7; }
        .alert-danger { background-color: #fee2e2; color: #991b1b; border-color: #fca5a5; }
        .main-header .btn-back { background-color: #e9ecf2; color: var(--text-dark); padding: 0.6rem 1rem; border-radius: var(--radius); text-decoration: none; font-weight: 500; transition: background-color 0.2s; }
        .main-header .btn-back:hover { background-color: #d1d5db; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><a href="dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="create_card.php"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="fund_card.php" class="active"><i class="fa-solid fa-dollar-sign"></i> Fund Card</a></li>
                    <li><a href="transactions.php"><i class="fa-solid fa-receipt"></i> Transactions</a></li>
                    <li><a href="../referral.php"><i class="fa-solid fa-users"></i> Referrals</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>

        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title"><h1>Fund Your Card</h1><p>Add money to your virtual card from your balance.</p></div>
                <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> </a>
            </header>

            <div class="fund-card-container">
                <div class="form-wrapper">
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($all_user_cards) && $user): ?>
                        <div class="balance-box">
                            <div class="label">Your Current Balance</div>
                            <div class="amount">$<?= number_format($user['balance'] ?? 0.00, 2) ?></div>
                        </div>

                        <form action="fund_card.php" method="POST" id="funding-form">
                            <div class="form-group">
                                <label for="card_id">Select Card to Fund</label>
                                <div class="input-group">
                                    <span class="icon"><i class="fa-solid fa-credit-card"></i></span>
                                    <select name="card_id" id="card_id">
                                        <?php foreach ($all_user_cards as $c): ?>
                                            <option value="<?= htmlspecialchars($c['card_id']) ?>" <?= ($c['card_id'] == $selected_card_id) ? 'selected' : '' ?>>
                                                <?= strtoupper(htmlspecialchars($c['brand'])) ?> **** <?= htmlspecialchars($c['last4']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        
                            <div class="form-group">
                                <label for="amount">Amount to Fund (USD)</label>
                                <div class="input-group">
                                    <span class="icon">$</span>
                                    <input type="number" id="amount" name="amount" placeholder="0.00" min="1.00" max="50.00" step="0.01" required>
                                </div>
                            </div>
                            <div class="fee-summary" id="fee-summary">
                                Enter an amount to see the total charge.
                            </div>
                            <button type="submit" class="btn-primary" id="submit-button">Fund Card</button>
                        </form>
                    <?php elseif ($user): ?>
                        <div class="alert alert-danger">You do not have any cards to fund. Please <a href="create_card.php">create a card</a> first.</div>
                    <?php else: ?>
                         <div class="alert alert-danger">Could not load user data. Please try again later.</div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }

        const amountInput = document.getElementById('amount');
        const fundingForm = document.getElementById('funding-form');
        const submitButton = document.getElementById('submit-button');

        if (amountInput) {
            const fixedFee = <?= json_encode($card_funding_fixed_fee) ?>;
            const percentageRate = <?= json_encode($card_funding_percentage_fee) ?>;
            const feeSummary = document.getElementById('fee-summary');

            const updateFeeDisplay = () => {
                const amount = parseFloat(amountInput.value) || 0;
                if (amount >= 1) {
                    const percentageFee = amount * (percentageRate / 100);
                    const totalDeduction = amount + fixedFee + percentageFee;
                    feeSummary.textContent = `Total charge: $${totalDeduction.toFixed(2)} (includes $${(fixedFee + percentageFee).toFixed(2)} fees)`;
                } else {
                    feeSummary.textContent = 'Enter an amount to see the total charge.';
                }
            };
            amountInput.addEventListener('input', updateFeeDisplay);
        }

        // Disable button on form submission to prevent double-clicks
        if(fundingForm && submitButton) {
            fundingForm.addEventListener('submit', function() {
                submitButton.disabled = true;
                submitButton.textContent = 'Processing...';
            });
        }
    });
    </script>
</body>
</html>