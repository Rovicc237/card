<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

try {
    // Fetch all transactions for the logged-in user
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $transactions = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Transaction History DB Error: " . $e->getMessage());
    die("A database error occurred. Please try again later.");
}

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/deposit_history.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating a user.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <?php include 'templates/sidebar.php'; ?>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                   <center> <h4>Transaction History</h4> </center>
                    <p>A complete record of all your account activities.</p>
                </div>
                <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> </a>
            </header>

            <section class="transactions-section">
                <div class="table-container">
                    <?php if (empty($transactions)): ?>
                        <div class="no-transactions-message">
                            <p>You have not made any transactions yet.</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Amount (USD)</th>
                                    <th>Amount (XAF)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($transaction['tx_ref']) ?></td>
                                        <td><?= date("M j, Y, g:i A", strtotime($transaction['created_at'])) ?></td>
                                        <td><?= htmlspecialchars(ucwords(str_replace('_', ' ', $transaction['type']))) ?></td>
                                        <td class="amount-usd">$<?= number_format($transaction['amount_usd'], 2) ?></td>
                                        <td class="amount-xaf"><?= number_format($transaction['amount_xaf'], 2) ?> XAF</td>
                                        <td>
                                            <?php
                                                $status_text = ucfirst(htmlspecialchars(str_replace('_', ' ', $transaction['status'])));
                                                $status_class = 'status-' . htmlspecialchars(strtolower($transaction['status']));

                                                // Types that are successful if they exist with an empty status
                                                $successful_by_default = ['card_funding', 'card_withdrawal', 'referral_bonus', 'manual_adjustment'];

                                                if (in_array($transaction['type'], $successful_by_default) && empty($transaction['status'])) {
                                                    $status_text = 'Successful';
                                                    $status_class = 'status-successful';
                                                } else {
                                                    switch (strtolower($transaction['status'])) {
                                                        case 'completed':
                                                        case 'successful':
                                                        case 'payment_successful':
                                                            $status_text = 'Successful';
                                                            $status_class = 'status-successful';
                                                            break;
                                                        case 'pending':
                                                            $status_class = 'status-pending';
                                                            break;
                                                        case 'failed':
                                                            $status_class = 'status-failed';
                                                            break;
                                                        default:
                                                            $status_class = 'status-default';
                                                            break;
                                                    }
                                                }
                                            ?>
                                            <span class="status-pill <?= $status_class ?>">
                                                <?= $status_text ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }
    });
    </script>
</body>
</html>