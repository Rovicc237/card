<?php
session_start();
// The database connection is required for all dashboard operations.
require_once __DIR__ . '/../../database/db.php';

// If a user is not logged in, they should not be able to access the dashboard.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// --- Initialize variables ---
$cardToken = '';
$error_message = '';
$cardId_from_form = '';
$sudo_api_key = null;
$sudo_base_url = null;
$sudo_vault_id = null;
$virtual_card_balance = 'N/A'; // Initialize virtual card balance

// Function to get account balance from Sudo API
function getAccountBalanceFromSudo(string $baseUrl, string $accountId, string $apiToken): string
{
    $url = rtrim($baseUrl, '/') . "/accounts/{$accountId}/balance";
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_HTTPGET => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer {$apiToken}",
            "Content-Type: application/json",
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
    ]);
    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        error_log('cURL Error in getAccountBalanceFromSudo: ' . $curl_error);
        return 'Error';
    }

    $balanceData = json_decode($response, true);
    if (isset($balanceData['data']['currentBalance'])) {
        return number_format($balanceData['data']['currentBalance'], 2);
    }
    error_log("Could not find 'currentBalance' in Sudo API response for account {$accountId}: " . $response);
    return 'N/A';
}

// --- DATABASE QUERIES (including new API Settings query) ---
try {
    // Fetch user data, including the new balance
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
    
    // Fetch ALL user's virtual cards instead of just the latest one
    $card_stmt = $pdo->prepare("SELECT * FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC");
    $card_stmt->execute([$user_id]);
    $cards = $card_stmt->fetchAll();
    // Default to the first card on page load, or null if no cards exist
    $card = !empty($cards) ? $cards[0] : null;

    // Fetch dynamic API settings from the database
    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url', 'sudo_vault_id')");
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;
    $sudo_vault_id = $api_settings['sudo_vault_id'] ?? null; 

    // Fetch virtual card balance if card and API settings exist
    if ($card && !empty($card['account_id']) && !empty($sudo_api_key) && !empty($sudo_base_url)) {
        $virtual_card_balance = getAccountBalanceFromSudo($sudo_base_url, $card['account_id'], $sudo_api_key);
    }

} catch (PDOException $e) {
    // Set a generic error message, but log the real error for debugging.
    $error_message = "A critical database error occurred. Please try again later.";
    error_log("User Dashboard DB Error: " . $e->getMessage());
}

// --- Fetch Recent Transactions ---
$transactions = [];
$api_error_transactions = '';

if ($card && !empty($sudo_api_key) && !empty($sudo_base_url)) {
    $cardId_for_transactions = $card['card_id'];
    
    $toDate = date('c');
    $fromDate = date('c', strtotime('-2 years'));
    $page = 0;
    $limit = 1000; // Fetch a large number to sort from

    $queryParams = http_build_query([
        'page' => $page,
        'limit' => $limit,
        'fromDate' => $fromDate,
        'toDate' => $toDate
    ]);
    $requestUrl = rtrim($sudo_base_url, '/') . '/cards/' . $cardId_for_transactions . '/transactions?' . $queryParams;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $requestUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $sudo_api_key,
        "Content-Type: application/json"
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        $api_error_transactions = "cURL Error: " . $curlError;
    } elseif ($httpCode != 200) {
        $api_error_transactions = "API Error: Received HTTP code " . $httpCode . ". Response: " . $response;
    } else {
        $response_data = json_decode($response, true);
        if (isset($response_data['data'])) {
            $all_transactions = $response_data['data'];
            
            usort($all_transactions, function($a, $b) {
                return strtotime($b['createdAt']) - strtotime($a['createdAt']);
            });

            $transactions = array_slice($all_transactions, 0, 5);
        }
    }
}

// --- SERVER-SIDE TOKEN GENERATION ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['card_id_for_token'])) {
    $cardId_from_form = htmlspecialchars(trim($_POST['card_id_for_token']));

    if (empty($cardId_from_form)) {
        $error_message = "Card ID is missing. Cannot reveal details.";
    } else if (empty($sudo_api_key) || empty($sudo_base_url)) {
        $error_message = "Card services are currently unavailable. Please contact support.";
        error_log("Admin has not configured Sudo API Key or Base URL.");
    } else {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => rtrim($sudo_base_url, '/') . '/cards/' . $cardId_from_form . "/token",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer " . $sudo_api_key,
                "Accept: application/json"
            ],
        ]);

        $response_body = curl_exec($curl);
        $curl_error = curl_error($curl);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($curl_error) {
            $error_message = "A system error occurred while fetching card details.";
            error_log("cURL Error for token generation: " . $curl_error);
        } else {
            $response_data = json_decode($response_body, true);
            if ($http_code == 200 && isset($response_data['data']['token'])) {
                $cardToken = $response_data['data']['token'];
            } else {
                $api_error = $response_data['message'] ?? 'Could not retrieve token. HTTP Code: ' . $http_code;
                $error_message = "API Error: " . $api_error;
                error_log("Sudo Token API Error: " . $api_error);
            }
        }
    }
}

// Prepare user and card data for display
$firstName = htmlspecialchars($user['first_name'] ?? 'User');
$lastName = htmlspecialchars($user['last_name'] ?? '');
$fullName = trim($firstName . ' ' . $lastName);
$is_verified = $user['is_verified'];
$kyc_status = $user['kyc_status'];
$kyc_feedback = $user['kyc_feedback'];
$kyc_reviewed_at = $user['kyc_reviewed_at'];
$current_balance = $user['balance'] ?? 0.00;
$referral_balance = $user['referral_balance'] ?? 0.00;


// Prepare card number for display
$pan_parts = ['****', '****', '****', '0000'];
if ($card && !empty($card['maskedPan'])) {
    $maskedPan = preg_replace('/[^0-9*]/', '', $card['maskedPan']);
    if (strlen($maskedPan) === 16) {
        $pan_parts = [
            substr($maskedPan, 0, 4),
            substr($maskedPan, 4, 4),
            substr($maskedPan, 8, 4),
            substr($maskedPan, 12, 4)
        ];
    }
} elseif ($card && !empty($card['last4'])) {
    $pan_parts[3] = $card['last4'];
}

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Rovicc</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Courier+Prime:wght@400;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        /* --- STYLISH UPDATES --- */
        .sidebar-nav .nav-divider {
            height: 1px;
            background-color: var(--border-color);
            margin: 15px 20px;
        }

        .whatsapp-fab {
            position: fixed;
            width: 30px;
            height: 30px;
            bottom: 40px;
            right: 40px;
            background-color: #25D366; /* Official WhatsApp Green */
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.25);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }
        .whatsapp-fab:hover {
            transform: scale(1.1);
            background-color: #128C7E; /* Darker WhatsApp Green */
        }
        /* --- END OF STYLISH UPDATES --- */

        .billing-address-section {
            margin-top: 25px;
            border-top: 1px solid var(--border-color);
            padding-top: 20px;
        }
        .billing-address-section > label { /* Direct child label */
            display: block;
            font-size: 1.1rem; /* Make the main label slightly larger */
            color: var(--text-dark);
            margin-bottom: 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .address-box {
            font-family: var(--font-mono);
            font-size: 1rem;
            padding: 20px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background-color: var(--background);
        }
        .address-item {
            display: grid;
            grid-template-columns: 120px 1fr; /* Fixed width for labels */
            gap: 15px;
            padding: 10px 0;
            border-bottom: 1px solid #e0e5ec;
        }
        .address-item:last-child {
            border-bottom: none;
        }
        .address-item .address-label {
            font-weight: 600;
            color: var(--text-light);
        }
        .address-item .address-value {
            color: var(--text-dark);
            word-break: break-word;
        }
        .copy-notice {
            display: block;
            font-size: 0.8rem;
            color: var(--text-light);
            margin-top: 15px;
            text-align: center;
        }
        
        /* NEW PROFESSIONAL CARD SWITCHER STYLES */
        .card-switcher-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 15px 0;
            position: relative;
        }
        
        .card-switcher-btn {
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .card-switcher-btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }
        
        .card-switcher-btn:disabled {
            background-color: var(--border-color);
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .card-switcher-btn i {
            font-size: 1rem;
        }
        
        .card-position-indicator {
            font-size: 0.9rem;
            color: var(--text-light);
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            background: var(--background-light);
            padding: 2px 10px;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .card-actions-section {
            margin-top: 20px;
        }
        
        /* Style for both activate and deactivate buttons */
        .card-secondary-actions .btn-status {
            display: inline-block;
            margin-right: 8px;
        }
    </style>
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($fullName) ?>.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
       <?php include 'templates/sidebar.php'; ?>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title"><h1>Dashboard</h1><p>Welcome Back, <?= $firstName ?>!</p></div>
            </header>

            <?php if (!empty($error_message)): ?>
                <div class="kyc-status-banner kyc-status-rejected"><div class="banner-main-content"><div class="banner-icon"><i class="fa-solid fa-triangle-exclamation"></i></div><div class="banner-text"><h4>Error</h4><p><?= htmlspecialchars($error_message) ?></p></div></div></div>
            <?php endif; ?>

            <?php if ($is_verified && !is_null($kyc_reviewed_at) && $kyc_status === 'Rejected'): ?>
                 <div class="kyc-status-banner kyc-status-rejected"><div class="banner-main-content"><div class="banner-icon"><i class="fa-solid fa-triangle-exclamation"></i></div><div class="banner-text"><h4>Action Required</h4><p>Your document submission was not approved. Please review feedback and resubmit.</p><?php if (!empty($kyc_feedback)): ?><p class="feedback-text"><strong>Feedback:</strong> <?= htmlspecialchars($kyc_feedback) ?></p><?php endif; ?></div></div><div class="banner-action"><a href="resubmit_documents.php" class="btn-resubmit">Resubmit Documents <i class="fa-solid fa-arrow-right"></i></a></div></div>
            <?php endif; ?>

            <section class="top-section">
                <div class="card-column">
                    <?php if (!empty($cards)): ?>
                        <div class="card-switcher-container">
                            <button class="card-switcher-btn" id="prev-card" disabled>
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            
                            <span class="card-position-indicator" id="card-position">
                                Card 1 of <?= count($cards) ?>
                            </span>
                            
                            <button class="card-switcher-btn" id="next-card" <?= count($cards) <= 1 ? 'disabled' : '' ?>>
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="card-flipper <?= ($card && $card['status'] === 'inactive') ? 'inactive' : '' ?>" id="card-flipper">
                        <?php if ($card): ?>
                            <div class="card-side card-front">
                                <div class="card-top"><span class="card-brand-logo">ROVICC</span><div class="card-balance"><small>Card Balance</small><p>$<?= htmlspecialchars($virtual_card_balance) ?></p></div></div>
                                <div class="card-chip"></div>
                                <div class="card-number">
                                    <span><?= htmlspecialchars($pan_parts[0]) ?></span>
                                    <span><?= htmlspecialchars($pan_parts[1]) ?></span>
                                    <span><?= htmlspecialchars($pan_parts[2]) ?></span>
                                    <span><?= htmlspecialchars($pan_parts[3]) ?></span>
                                </div>
                                <div class="card-bottom"><div class="card-holder"><small>Card Holder</small><p><?= strtoupper($fullName) ?></p></div><div class="card-expiry"><small>Valid Thru</small><p><?= htmlspecialchars($card['expiryMonth'] ?? 'MM') . '/' . htmlspecialchars($card['expiryYear'] ?? 'YY') ?></p></div><div class="card-network-logo" id="card-network-logo"><?php if ($card['brand'] === 'Visa'): ?><i class="fab fa-cc-visa" style="font-size: 3rem; color: white;"></i><?php else: ?><svg xmlns="http://www.w3.org/2000/svg" width="60" height="40" viewBox="0 0 78 48"><circle fill="#EB001B" cx="24" cy="24" r="24"/><circle fill="#F79E1B" cx="54" cy="24" r="24" opacity=".95"/></svg><?php endif; ?></div></div>
                                <div class="card-status-overlay"><span class="status-text">Inactive</span></div>
                            </div>
                            <div class="card-side card-back">
                                <div class="card-mag-stripe"></div>
                                <div class="card-back-content"><div class="cvv-box"><small>CVV</small><p>***</p></div><p class="card-back-text">This card is issued by Rovicc Financial Technologies...</p></div>
                                <div class="card-status-overlay"><span class="status-text">Inactive</span></div>
                            </div>
                        <?php else: ?>
                            <div class="card-side card-front" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                                <h3>No Card Available</h3><p>You haven't created a virtual card yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($card): ?>
                    <div class="card-secondary-actions" id="card-secondary-actions">
                        <form action="dashboard.php" method="POST" style="display: contents;">
                            <input type="hidden" name="card_id_for_token" value="<?= htmlspecialchars($card['card_id']) ?>">
                            <button type="submit" class="btn btn-info">
                                <i class="fa-solid fa-eye"></i> Details
                            </button>
                        </form>
                        <?php if ($card['status'] === 'active'): ?>
                            <button type="button" class="btn btn-danger btn-status" onclick="updateCardStatus('<?= htmlspecialchars($card['card_id']) ?>', 'inactive', this)">
                                <i class="fa-solid fa-ban"></i> Deactivate
                            </button>
                        <?php else: ?>
                            <button type="button" class="btn btn-success btn-status" onclick="updateCardStatus('<?= htmlspecialchars($card['card_id']) ?>', 'active', this)">
                                <i class="fa-solid fa-check-circle"></i> Activate
                            </button>
                        <?php endif; ?>
                        <a href="card_authorizations.php?card_id=<?= htmlspecialchars($card['card_id']) ?>" id="secondary-auth-link" class="btn btn-primary">
                            <i class="fa-solid fa-file-contract"></i> Authorizations
                        </a>
                        <div id="cardStatusMessage" class="status-message-box"></div>
                    </div>
                    <?php endif; ?>

                    <div class="card-actions-section">
                        <a href="SudoCard/create_card.php" class="btn btn-success"><i class="fa-solid fa-plus"></i> Create</a>
                        <a href="deposit/deposit.php" class="btn btn-deposit"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
                        <a href="fund_card.php?card_id=<?= htmlspecialchars($card['card_id'] ?? '') ?>" id="main-fund-link" class="btn btn-primary"><i class="fa-solid fa-dollar-sign"></i> Fund</a>
                        <a href="withdraw_card.php?card_id=<?= htmlspecialchars($card['card_id'] ?? '') ?>" id="main-withdraw-link" class="btn btn-danger"><i class="fa-solid fa-arrow-up-from-bracket"></i> Withdraw</a>
                        <a href="international_transfers/international_transfers.php" class="btn btn-info"><i class="fa-solid fa-globe"></i> International Transfers</a>
                    </div>

                </div>

                <div class="widgets-column">
                    <div class="widget">
                        <div class="widget-icon" style="color: #5A54D8; background-color: #e0e9f8;"><i class="fa-solid fa-wallet"></i></div>
                        <div class="widget-info">
                            <small>Current Balance</small>
                            <p class="amount">$<?= number_format($current_balance, 2) ?></p>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="widget-icon" style="color: #6366f1; background-color: #e0e7ff;"><i class="fa-solid fa-handshake"></i></div>
                        <div class="widget-info">
                            <small>Referral Balance</small>
                            <p class="amount">XAF <?= number_format($referral_balance, 2) ?></p>
                        </div>
                    </div>
                    <div class="widget"><div class="widget-icon" style="color: #f43f5e; background-color: #fddbde;"><i class="fa-solid fa-arrow-down"></i></div><div class="widget-info"><small>Spent This Month</small><p class="amount">$0.00</p></div></div>
                    <div class="widget"><div class="widget-icon" style="color: #10b981; background-color: #d1fae5;"><i class="fa-solid fa-arrow-up"></i></div><div class="widget-info"><small>Income This Month</small><p class="amount">$0.00</p></div></div>
                </div>
            </section>
            
            <?php if ($cardToken): ?>
            <section class="revealed-details-section">
                <h3>Card Details</h3>
                <div class="details-grid">
                    <div class="detail-item-group">
                        <label>Card Number</label>
                        <div class="secure-field" id="revealedCardNumber"></div>
                    </div>
                    <div class="detail-item-group">
                        <label>CVV</label>
                        <div class="secure-field" id="revealedCvv"></div>
                    </div>
                </div>
                
                <div class="billing-address-section">
                    <label><i class="fa-solid fa-map-marker-alt"></i> Card Billing Address</label>
                    <div class="address-box">
                        <div class="address-item">
                            <span class="address-label">Address:</span>
                            <span class="address-value">1007 N Orange St. 4th Floor</span>
                        </div>
                        <div class="address-item">
                            <span class="address-label">City:</span>
                            <span class="address-value">Wilmington</span>
                        </div>
                        <div class="address-item">
                            <span class="address-label">State:</span>
                            <span class="address-value">Delaware</span>
                        </div>
                        <div class="address-item">
                            <span class="address-label">Zip Code:</span>
                            <span class="address-value">19801</span>
                        </div>
                        <div class="address-item">
                            <span class="address-label">Country:</span>
                            <span class="address-value">United States</span>
                        </div>
                    </div>
                    <small class="copy-notice">Use this address for online purchases when required.</small>
                </div>
            </section>
            <?php endif; ?>

            <section class="transactions-section" id="transactions-section">
                 <div class="section-header"><h2>Recent Transactions</h2><a href="transactions.php" class="view-all">View All</a></div>
                 <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="amount-header">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($api_error_transactions)): ?>
                                <tr><td colspan="4" style="text-align: center; color: var(--danger);"><?= htmlspecialchars($api_error_transactions) ?></td></tr>
                            <?php elseif (empty($transactions)): ?>
                                <tr><td colspan="4" style="text-align: center;">No recent transactions found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($transactions as $transaction): ?>
                                    <?php
                                        $transactionName = $transaction['merchant']['name'] ?? 'N/A';
                                        $amount = $transaction['amount'] ?? 0;
                                        $currency = $transaction['currency'] ?? '';
                                        $formattedAmount = number_format(abs($amount), 2);
                                        
                                        $utc_date = $transaction['createdAt'] ?? null;
                                        $formattedDate = 'N/A';
                                        if ($utc_date) {
                                            $date = new DateTime($utc_date);
                                            $date->setTimezone(new DateTimeZone('Africa/Douala')); // WAT timezone
                                            $formattedDate = $date->format('M j, Y, g:i A');
                                        }
                                        $status = $transaction['type'] ?? 'unknown';
                                        $statusClass = 'status-' . htmlspecialchars(strtolower($status));
                                        
                                        $isDebit = $amount < 0;
                                        $amountClass = $isDebit ? 'amount-debit' : 'amount-credit';
                                        $amountPrefix = $isDebit ? '-' : '+';
                                        $iconClass = $isDebit ? 'fa-arrow-down' : 'fa-arrow-up';
                                        $iconBgColor = $isDebit ? '#fddbde' : '#d1fae5';
                                        $iconColor = $isDebit ? '#f43f5e' : '#10b981';
                                    ?>
                                    <tr>
                                        <td data-label="Description">
                                            <div class="desc-cell">
                                                <div class="desc-icon" style="background-color: <?= $iconBgColor ?>; color: <?= $iconColor ?>;"><i class="fa-solid <?= $iconClass ?>"></i></div>
                                                <span><?= htmlspecialchars($transactionName) ?></span>
                                            </div>
                                        </td>
                                        <td data-label="Date"><?= htmlspecialchars($formattedDate) ?></td>
                                        <td data-label="Status"><span class="status-pill <?= $statusClass ?>"><?= htmlspecialchars(ucfirst($status)) ?></span></td>
                                        <td data-label="Amount" class="<?= $amountClass ?>"><?= $amountPrefix ?>$<?= $formattedAmount ?> <?= htmlspecialchars($currency) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                 </div>
            </section>
        </main>
    </div>
    
    <a href="https://chat.whatsapp.com/FYeR3QeOUaW3KKHcAeppZ4" class="whatsapp-fab" target="_blank" rel="noopener noreferrer" title="Join our WhatsApp Group">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script type="text/javascript" src="https://js.securepro.xyz/sudo-show/1.1/ACiWvWF9tYAez4M498DHs.min.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }
        
        const cardFlipper = document.getElementById('card-flipper');
        if (cardFlipper) {
            cardFlipper.addEventListener('click', (e) => {
                if (e.target.closest('.card-actions-section') || e.target.closest('form')) {
                    return;
                }
                cardFlipper.classList.toggle('is-flipped');
            });
        }

        const cardStatusMessageDiv = document.getElementById('cardStatusMessage');
        function showCardStatusMessage(text, type) {
            cardStatusMessageDiv.textContent = text;
            cardStatusMessageDiv.className = `status-message-box visible ${type}`;
            setTimeout(() => {
                cardStatusMessageDiv.classList.remove('visible');
            }, 5000);
        }

        window.updateCardStatus = async function(cardId, newStatus, buttonElement) {
            const originalButtonText = buttonElement.innerHTML;
            buttonElement.disabled = true;
            buttonElement.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';
            showCardStatusMessage('Updating card status...', 'info');

            try {
                const response = await fetch('process_card_status_update.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ cardId: cardId, status: newStatus })
                });
                const result = await response.json();
                if (result.success) {
                    showCardStatusMessage('Card status updated successfully to ' + newStatus + '!', 'success');
                    setTimeout(() => location.reload(), 1500); 
                } else {
                    showCardStatusMessage('Failed to update card status: ' + result.message, 'error');
                }
            } catch (error) {
                showCardStatusMessage('An unexpected error occurred: ' + error.message, 'error');
            } finally {
                buttonElement.disabled = false;
                buttonElement.innerHTML = originalButtonText;
            }
        };
        
        // --- UPDATED Card Switcher Functionality ---
        const prevBtn = document.getElementById('prev-card');
        const nextBtn = document.getElementById('next-card');
        const cardPositionIndicator = document.getElementById('card-position');
        const transactionsSection = document.getElementById('transactions-section');
        const cardSecondaryActions = document.getElementById('card-secondary-actions');
        const cardNetworkLogo = document.getElementById('card-network-logo');
        
        // --- Main action links that need to be updated ---
        const mainFundLink = document.getElementById('main-fund-link');
        const mainWithdrawLink = document.getElementById('main-withdraw-link');
        const sidebarAuthLink = document.getElementById('card-authorizations-link');
        const sidebarFundLink = document.getElementById('fund-card-link');
        const sidebarWithdrawLink = document.getElementById('withdraw-card-link');
        
        <?php if (!empty($cards)): ?>
            const cardsData = <?= json_encode($cards) ?>;
            let currentCardIndex = 0;
            
            function updateNavButtons() {
                prevBtn.disabled = currentCardIndex === 0;
                nextBtn.disabled = currentCardIndex === cardsData.length - 1;
                cardPositionIndicator.textContent = `Card ${currentCardIndex + 1} of ${cardsData.length}`;
            }
            
            // This function now updates everything when the card is switched
            function loadCardData(index) {
                currentCardIndex = index;
                const card = cardsData[index];

                // 1. Update Navigation Buttons (Prev/Next)
                updateNavButtons();
                
                // 2. Update Card Visuals (Number, Expiry, Status)
                const cardFlipper = document.getElementById('card-flipper');
                cardFlipper.className = `card-flipper ${card.status === 'inactive' ? 'inactive' : ''}`;
                
                const panParts = ['****', '****', '****', card.last4 || '0000'];
                if (card.maskedPan && card.maskedPan.replace(/[^0-9*]/g, '').length === 16) {
                    const maskedPan = card.maskedPan.replace(/[^0-9*]/g, '');
                    panParts[0] = maskedPan.substring(0, 4); panParts[1] = maskedPan.substring(4, 8);
                    panParts[2] = maskedPan.substring(8, 12); panParts[3] = maskedPan.substring(12, 16);
                }
                document.querySelectorAll('.card-number span').forEach((span, i) => { span.textContent = panParts[i]; });
                document.querySelector('.card-expiry p').textContent = (card.expiryMonth || 'MM') + '/' + (card.expiryYear || 'YY');
                
                // Update card network logo based on brand
                if (cardNetworkLogo) {
                    if (card.brand === 'Visa') {
                        cardNetworkLogo.innerHTML = '<i class="fab fa-cc-visa" style="font-size: 3rem; color: white;"></i>';
                    } else {
                        cardNetworkLogo.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="60" height="40" viewBox="0 0 78 48"><circle fill="#EB001B" cx="24" cy="24" r="24"/><circle fill="#F79E1B" cx="54" cy="24" r="24" opacity=".95"/></svg>';
                    }
                }
                
                // 3. Update ALL Action Links with the new Card ID
                if (mainFundLink) mainFundLink.href = `fund_card.php?card_id=${card.card_id}`;
                if (mainWithdrawLink) mainWithdrawLink.href = `withdraw_card.php?card_id=${card.card_id}`;
                
                // Update sidebar links too
                if (sidebarAuthLink) sidebarAuthLink.href = `card_authorizations.php?card_id=${card.card_id}`;
                if (sidebarFundLink) sidebarFundLink.href = `fund_card.php?card_id=${card.card_id}`;
                if (sidebarWithdrawLink) sidebarWithdrawLink.href = `withdraw_card.php?card_id=${card.card_id}`;
                
                // 4. Update Secondary Action Buttons (Details, Status, Auth)
                updateCardSecondaryActions(card);
                
                // 5. Load associated data via AJAX
                loadCardTransactions(card.card_id);
                loadCardBalance(card.card_id); // **FIXED**: Pass card_id instead of account_id
            }
            
            function updateCardSecondaryActions(card) {
                if (!cardSecondaryActions) return;
                
                cardSecondaryActions.querySelector('form input[name="card_id_for_token"]').value = card.card_id;
                cardSecondaryActions.querySelector('#secondary-auth-link').href = `card_authorizations.php?card_id=${card.card_id}`;
                
                const existingStatusBtn = cardSecondaryActions.querySelector('.btn-status');
                if (existingStatusBtn) existingStatusBtn.remove();
                
                let statusBtn = document.createElement('button');
                statusBtn.type = 'button';

                if (card.status === 'active') {
                    statusBtn.className = 'btn btn-danger btn-status';
                    statusBtn.innerHTML = '<i class="fa-solid fa-ban"></i> Deactivate';
                    statusBtn.onclick = () => updateCardStatus(card.card_id, 'inactive', statusBtn);
                } else {
                    statusBtn.className = 'btn btn-success btn-status';
                    statusBtn.innerHTML = '<i class="fa-solid fa-check-circle"></i> Activate';
                    statusBtn.onclick = () => updateCardStatus(card.card_id, 'active', statusBtn);
                }
                
                const detailsForm = cardSecondaryActions.querySelector('form');
                if (detailsForm) {
                    detailsForm.insertAdjacentElement('afterend', statusBtn);
                }
            }
            
            async function loadCardTransactions(cardId) {
                try {
                    const response = await fetch('get_card_transactions.php?card_id=' + cardId);
                    transactionsSection.innerHTML = await response.text();
                } catch (error) {
                    console.error('Error loading transactions:', error);
                    transactionsSection.innerHTML = `<p style="text-align:center; color:red;">Failed to load transactions.</p>`;
                }
            }
            
            // **FIXED**: Function now accepts cardId and sends it to the backend
            async function loadCardBalance(cardId) {
                try {
                    const response = await fetch('get_card_balance.php?card_id=' + cardId);
                    const data = await response.json();
                    document.querySelector('.card-balance p').textContent = (response.ok && data.success) ? '$' + data.balance : '$N/A';
                } catch (error) {
                    console.error('Error loading balance:', error);
                    document.querySelector('.card-balance p').textContent = '$N/A';
                }
            }
            
            // Event listeners for navigation
            prevBtn.addEventListener('click', () => { if (currentCardIndex > 0) loadCardData(currentCardIndex - 1); });
            nextBtn.addEventListener('click', () => { if (currentCardIndex < cardsData.length - 1) loadCardData(currentCardIndex + 1); });
            
            let touchStartX = 0;
            cardFlipper.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].screenX; }, false);
            cardFlipper.addEventListener('touchend', e => {
                const touchEndX = e.changedTouches[0].screenX;
                const difference = touchStartX - touchEndX;
                if (Math.abs(difference) > 50) { // Swipe threshold
                    if (difference > 0 && !nextBtn.disabled) loadCardData(currentCardIndex + 1); // Swipe left
                    else if (difference < 0 && !prevBtn.disabled) loadCardData(currentCardIndex - 1); // Swipe right
                }
            }, false);
            
            updateNavButtons(); // Initialize on page load
        <?php endif; ?>
    });
    </script>
    
    <?php if ($cardToken): ?>
    <script type="text/javascript">
        try {
            const vaultId = "<?= htmlspecialchars($sudo_vault_id) ?>";
            const cardToken = "<?= $cardToken ?>";
            const cardId = "<?= $cardId_from_form ?>";

            const numberSecret = SecureProxy.create(vaultId);
            const cvv2Secret = SecureProxy.create(vaultId);

            numberSecret.request({
                name: 'pan-text', method: 'GET', path: `/cards/${cardId}/secure-data/number`,
                headers: { "Authorization": "Bearer " + cardToken }, htmlWrapper: 'text',
                jsonPathSelector: 'data.number', style: { 'height': '100%', 'width': '100%' },
                serializers: [ numberSecret.SERIALIZERS.replace('(\\d{4})(\\d{4})(\\d{4})(\\d{4})', '$1 $2 $3 $4') ]
            }).render('#revealedCardNumber');

            cvv2Secret.request({
                name: 'cvv-text', method: 'GET', path: `/cards/${cardId}/secure-data/cvv2`,
                headers: { "Authorization": "Bearer " + cardToken }, htmlWrapper: 'text',
                jsonPathSelector: 'data.cvv2', style: { 'height': '100%', 'width': '100%' },
                serializers: []
            }).render('#revealedCvv');

        } catch (e) {
            console.error("Failed to initialize or render SecureProxy.", e);
            document.getElementById('revealedCardNumber').innerHTML = '<span style="color:red;font-size:0.8rem;">Error loading details.</span>';
        }
    </script>
    <?php endif; ?>
</body>
</html>