<?php
session_start();

$email = isset($_SESSION['signup_email']) ? htmlspecialchars($_SESSION['signup_email']) : 'your email address';

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';

unset($_SESSION['message']);
unset($_SESSION['message_type']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Your Email - Rovicc</title>
    <link rel="stylesheet" href="css/auth-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-icon">
                <i class="fa-solid fa-envelope-open-text"></i>
            </div>
            <h1>Check Your Inbox</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?= htmlspecialchars($message_type) ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <p>We've sent a verification link to <strong><?= $email ?></strong>. Please click the link in that email to activate your account and complete your setup.</p>
            <div class="auth-footer-link">
                Didn't receive it? 
                <a href="resend-verification.php?email=<?= urlencode($email === 'your email address' ? '' : $email) ?>">Resend link</a> 
                or <a href="login.php">go back to login</a>.
            </div>
        </div>
    </div>
</body>
</html>