<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../config/smtp_config.php'; // Use the new centralized config

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "Please enter a valid email address.";
        $_SESSION['message_type'] = 'danger';
        header("Location: forgot-password.php");
        exit();
    }

    try {
        $stmt = $pdo->prepare("SELECT id, first_name FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $resetToken = bin2hex(random_bytes(50));
            $resetExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $updateStmt = $pdo->prepare("UPDATE users SET password_reset_token = ?, password_reset_expiry = ? WHERE id = ?");
            $updateStmt->execute([$resetToken, $resetExpiry, $user['id']]);

            // Send the email
            $mail = get_mailer(); // Get the configured mailer
            try {
                $mail->setFrom('mail@rovicc.com', 'Rovicc Support');
                $mail->addAddress($email, $user['first_name']);

                $mail->isHTML(true);
                $mail->Subject = 'Your Rovicc Password Reset Request';
                $resetLink = "http://card.rovicc.com/user/reset-password.php?token=" . $resetToken;

                $emailTemplate = file_get_contents(__DIR__ . '/emails/password-reset-email.html');
                $emailBody = str_replace(['{{NAME}}', '{{RESET_LINK}}'], [$user['first_name'], $resetLink], $emailTemplate);
                $mail->Body = $emailBody;

                $mail->send();
            } catch (Exception $e) {
                // Log the error, but don't expose it to the user for security reasons.
                error_log("Mailer Error (Password Reset): {$mail->ErrorInfo}");
            }
        }

        // For security, always show the same message whether the user exists or not
        $_SESSION['message'] = "If an account with that email exists, a password reset link has been sent.";
        $_SESSION['message_type'] = 'success';
        header("Location: forgot-password.php");
        exit();

    } catch (PDOException $e) {
        error_log($e->getMessage());
        $_SESSION['message'] = "A database error occurred. Please try again later.";
        $_SESSION['message_type'] = 'danger';
        header("Location: forgot-password.php");
        exit();
    }
} else {
    header("Location: forgot-password.php");
    exit();
}
