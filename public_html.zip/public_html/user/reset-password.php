<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

$token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_STRING);
$message = '';
$message_type = 'danger';
$token_valid = false;

if (empty($token)) {
    $message = "Invalid password reset request. The token is missing.";
} else {
    try {
        $stmt = $pdo->prepare("SELECT id, password_reset_expiry FROM users WHERE password_reset_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if ($user) {
            $now = new DateTime();
            $expiry = new DateTime($user['password_reset_expiry']);
            if ($now > $expiry) {
                $message = "Your password reset token has expired. Please request a new one.";
            } else {
                $token_valid = true;
            }
        } else {
            $message = "This password reset token is invalid or has already been used.";
        }
    } catch (PDOException $e) {
        $message = "A database error occurred. Please try again later.";
        error_log($e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $token_valid) {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($password) || empty($confirm_password)) {
        $message = "Please enter and confirm your new password.";
    } elseif ($password !== $confirm_password) {
        $message = "The passwords you entered do not match.";
    } elseif (strlen($password) < 8) {
        $message = "Your new password must be at least 8 characters long.";
    } else {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ?, password_reset_token = NULL, password_reset_expiry = NULL WHERE id = ?");
            $stmt->execute([$hashedPassword, $user['id']]);

            $message = "Your password has been successfully reset! You can now log in with your new password.";
            $message_type = 'success';
            $token_valid = false; 
        } catch (PDOException $e) {
            $message = "A critical error occurred while updating your password. Please try again.";
            error_log($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Rovicc</title>
    <link rel="stylesheet" href="css/auth-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
             <div class="auth-icon">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h1>Create a New Password</h1>
            <?php if (!$token_valid): ?>
                <p>This link is invalid or has expired. Please request a new password reset link.</p>
            <?php else: ?>
                <p>Your new password must be at least 8 characters long and different from previous passwords.</p>
            <?php endif; ?>
            
            <?php if ($message): ?>
                <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <?php if ($token_valid): ?>
            <form action="reset-password.php?token=<?= htmlspecialchars($token) ?>" method="POST" class="auth-form">
                <div class="form-group">
                    <label for="password">New Password</label>
                     <div class="input-wrapper">
                         <i class="fa-solid fa-lock form-icon"></i>
                        <input type="password" name="password" id="password" required placeholder="Minimum 8 characters">
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <div class="input-wrapper">
                         <i class="fa-solid fa-lock form-icon"></i>
                        <input type="password" name="confirm_password" id="confirm_password" required placeholder="Re-enter your new password">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary auth-button">Reset Password</button>
            </form>
            <?php elseif ($message_type === 'success'): ?>
                 <p class="auth-footer-link"><a href="login.php">Proceed to Login</a></p>
            <?php else: ?>
                <p class="auth-footer-link"><a href="forgot-password.php">Request a new link</a></p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>