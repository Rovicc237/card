<?php
session_start();
// All necessary includes
require_once __DIR__ . '/../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// Fetch user data, specifically their KYC status and feedback
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Security: Only allow access to this page if KYC status is 'Rejected'
if ($user['kyc_status'] !== 'Rejected') {
    header("Location: dashboard.php");
    exit();
}

$firstName = htmlspecialchars($user['first_name'] ?? 'User');
$kyc_feedback = $user['kyc_feedback'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resubmit KYC Documents - Rovicc</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/resubmit-page.css">
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <aside class="sidebar">
             <div class="sidebar-header">
                <a href="dashboard.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="#"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="#"><i class="fa-solid fa-receipt"></i> Transactions</a></li>
                    <li><a href="#"><i class="fa-solid fa-chart-pie"></i> Analytics</a></li>
                    <li><a href="#"><i class="fa-solid fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                 <ul>
                    <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Resubmit KYC Documents</h1>
                    <p>Please upload new documents based on the feedback provided.</p>
                </div>
                 <a href="dashboard.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <section class="resubmit-section-grid">
                <div class="feedback-card">
                    <h4><i class="fa-solid fa-comment-dots"></i> Feedback From Our Team</h4>
                    <p><?= !empty($kyc_feedback) ? htmlspecialchars($kyc_feedback) : 'No specific feedback was provided. Please ensure your documents are clear, valid, and not expired.' ?></p>
                </div>

                <div class="form-card">
                    <form action="resubmit_kyc.php" method="POST" enctype="multipart/form-data" id="resubmit-form">
                        <div class="upload-group">
                            <label for="profile_picture"><i class="fa-solid fa-camera-retro"></i> New Selfie Picture</label>
                            <label class="file-input-wrapper">
                                <span class="file-input-text">Click to upload a file</span>
                                <span class="file-input-hint">PNG, JPG, or PDF (MAX. 5MB)</span>
                                <span class="file-name" id="profile_picture_name"></span>
                                <input type="file" name="profile_picture" id="profile_picture" accept="image/jpeg, image/png, application/pdf" required>
                            </label>
                        </div>
                        <div class="upload-group">
                            <label for="id_card_front"><i class="fa-solid fa-id-card"></i> New ID Card (Front)</label>
                             <label class="file-input-wrapper">
                                <span class="file-input-text">Click to upload a file</span>
                                <span class="file-input-hint">PNG, JPG, or PDF (MAX. 5MB)</span>
                                <span class="file-name" id="id_card_front_name"></span>
                                <input type="file" name="id_card_front" id="id_card_front" accept="image/jpeg, image/png, application/pdf" required>
                            </label>
                        </div>
                        <div class="upload-group">
                            <label for="id_card_back"><i class="fa-solid fa-id-card-clip"></i> New ID Card (Back)</label>
                             <label class="file-input-wrapper">
                                <span class="file-input-text">Click to upload a file</span>
                                <span class="file-input-hint">PNG, JPG, or PDF (MAX. 5MB)</span>
                                <span class="file-name" id="id_card_back_name"></span>
                                <input type="file" name="id_card_back" id="id_card_back" accept="image/jpeg, image/png, application/pdf" required>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary submit-btn">Submit for Review <i class="fa-solid fa-paper-plane"></i></button>
                    </form>
                </div>
            </section>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Standard dashboard script for sidebar toggle
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }

            // Script to display file names in the custom upload fields
            function setupFileInput(inputId, nameId) {
                const input = document.getElementById(inputId);
                const nameDisplay = document.getElementById(nameId);
                if (input && nameDisplay) {
                    input.addEventListener('change', function(e) {
                        if (e.target.files && e.target.files[0]) {
                            nameDisplay.textContent = e.target.files[0].name;
                        } else {
                            nameDisplay.textContent = '';
                        }
                    });
                }
            }

            setupFileInput('profile_picture', 'profile_picture_name');
            setupFileInput('id_card_front', 'id_card_front_name');
            setupFileInput('id_card_back', 'id_card_back_name');
        });
    </script>
</body>
</html>