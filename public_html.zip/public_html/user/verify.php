<?php
// public_html/user/verify.php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../config/smtp_config.php';

$is_successful = false;
$user_name = 'User';
$page_title = 'Account Verification';
$display_message = '';
$is_error = false;
$final_message_heading = 'Verification Complete!';
$final_message_body = 'Your account is now active. You will be redirected to the login page automatically.';

$token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_STRING);

if (empty($token)) {
    $is_error = true;
    $display_message = "No verification token was provided. The link may be incomplete or invalid.";
} else {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE verification_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if (!$user) {
            $is_error = true;
            $display_message = "This verification link is invalid or has already been used. Please try logging in.";
        } elseif ($user['is_verified'] == 1) {
            $is_successful = true;
            $user_name = htmlspecialchars($user['first_name']);
            $final_message_heading = 'Account Already Active!';
            $final_message_body = 'This account was already verified. You will be redirected to the login page.';
        } else {
            $now = new DateTime();
            $expiry = new DateTime($user['token_expiry']);

            if ($now > $expiry) {
                $is_error = true;
                $display_message = "Your verification link has expired. Please request a new one from the login page.";
            } else {
                $user_name = htmlspecialchars($user['first_name']);
                
                // Start Transaction
                $pdo->beginTransaction();

                // 1. Update user status in DB
                $updateSql = "UPDATE users SET is_verified = 1, verification_token = NULL, token_expiry = NULL WHERE id = ?";
                $updateStmt = $pdo->prepare($updateSql);
                $updateStmt->execute([$user['id']]);

                // 2. Send Admin Notification Email on Verification
                try {
                    $stmt_admin = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key = 'notification_email'");
                    $admin_email = $stmt_admin->fetchColumn();
                    if ($admin_email) {
                        $mail_admin = get_mailer();
                        $mail_admin->setFrom('mail@rovicc.com', 'Rovicc Notifier');
                        $mail_admin->addAddress($admin_email);
                        $mail_admin->isHTML(true);
                        $mail_admin->Subject = 'User Account Verified';
                        $mail_admin->Body = "A new user has successfully verified their account:<br><br>" .
                            "<b>Name:</b> " . htmlspecialchars($user['first_name']) . " " . htmlspecialchars($user['last_name']) . "<br>" .
                            "<b>Email:</b> " . htmlspecialchars($user['email']) . "<br>" .
                            "<b>User ID:</b> " . $user['id'] . "<br><br>" .
                            "The user's documents are ready for KYC review in the admin panel.";
                        $mail_admin->send();
                    }
                } catch (Exception $e) {
                    error_log("Admin verification notification failed for user {$user['id']}: " . $e->getMessage());
                }
                
                // 3. Commit Transaction
                $pdo->commit();
                $is_successful = true;
            }
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $is_error = true;
        $display_message = "A database error occurred during verification. Please contact support.";
        error_log($e->getMessage());
    }
}

if ($is_error) {
    $page_title = 'Verification Failed';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> - Rovicc</title>
    <link rel="stylesheet" href="css/auth-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Roboto+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="verification-process-box">
             <?php if ($is_error): ?>
                <div class="auth-icon" style="color: var(--danger); animation: none;"><i class="fa-solid fa-circle-xmark"></i></div>
                <h1>Verification Failed</h1>
                <p class="alert alert-danger" style="text-align: center;"><?= htmlspecialchars($display_message) ?></p>
                <a href="login.php" class="btn btn-primary" style="margin-top: 20px;">Return to Login</a>
            <?php else: ?>
                <div class="auth-icon" style="animation: none;"><i class="fa-solid fa-user-shield"></i></div>
                <h1>Verifying Your Account</h1>
                <p class="sub-text">Hi <?= $user_name ?>, please wait while we finalize your account activation...</p>
                
                <div class="progress-bar-container">
                    <div class="progress-bar" id="progressBar"></div>
                </div>

                <ul class="verification-steps">
                 <li class="verification-step" id="step1"><span class="status-icon"><i class="fa-solid fa-spinner fa-spin"></i></span><span class="status-text">Validating KYC...</span></li>
                     <li class="verification-step" id="step1"><span class="status-icon"><i class="fa-solid fa-spinner fa-spin"></i></span><span class="status-text">Validating Token...</span></li>
                     <li class="verification-step" id="step2"><span class="status-icon"><i class="fa-solid fa-spinner fa-spin"></i></span><span class="status-text">Activating Account...</span></li>
                     <li class="verification-step" id="step3"><span class="status-icon"><i class="fa-solid fa-spinner fa-spin"></i></span><span class="status-text">Sending Confirmation...</span></li>
                     <li class="verification-step" id="step4"><span class="status-icon"><i class="fa-solid fa-spinner fa-spin"></i></span><span class="status-text">Finalizing Setup...</span></li>
                </ul>

                <div id="final-message" style="display: none;">
                    <h2><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($final_message_heading) ?></h2>
                    <p><?= htmlspecialchars($final_message_body) ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($is_successful): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const steps = [
                { id: 'step1', duration: 2500 },
                { id: 'step2', duration: 2000 },
                { id: 'step3', duration: 1700 },
                { id: 'step4', duration: 1100 }
            ];
            
            const progressBar = document.getElementById('progressBar');
            const finalMessage = document.getElementById('final-message');
            const totalDuration = steps.reduce((sum, step) => sum + step.duration, 0);
            let progress = 0;
            let currentStep = 0;
            
            function processStep() {
                if (currentStep >= steps.length) {
                    progressBar.style.width = '100%';
                    finalMessage.style.display = 'block';
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 4000);
                    return;
                }
                
                const stepElement = document.getElementById(steps[currentStep].id);
                stepElement.classList.add('active');
                
                setTimeout(() => {
                    const icon = stepElement.querySelector('.status-icon i');
                    icon.classList.remove('fa-spinner', 'fa-spin');
                    icon.classList.add('fa-check-circle');

                    progress += (steps[currentStep].duration / totalDuration) * 100;
                    progressBar.style.width = Math.min(progress, 100) + '%';
                    
                    currentStep++;
                    processStep();
                }, steps[currentStep].duration);
            }
            
            setTimeout(processStep, 500);
        });
    </script>
    <?php endif; ?>
</body>
</html>