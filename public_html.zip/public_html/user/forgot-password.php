<?php
session_start();
$message = '';
$message_type = '';

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = $_SESSION['message_type'];
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Rovicc</title>
    <link rel="stylesheet" href="css/auth-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-icon">
                <i class="fa-solid fa-key"></i>
            </div>
            <h1>Forgot Your Password?</h1>
            <p>No problem. Enter the email address associated with your Rovicc account, and we will send you a link to reset your password.</p>

            <?php if ($message): ?>
                <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form action="send-password-reset.php" method="POST" class="auth-form">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-envelope form-icon"></i>
                        <input type="email" id="email" name="email" placeholder="you@example.com" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary auth-button">Send Reset Link</button>
            </form>
            <p class="auth-footer-link">Remembered your password? <a href="login.php">Log In</a></p>
        </div>
    </div>
</body>
</html>