<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

$card_id = filter_input(INPUT_GET, 'card_id', FILTER_SANITIZE_STRING);
$authorizations = [];
$api_error_message = '';

if (empty($card_id)) {
    $api_error_message = "Card ID is missing. Cannot fetch authorizations.";
} else {
    try {
        // Verify that the card belongs to the logged-in user
        $stmt_verify_card = $pdo->prepare("SELECT id FROM virtual_cards WHERE card_id = ? AND user_id = ? LIMIT 1");
        $stmt_verify_card->execute([$card_id, $user_id]);
        $card_exists = $stmt_verify_card->fetch();

        if (!$card_exists) {
            $api_error_message = "Card not found or does not belong to your account.";
        } else {
            // Fetch Sudo API key and base URL from admin settings
            $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
            $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
            $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
            $sudo_base_url = $api_settings['sudo_base_url'] ?? null;

            if (empty($sudo_api_key) || empty($sudo_base_url)) {
                $api_error_message = "API credentials are not configured by the administrator.";
            } else {
                // Use precise date and time for a full two-year history
                $toDate = date('c'); // ISO 8601 format for current time
                $fromDate = date('c', strtotime('-2 years'));
                $page = 0;
                $limit = 1000; // A large limit to get all authorizations

                $queryParams = http_build_query([
                    'page' => $page,
                    'limit' => $limit,
                    'fromDate' => $fromDate,
                    'toDate' => $toDate
                ]);

                $requestUrl = rtrim($sudo_base_url, '/') . '/cards/' . $card_id . '/authorizations?' . $queryParams;

                $ch = curl_init();
                curl_setopt_array($ch, [
                    CURLOPT_URL => $requestUrl,
                    CURLOPT_HTTPGET => true,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => [
                        "Authorization: Bearer {$sudo_api_key}",
                        "Content-Type: application/json",
                    ],
                    CURLOPT_CONNECTTIMEOUT => 10,
                    CURLOPT_TIMEOUT => 30,
                ]);
                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $curlError = curl_error($ch);
                curl_close($ch);

                if ($curlError) {
                    $api_error_message = "cURL Error: " . $curlError;
                } elseif ($httpCode != 200) {
                    $api_error_message = "API Error: Received HTTP code " . $httpCode . ". Response: " . $response;
                } else {
                    $response_data = json_decode($response, true);
                    if (isset($response_data['data'])) {
                        $authorizations = $response_data['data'];
                        
                        // Sort authorizations by date in descending order (newest first)
                        usort($authorizations, function($a, $b) {
                            return strtotime($b['createdAt']) - strtotime($a['createdAt']);
                        });

                    } else {
                        $api_error_message = "API response did not contain expected data. Raw response: " . $response;
                    }
                }
            }
        }
    } catch (PDOException $e) {
        $api_error_message = "A database error occurred while fetching card details.";
        error_log("Card Authorizations DB Error: " . $e->getMessage());
    } catch (Exception $e) {
        $api_error_message = "An unexpected error occurred: " . $e->getMessage();
        error_log("Card Authorizations General Error: " . $e->getMessage());
    }
}

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);

// Determine active class for 'My Cards'
$my_cards_active = '';
if (in_array($current_page, ['create_card.php', 'payment_page.php', 'card_creation_status.php', 'card_payment_status.php'])) {
    $my_cards_active = 'active';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Authorizations - Rovicc</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        /* General section and heading styles (reused from dashboard.css but customized here) */
        .authorizations-section {
            background: var(--white);
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }
        .authorizations-section h2 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }
        .authorizations-section p.intro-text {
            color: var(--text-light);
            margin-bottom: 20px;
            font-size: 0.95rem;
        }
        .error-message {
            color: var(--danger);
            background-color: #fee2e2;
            border: 1px solid #fca5a5;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .no-data-message {
            text-align: center;
            padding: 40px;
            color: var(--text-light);
            font-style: italic;
        }

        /* Table specific styles for authorizations - ENHANCED */
        .authorizations-table-container {
            overflow-x: auto;
            margin-top: 20px;
            border: 1px solid var(--border-color); /* Added table border */
            border-radius: var(--radius);
            box-shadow: 0 2px 8px rgba(0,0,0,0.03); /* Subtle shadow for table */
        }
        .authorizations-table {
            width: 100%;
            border-collapse: collapse;
        }
        .authorizations-table th,
        .authorizations-table td {
            padding: 14px 15px; /* Increased padding */
            text-align: left;
            white-space: nowrap;
            border-bottom: 1px solid var(--border-color);
        }
        .authorizations-table th {
            font-size: 0.75rem;
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
            background-color: var(--background); /* Light background for header */
        }
        .authorizations-table tbody tr:hover {
            background-color: #fcfcff; /* Subtle hover effect */
        }
        .auth-amount {
            font-weight: 600;
        }
        .amount-debit { color: #b91c1c; }
        .amount-credit { color: #065f46; }

        /* Status Pill Styling - Consistent and clearer */
        .status-pill {
            display: inline-block;
            padding: 6px 12px; /* Adjusted padding */
            border-radius: 20px;
            font-size: 0.75rem; /* Adjusted font size */
            font-weight: 600;
            text-align: center;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        .status-approved {
            background-color: #d1fae5; /* Light green */
            color: #065f46; /* Darker green */
        }
        .status-declined {
            background-color: #fee2e2; /* Light red */
            color: #991b1b; /* Darker red */
        }
        .status-pending {
            background-color: #fef3c7; /* Light yellow */
            color: #9a3412; /* Darker yellow/orange */
        }
        .status-reversed { /* Example for a 'reversed' status, adjust as needed */
            background-color: #e0e7ff;
            color: var(--info);
        }

        .reason-declined {
            color: #b91c1c;
            font-weight: 600;
        }

        /* Responsive adjustments for table */
        @media (max-width: 768px) {
            .authorizations-table-container {
                border: none; /* Remove outer border on small screens */
                box-shadow: none;
            }
            .authorizations-table thead {
                display: none;
            }
            .authorizations-table tr {
                display: block;
                background: var(--white);
                border-radius: var(--radius);
                margin-bottom: 15px;
                padding: 15px;
                border: 1px solid var(--border-color);
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            }
            .authorizations-table td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 0;
                border: none;
                text-align: right;
                white-space: normal;
            }
            .authorizations-table td:not(:last-child) {
                border-bottom: 1px solid #f0f0f0;
            }
            .authorizations-table td:before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--text-dark);
                text-align: left;
                padding-right: 15px;
            }
        }
    </style>
</head>
<body>
    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating a user.
            <a href="../../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><a href="/user/dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="/user/dashboard.php" class="<?= ($current_page == 'dashboard.php') ? 'active' : '' ?>"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="/user/SudoCard/create_card.php" class="<?= $my_cards_active ?>"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="/user/deposit/deposit.php" class="<?= ($current_page == 'deposit.php') ? 'active' : '' ?>"><i class="fa-solid fa-money-bill-transfer"></i> Deposit</a></li>
                    <li><a href="/user/deposit_history.php" class="<?= ($current_page == 'deposit_history.php') ? 'active' : '' ?>"><i class="fa-solid fa-clock-rotate-left"></i> Deposit History</a></li>
                    <li><a href="/user/transactions.php" class="<?= ($current_page == 'transactions.php') ? 'active' : '' ?>"><i class="fa-solid fa-receipt"></i> Card Transactions</a></li>
                    <li><a href="/user/card_authorizations.php" class="active"><i class="fa-solid fa-file-contract"></i> Authorizations</a></li>
                   
                   
                    <li><a href="/user/referral.php" class="<?= ($current_page == 'referral.php') ? 'active' : '' ?>"><i class="fa-solid fa-users"></i> Referrals</a></li>
                    <li><a href="#"><i class="fa-solid fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="/user/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h6>Card Authorization History</h6>
                    <p>Review all payment authorization attempts for your card.</p>
                </div>
                <a href="/user/dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> </a>
            </header>

            <section class="authorizations-section">
                <h4>Recent Authorization Attempts</h4>
              

                <?php if (!empty($api_error_message)): ?>
                    <div class="error-message">
                        <p><?= htmlspecialchars($api_error_message) ?></p>
                    </div>
                <?php elseif (empty($authorizations)): ?>
                    <div class="no-data-message">
                        <p>No authorization attempts found for this card in the selected period.</p>
                    </div>
                <?php else: ?>
                    <div class="authorizations-table-container">
                        <table class="authorizations-table">
                            <thead>
                                <tr>
                                    <th>Merchant</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Reason</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($authorizations as $auth): ?>
                                    <?php
                                        $merchantName = htmlspecialchars($auth['merchant']['name'] ?? 'N/A');
                                        // --- FIX: Use the exact amount from the API and handle formatting ---
                                        $amount = $auth['amount'] ?? 0;
                                        $currency = htmlspecialchars($auth['currency'] ?? 'USD');
                                        $formattedAmount = number_format(abs($amount), 2);
                                        $isDebit = $amount < 0;
                                        $amountClass = $isDebit ? 'amount-debit' : 'amount-credit';
                                        $amountPrefix = $isDebit ? '-' : '+';

                                        $statusText = 'Unknown';
                                        $statusClass = 'status-unknown';
                                        if (isset($auth['approved'])) {
                                            if ($auth['approved']) {
                                                $statusText = 'Approved';
                                                $statusClass = 'status-approved';
                                            } else {
                                                $statusText = 'Declined';
                                                $statusClass = 'status-declined';
                                            }
                                        } elseif (isset($auth['status'])) {
                                            $statusText = ucfirst(htmlspecialchars($auth['status']));
                                            $statusClass = 'status-' . htmlspecialchars(strtolower($auth['status']));
                                        }

                                        $reason = 'N/A';
                                        if (!$auth['approved'] && !empty($auth['requestHistory'])) {
                                            $latestRequest = $auth['requestHistory'][0]; // Assuming latest is first
                                            $reason_from_api = $latestRequest['narration'] ?? $latestRequest['reason'] ?? 'No specific reason';

                                            if (stripos($reason_from_api, 'insufficient fund') !== false) {
                                                $reason = 'Insufficient funds on the card.';
                                            } else {
                                                $reason = htmlspecialchars($reason_from_api);
                                            }
                                        }

                                        $utc_date = $auth['createdAt'] ?? null;
                                        $formattedDate = 'N/A';
                                        if ($utc_date) {
                                            $date = new DateTime($utc_date);
                                            $date->setTimezone(new DateTimeZone('Africa/Douala')); // WAT timezone
                                            $formattedDate = $date->format('M j, Y, g:i A');
                                        }
                                    ?>
                                    <tr>
                                        <td data-label="Merchant"><?= $merchantName ?></td>
                                        <td data-label="Amount" class="auth-amount <?= $amountClass ?>"><?= $amountPrefix ?>$<?= $formattedAmount ?> <?= $currency ?></td>
                                        <td data-label="Status"><span class="status-pill <?= $statusClass ?>"><?= $statusText ?></span></td>
                                        <td data-label="Reason" class="<?= !$auth['approved'] ? 'reason-declined' : '' ?>"><?= $reason ?></td>
                                        <td data-label="Date"><?= $formattedDate ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>
