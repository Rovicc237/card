<?php
// public_html/user/resubmit_kyc.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../config/smtp_config.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (empty($_FILES['profile_picture']['tmp_name']) || empty($_FILES['id_card_front']['tmp_name']) || empty($_FILES['id_card_back']['tmp_name'])) {
    $_SESSION['message'] = "All three documents are required for resubmission.";
    $_SESSION['message_type'] = 'danger';
    header("Location: resubmit_documents.php");
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT first_name, last_name, email FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    if (!$user) { throw new Exception("User not found."); }

    $safe_user_name = strtolower(preg_replace('/[^a-zA-Z0-9]/', '_', $user['first_name'] . '_' . $user['last_name']));
    $user_upload_dir = dirname(__DIR__, 2) . '/kyc_documents/' . $safe_user_name . '/';
    if (!is_dir($user_upload_dir)) { mkdir($user_upload_dir, 0755, true); }

    function handle_upload($file_key, $file_type, $destination_dir) {
        if ($file_key['error'] !== UPLOAD_ERR_OK) return [false, "Error uploading {$file_type}."];
        $allowed_types = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];
        $file_info = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $file_info->file($file_key['tmp_name']);
        if (!in_array($mime_type, $allowed_types)) return [false, "Invalid file type for {$file_type}."];
        $extension = array_search($mime_type, $allowed_types);
        $new_filename = "{$file_type}_resubmitted_" . uniqid() . ".{$extension}";
        $destination = $destination_dir . $new_filename;
        if (move_uploaded_file($file_key['tmp_name'], $destination)) {
            return [true, basename($destination_dir) . '/' . $new_filename];
        } else {
            return [false, "Could not save {$file_type} file."];
        }
    }

    $profile_pic_result = handle_upload($_FILES['profile_picture'], 'profile', $user_upload_dir);
    $id_front_result = handle_upload($_FILES['id_card_front'], 'id_front', $user_upload_dir);
    $id_back_result = handle_upload($_FILES['id_card_back'], 'id_back', $user_upload_dir);

    if (!$profile_pic_result[0] || !$id_front_result[0] || !$id_back_result[0]) {
        $error = implode(' ', array_filter([!$profile_pic_result[0] ? $profile_pic_result[1] : '', !$id_front_result[0] ? $id_front_result[1] : '', !$id_back_result[0] ? $id_back_result[1] : '']));
        throw new Exception($error);
    }

    $sql = "UPDATE users SET profile_picture = ?, id_card_front = ?, id_card_back = ?, documents_submitted_at = NOW(), kyc_status = 'Pending', kyc_feedback = NULL, kyc_reviewed_at = NULL, kyc_reviewed_by = NULL WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$profile_pic_result[1], $id_front_result[1], $id_back_result[1], $user_id]);

    $notification_message = htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) . " has RESUBMITTED KYC documents for review.";
    $notification_link = "view_user.php?id=" . $user_id;
    $notif_stmt = $pdo->prepare("INSERT INTO admin_notifications (user_id, message, link) VALUES (?, ?, ?)");
    $notif_stmt->execute([$user_id, $notification_message, $notification_link]);
    $notification_id = $pdo->lastInsertId();
    
    $stmt_admin = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key = 'notification_email'");
    $admin_email = $stmt_admin->fetchColumn();

    if ($admin_email) {
        $mail_admin = get_mailer();
        $mail_admin->setFrom('mail@rovicc.com', 'Rovicc KYC Notifier');
        $mail_admin->addAddress($admin_email);
        $mail_admin->isHTML(true);
        $mail_admin->Subject = 'KYC Document Resubmission for Review';

        $admin_template = file_get_contents(__DIR__ . '/../admin/emails/kyc_submission_admin_email.html');
        $admin_body = str_replace('{{USER_NAME}}', htmlspecialchars($user['first_name'] . ' ' . $user['last_name']), $admin_template);
        $admin_body = str_replace('{{USER_EMAIL}}', htmlspecialchars($user['email']), $admin_body);
        $admin_body = str_replace('{{SUBMISSION_TYPE}}', 'Document Resubmission', $admin_body);
        $admin_body = str_replace('{{REVIEW_LINK}}', "http://card.rovicc.com/admin/view_user.php?id=$user_id&notification_id=$notification_id", $admin_body);
        $mail_admin->Body = $admin_body;

        $mail_admin->send();
    }

    $_SESSION['message'] = "Your new documents have been submitted successfully and are pending review.";
    $_SESSION['message_type'] = 'success';

} catch (Exception $e) {
    $_SESSION['message'] = "An error occurred: " . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
    error_log("KYC Resubmission Error for user $user_id: " . $e->getMessage());
}

header("Location: dashboard.php");
exit();