<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM manual_withdrawals WHERE user_id = ? ORDER BY requested_at DESC");
    $stmt->execute([$user_id]);
    $withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Withdrawal History DB Error: " . $e->getMessage());
    die("A database error occurred. Please try again later.");
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal History - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/deposit_history.css"> 
</head>
<body>
    <div class="dashboard-container">
    <?php include 'templates/sidebar.php'; ?>
        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Withdrawal History</h1>
                    <p>Track the status of your manual withdrawal requests.</p>
                </div>
                <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </header>

            <section class="transactions-section">
                <div class="table-container">
                    <?php if (empty($withdrawals)): ?>
                        <div class="no-transactions-message">
                            <p>You have not made any withdrawal requests yet.</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Date Requested</th>
                                    <th>Amount (USD)</th>
                                    <th>Mobile Money Number</th>
                                    <th>Status</th>
                                    <th>Date Processed</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($withdrawals as $withdrawal): ?>
                                    <tr>
                                        <td>#<?= htmlspecialchars($withdrawal['id']) ?></td>
                                        <td><?= date("M j, Y, g:i A", strtotime($withdrawal['requested_at'])) ?></td>
                                        <td class="amount-usd">$<?= number_format($withdrawal['amount'], 2) ?></td>
                                        <td><?= htmlspecialchars($withdrawal['mobile_money_number']) ?></td>
                                        <td>
                                            <?php
                                                $status_class = 'status-default';
                                                if ($withdrawal['status'] === 'approved') $status_class = 'status-successful';
                                                if ($withdrawal['status'] === 'pending') $status_class = 'status-pending';
                                                if ($withdrawal['status'] === 'rejected') $status_class = 'status-failed';
                                            ?>
                                            <span class="status-pill <?= $status_class ?>">
                                                <?= htmlspecialchars(ucfirst($withdrawal['status'])) ?>
                                            </span>
                                        </td>
                                        <td><?= $withdrawal['processed_at'] ? date("M j, Y, g:i A", strtotime($withdrawal['processed_at'])) : 'N/A' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>