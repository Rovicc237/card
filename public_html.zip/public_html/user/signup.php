<?php
// public_html/user/signup.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

// Get error message from session and clear it (for non-AJAX page loads)
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);

// --- HELPER FUNCTION TO GET PHP INI SETTINGS ---
function get_ini_bytes($val) {
    $val = trim($val);
    $last = strtolower($val[strlen($val)-1]);
    $val = (int)$val;
    switch($last) {
        case 'g': $val *= 1024;
        case 'm': $val *= 1024;
        case 'k': $val *= 1024;
    }
    return $val;
}

// --- UPDATED HELPER FUNCTION FOR AJAX RESPONSES ---
function send_json_response($success, $data) {
    header('Content-Type: application/json');
    if ($success) {
        echo json_encode(array_merge(['success' => true], $data));
    } else {
        echo json_encode(['success' => false, 'error' => $data]);
    }
    // FIX: Explicitly write and close the session before exiting.
    // This prevents a race condition on fast server responses.
    session_write_close();
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- CRITICAL CHECK: Was the POST data too large? ---
    $post_max_size = get_ini_bytes(ini_get('post_max_size'));
    if (isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > $post_max_size) {
        send_json_response(false, "The files you uploaded are too large. Please make sure the total size of all files is less than " . ini_get('post_max_size') . "B.");
    }

    require_once __DIR__ . '/../../database/db.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
    require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
    require_once __DIR__ . '/../config/smtp_config.php';

    $firstName = trim(filter_input(INPUT_POST, 'firstName', FILTER_SANITIZE_STRING));
    $lastName = trim(filter_input(INPUT_POST, 'lastName', FILTER_SANITIZE_STRING));
    $phone = trim(filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING));
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = $_POST['password'];
    $dob = $_POST['dob'];
    $referral_code_input = isset($_POST['referral_code']) ? trim(strtolower(filter_input(INPUT_POST, 'referral_code', FILTER_SANITIZE_STRING))) : null;

    // --- Enhanced Form Validation ---
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($phone) || empty($dob) || empty($_FILES['profile_picture']['tmp_name']) || empty($_FILES['id_card_front']['tmp_name']) || empty($_FILES['id_card_back']['tmp_name'])) {
        send_json_response(false, "All fields and document uploads are required.");
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        send_json_response(false, "Invalid email format.");
    } elseif (strlen($password) < 8) {
        send_json_response(false, "Password must be at least 8 characters long.");
    } else {
        try {
            $validation_error = '';

            // Check for existing email
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $validation_error = "This email address is already registered.";
            }

            // Check for existing name combination
            if (empty($validation_error)) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE first_name = ? AND last_name = ?");
                $stmt->execute([$firstName, $lastName]);
                if ($stmt->fetch()) {
                    $validation_error = "A user with this first and last name already exists.";
                }
            }
            
            // Check if user is at least 15 years old
            if (empty($validation_error)) {
                $dob_datetime = new DateTime($dob);
                $today = new DateTime();
                $age = $today->diff($dob_datetime)->y;
                if ($age < 15) {
                    $validation_error = "You must be at least 15 years old to register.";
                }
            }
            
            if (!empty($validation_error)) {
                send_json_response(false, $validation_error);
            }

            // --- At this point, initial validation passed. Proceed with file handling. ---
            $safe_user_name = strtolower(preg_replace('/[^a-zA-Z0-9]/', '_', $firstName . '_' . $lastName));
            $user_upload_dir = dirname(__DIR__, 2) . '/kyc_documents/' . $safe_user_name . '/';
            
            if (!is_dir($user_upload_dir)) {
                if (!mkdir($user_upload_dir, 0755, true)) {
                    send_json_response(false, "A server error occurred (could not create directory). Please contact support.");
                }
            }
            
            if (!is_writable($user_upload_dir)) {
                error_log("Signup Error: Directory is not writable: " . $user_upload_dir);
                send_json_response(false, "A server permissions error occurred. Please contact support.");
            }

            /**
             * Compresses an image to a target size.
             */
            function compress_image($source_path, $destination_path, $target_size) {
                if (!extension_loaded('gd')) {
                    error_log('Signup Error: GD library is not loaded.');
                    return false;
                }
                $image_info = getimagesize($source_path);
                if (!$image_info) return false;
                $mime = $image_info['mime'];
                $image = null;
                switch ($mime) {
                    case 'image/jpeg': $image = imagecreatefromjpeg($source_path); break;
                    case 'image/png':
                        $image = imagecreatefrompng($source_path);
                        $bg = imagecreatetruecolor(imagesx($image), imagesy($image));
                        imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
                        imagealphablending($bg, TRUE);
                        imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
                        imagedestroy($image);
                        $image = $bg;
                        break;
                    case 'image/gif': $image = imagecreatefromgif($source_path); break;
                    case 'image/webp': $image = imagecreatefromwebp($source_path); break;
                    default: return false;
                }
                if (!$image) return false;
                for ($quality = 85; $quality >= 10; $quality -= 5) {
                    ob_start();
                    imagejpeg($image, NULL, $quality);
                    $data = ob_get_contents();
                    ob_end_clean();
                    if (strlen($data) <= $target_size) {
                        imagedestroy($image);
                        return file_put_contents($destination_path, $data) !== false;
                    }
                }
                imagedestroy($image);
                return false;
            }

            /**
             * Handles file uploads, including compression for large images.
             */
            function handle_upload($file_key, $file_type, $destination_dir) {
                if ($file_key['error'] !== UPLOAD_ERR_OK) {
                    switch ($file_key['error']) {
                        case UPLOAD_ERR_INI_SIZE: return [false, "The {$file_type} file is too large (server limit)."];
                        case UPLOAD_ERR_FORM_SIZE: return [false, "The {$file_type} file is too large (form limit)."];
                        case UPLOAD_ERR_PARTIAL: return [false, "The {$file_type} was only partially uploaded."];
                        case UPLOAD_ERR_NO_FILE: return [false, "No {$file_type} file was uploaded."];
                        default: return [false, "Error uploading {$file_type}. Please try again."];
                    }
                }
                $allowed_mimes = [
                    'jpg'  => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png'  => 'image/png', 'gif'  => 'image/gif',
                    'webp' => 'image/webp', 'heic' => 'image/heic', 'heif' => 'image/heif', 'pdf'  => 'application/pdf'
                ];
                $file_info = new finfo(FILEINFO_MIME_TYPE);
                $mime_type = $file_info->file($file_key['tmp_name']);
                if (!in_array($mime_type, $allowed_mimes)) {
                    return [false, "Invalid file type for {$file_type}. Please upload a JPG, PNG, GIF, WEBP, or PDF."];
                }
                $is_image = strpos($mime_type, 'image/') === 0;
                $file_size = $file_key['size'];
                $max_size_before_compression = 8 * 1024 * 1024; // 8MB
                $target_compressed_size = 1 * 1024 * 1024; // 1MB

                if ($is_image && $file_size > $max_size_before_compression) {
                    $new_filename = "{$file_type}_" . uniqid() . ".jpg";
                    $destination = $destination_dir . $new_filename;
                    if (compress_image($file_key['tmp_name'], $destination, $target_compressed_size)) {
                        return [true, basename($destination_dir) . '/' . $new_filename];
                    } else {
                        return [false, "The {$file_type} is too large and could not be compressed automatically. Please upload a file smaller than 8MB."];
                    }
                } else {
                    $extension = array_search($mime_type, $allowed_mimes);
                    if ($extension === false) {
                        $extension = array_keys($allowed_mimes, $mime_type)[0] ?? 'dat';
                    }
                    $new_filename = "{$file_type}_" . uniqid() . ".{$extension}";
                    $destination = $destination_dir . $new_filename;
                    if (move_uploaded_file($file_key['tmp_name'], $destination)) {
                        return [true, basename($destination_dir) . '/' . $new_filename];
                    } else {
                        return [false, "Could not save the {$file_type} file."];
                    }
                }
            }
            
            // Handle file uploads one by one to provide specific errors
            $profile_pic_result = handle_upload($_FILES['profile_picture'], 'profile', $user_upload_dir);
            if (!$profile_pic_result[0]) send_json_response(false, $profile_pic_result[1]);

            $id_front_result = handle_upload($_FILES['id_card_front'], 'id_front', $user_upload_dir);
            if (!$id_front_result[0]) send_json_response(false, $id_front_result[1]);

            $id_back_result = handle_upload($_FILES['id_card_back'], 'id_back', $user_upload_dir);
            if (!$id_back_result[0]) send_json_response(false, $id_back_result[1]);

            // All files uploaded successfully
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $verificationToken = bin2hex(random_bytes(50));
            $tokenExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $profile_pic_path = $profile_pic_result[1];
            $id_front_path = $id_front_result[1];
            $id_back_path = $id_back_result[1];

            $sql = "INSERT INTO users (first_name, last_name, phone, email, password, verification_token, token_expiry, dob, profile_picture, id_card_front, id_card_back, documents_submitted_at, referred_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
            $stmt = $pdo->prepare($sql);

            if ($stmt->execute([$firstName, $lastName, $phone, $email, $hashedPassword, $verificationToken, $tokenExpiry, $dob, $profile_pic_path, $id_front_path, $id_back_path, $referral_code_input])) {
                $user_id = $pdo->lastInsertId();
                
                $notification_message = htmlspecialchars($firstName . ' ' . $lastName) . " registered and submitted documents.";
                $notification_link = "view_user.php?id=" . $user_id;
                $notif_stmt = $pdo->prepare("INSERT INTO admin_notifications (user_id, message, link) VALUES (?, ?, ?)");
                $notif_stmt->execute([$user_id, $notification_message, $notification_link]);
                $notification_id = $pdo->lastInsertId();

                $mail_user = get_mailer();
                $mail_user->setFrom('mail@rovicc.com', 'Rovicc');
                $mail_user->addAddress($email, $firstName . ' ' . $lastName);
                $mail_user->isHTML(true);
                $mail_user->Subject = 'Verify Your Rovicc Account';
                $verificationLink = "https://rovicc.com/user/verify.php?token=" . $verificationToken;
                $emailTemplate = file_get_contents(__DIR__ . '/emails/modern_verification_template.html');
                $emailBody = str_replace(['{{NAME}}', '{{VERIFICATION_LINK}}'], [$firstName, $verificationLink], $emailTemplate);
                $mail_user->Body = $emailBody;
                $mail_user->send();

                try {
                    $stmt_admin = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key = 'notification_email'");
                    $admin_email = $stmt_admin->fetchColumn();
                    if ($admin_email) {
                        $mail_admin = get_mailer();
                        $mail_admin->setFrom('mail@rovicc.com', 'Rovicc KYC Notifier');
                        $mail_admin->addAddress($admin_email);
                        $mail_admin->isHTML(true);
                        $mail_admin->Subject = 'New User Submitted KYC Documents for Review';
                        $admin_template = file_get_contents(__DIR__ . '/../admin/emails/kyc_submission_admin_email.html');
                        $admin_body = str_replace(
                            ['{{USER_NAME}}', '{{USER_EMAIL}}', '{{SUBMISSION_TYPE}}', '{{REVIEW_LINK}}'], 
                            [htmlspecialchars($firstName . ' ' . $lastName), htmlspecialchars($email), 'Initial Registration', "https://rovicc.com/admin/view_user.php?id=$user_id&notification_id=$notification_id"], 
                            $admin_template
                        );
                        $mail_admin->Body = $admin_body;
                        $mail_admin->send();
                    }
                } catch (Exception $e) {
                    error_log("Admin Notification Email Error on Signup: " . $e->getMessage());
                }

                // --- FINAL SUCCESS POINT ---
                $_SESSION['signup_email'] = $email;
                $_SESSION['success'] = "Registration successful! Please check your email to verify your account.";
                send_json_response(true, ['redirectUrl' => 'check-email.php']);
            }
        } catch (PDOException | Exception $e) {
            error_log("Signup Error: " . $e->getMessage());
            send_json_response(false, "A system error occurred. Please try again later.");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Rovicc</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="css/auth-style.css">
    <style>
    .whatsapp-help { text-align: center; margin-top: 20px; padding: 15px; background-color: #e6f7e9; border: 1px solid #c7e8ca; border-radius: 8px; }
    .whatsapp-help a { font-size: 2.5rem; color: #25D366; text-decoration: none; transition: transform 0.2s; display: inline-block; }
    .whatsapp-help a:hover { transform: scale(1.1); }
    .whatsapp-help p { margin: 10px 0 0; color: #386641; font-size: 0.9rem; line-height: 1.4; }
    
    /* --- Progress Bar Styles --- */
    #progress-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.8);
        display: none; /* Hidden by default */
        justify-content: center;
        align-items: center;
        z-index: 9999;
        color: white;
        text-align: center;
        backdrop-filter: blur(5px);
    }
    .progress-container { width: 80%; max-width: 500px; }
    .progress-bar-wrapper { background-color: #444; border-radius: 10px; overflow: hidden; margin-bottom: 15px; border: 1px solid #666; box-shadow: 0 4px 15px rgba(0,0,0,0.2); }
    .progress-bar {
        width: 0%;
        height: 30px;
        background: linear-gradient(45deg, #28a745, #218838);
        transition: width 0.4s ease-in-out;
    }
    .progress-text { font-size: 1.2rem; font-weight: 500; margin-bottom: 5px; text-shadow: 1px 1px 2px rgba(0,0,0,0.5); }
    .progress-percentage { font-size: 1.1rem; font-weight: 700; }

    /* --- NEW: Input Error Styles --- */
    .input-error {
        border: 2px solid #e74c3c !important;
        box-shadow: 0 0 8px rgba(231, 76, 60, 0.5) !important;
    }
    .pic-preview.input-error {
        /* Ensure the border wraps the circle nicely */
        border-radius: 50%; 
    }
    </style>
</head>
<body class="auth-body">
    <div id="progress-overlay">
        <div class="progress-container">
            <h3 id="progress-text">Submitting...</h3>
            <div class="progress-bar-wrapper">
                <div id="progress-bar" class="progress-bar"></div>
            </div>
            <div id="progress-percentage" class="progress-percentage">0%</div>
        </div>
    </div>

    <div id="alert-container"></div>
    
    <main class="auth-container">
        <div class="auth-panel">
            <div class="auth-form-side">
                <div class="auth-form-wrapper">
                    <a href="../index.php" class="auth-logo"><span class="logo-icon">R</span><span>ROVICC</span></a>
                    <h3>Create an Account</h3>
                    <p class="auth-sub-text">Join the future of financial freedom.</p>
                    
                    <form action="signup.php" method="POST" class="auth-form" enctype="multipart/form-data" id="signup-form" novalidate>
                        <div class="form-group profile-upload-group">
                            <label for="profile_picture">Selfie Picture</label>
                            <div class="profile-pic-wrapper">
                                <div class="pic-preview" id="pic-preview"><i class="fa-solid fa-user-astronaut"></i></div>
                                <label for="profile_picture" class="btn btn-secondary pic-upload-btn"><i class="fa-solid fa-camera"></i> Choose Photo</label>
                                <input type="file" name="profile_picture" id="profile_picture" accept="image/*" required>
                                <p id="profile_picture_name" class="file-name"></p>
                            </div>
                        </div>

                        <div class="form-group-row">
                            <div class="form-group">
                                <label for="firstName">First Name</label>
                                <div class="input-wrapper">
                                    <i class="fa-solid fa-user form-icon"></i>
                                    <input type="text" id="firstName" name="firstName" placeholder="John" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lastName">Last Name</label>
                                <div class="input-wrapper">
                                    <i class="fa-solid fa-user form-icon" style="opacity:0;"></i>
                                    <input type="text" id="lastName" name="lastName" placeholder="Doe" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group"><label for="phone">Mobile Number</label><div class="input-wrapper"><i class="fa-solid fa-phone form-icon"></i><input type="tel" id="phone" name="phone" placeholder="e.g., 237676244204" required></div></div>
                        <div class="form-group"><label for="email">Email Address</label><div class="input-wrapper"><i class="fa-solid fa-envelope form-icon"></i><input type="email" id="email" name="email" placeholder="you@example.com" required></div></div>
                        <div class="form-group"><label for="password">Password</label><div class="input-wrapper"><i class="fa-solid fa-lock form-icon"></i><input type="password" id="password" name="password" placeholder="Minimum 8 characters" required></div></div>
                        <div class="form-group"><label for="dob">Date of Birth</label><div class="input-wrapper"><i class="fa-solid fa-calendar-alt form-icon"></i><input type="date" name="dob" id="dob" required></div></div>
                        <div class="form-group"><label for="referral_code">Referral Code (Optional)</label><div class="input-wrapper"><i class="fa-solid fa-user-friends form-icon"></i><input type="text" id="referral_code" name="referral_code" placeholder="Enter referral code"></div></div>

                        <div class="form-group"><label for="id_card_front">ID Card (Front)</label><label class="file-upload-wrapper"><i class="fa-solid fa-cloud-arrow-up"></i><span class="file-upload-text">Click to upload a file</span><span class="file-upload-hint">PNG, JPG, GIF, WEBP, PDF, HEIC</span><span class="file-name" id="id_card_front_name"></span><input type="file" name="id_card_front" id="id_card_front" accept="image/*,application/pdf" required></label></div>
                        <div class="form-group"><label for="id_card_back">ID Card (Back)</label><label class="file-upload-wrapper"><i class="fa-solid fa-cloud-arrow-up"></i><span class="file-upload-text">Click to upload a file</span><span class="file-upload-hint">PNG, JPG, GIF, WEBP, PDF, HEIC</span><span class="file-name" id="id_card_back_name"></span><input type="file" name="id_card_back" id="id_card_back" accept="image/*,application/pdf" required></label></div>
                        
                        <button type="submit" class="btn btn-primary btn-large auth-button">Create Account</button>
                    </form>
                    
                    <div class="whatsapp-help"><a href="https://wa.me/237676244204" target="_blank"><i class="fa-brands fa-whatsapp"></i></a><p>Used the old system? Contact us on WhatsApp to restore your account.</p></div>
                    <div class="social-auth-divider"><span>OR</span></div>
                    <div class="social-auth-buttons"><button class="btn btn-secondary social-btn"><i class="fa-brands fa-google"></i> Sign up with Google</button></div>
                    <p class="terms-text">By creating an account, you agree to our <a href="#">Terms</a> and <a href="#">Privacy Policy</a>.</p>
                    <p class="auth-switch-text">Already have an account? <a href="login.php">Log In</a></p>
                </div>
            </div>
            <div class="auth-image-side">
                <div class="auth-image-content">
                    <h2>Join Thousands of Secure Users</h2>
                    <p>Start creating secure virtual cards for all your online payments in just minutes.</p>
                </div>
            </div>
        </div>
    </main>

    <script src="../js/script.js" defer></script>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const signupForm = document.getElementById('signup-form');
        const profilePicInput = document.getElementById('profile_picture');
        const picPreview = document.getElementById('pic-preview');
        const profilePicName = document.getElementById('profile_picture_name');

        // --- UPDATED: A list of all required fields and their corresponding visual elements to style for errors ---
        const requiredFields = [
            { input: document.getElementById('firstName'), wrapper: document.getElementById('firstName') },
            { input: document.getElementById('lastName'), wrapper: document.getElementById('lastName') },
            { input: document.getElementById('phone'), wrapper: document.getElementById('phone') },
            { input: document.getElementById('email'), wrapper: document.getElementById('email') },
            { input: document.getElementById('password'), wrapper: document.getElementById('password') },
            { input: document.getElementById('dob'), wrapper: document.getElementById('dob') },
            { input: document.getElementById('profile_picture'), wrapper: document.getElementById('pic-preview') },
            { input: document.getElementById('id_card_front'), wrapper: document.querySelector('label[for="id_card_front"]') },
            { input: document.getElementById('id_card_back'), wrapper: document.querySelector('label[for="id_card_back"]') }
        ];

        // Profile picture preview logic
        if (profilePicInput) {
            profilePicInput.addEventListener('change', function(e) {
                picPreview.classList.remove('input-error'); // Clear error on change
                if (e.target.files && e.target.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        picPreview.innerHTML = `<img src="${event.target.result}" alt="Profile Preview">`;
                    }
                    reader.readAsDataURL(e.target.files[0]);
                    profilePicName.textContent = e.target.files[0].name;
                }
            });
        }

        // Function to handle file name display for ID cards
        function setupFileInput(inputId, nameId) {
            const input = document.getElementById(inputId);
            const nameDisplay = document.getElementById(nameId);
            const wrapper = document.querySelector(`label[for="${inputId}"]`);
            if(input && nameDisplay && wrapper) {
                input.addEventListener('change', function(e) {
                    wrapper.classList.remove('input-error'); // Clear error on change
                    nameDisplay.textContent = e.target.files && e.target.files[0] ? e.target.files[0].name : '';
                });
            }
        }
        setupFileInput('id_card_front', 'id_card_front_name');
        setupFileInput('id_card_back', 'id_card_back_name');

        // --- NEW: Function to clear error style on input for text fields ---
        requiredFields.forEach(field => {
            if (field.input.type !== 'file') {
                field.input.addEventListener('input', () => {
                    field.wrapper.classList.remove('input-error');
                });
            }
        });

        const progressOverlay = document.getElementById('progress-overlay');
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('progress-text');
        const progressPercentage = document.getElementById('progress-percentage');
        
        if (signupForm) {
            signupForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Always prevent default submission first

                // --- NEW: Client-side validation logic ---
                let isFormValid = true;
                requiredFields.forEach(field => {
                    let isEmpty = false;
                    if (field.input.type === 'file') {
                        if (field.input.files.length === 0) {
                            isEmpty = true;
                        }
                    } else {
                        if (field.input.value.trim() === '') {
                            isEmpty = true;
                        }
                    }

                    if (isEmpty) {
                        isFormValid = false;
                        field.wrapper.classList.add('input-error');
                    } else {
                        field.wrapper.classList.remove('input-error');
                    }
                });

                if (!isFormValid) {
                    showAlert('Please fill in all the highlighted required fields.', 'error');
                    return; // Stop the function if validation fails
                }
                // --- End of new validation logic ---

                // If validation passes, proceed with existing AJAX submission
                progressOverlay.style.display = 'flex';
                progressText.textContent = 'Preparing upload...';
                progressPercentage.textContent = '0%';
                progressBar.style.width = '0%';

                const formData = new FormData(signupForm);
                const xhr = new XMLHttpRequest();

                xhr.open('POST', 'signup.php', true);
                
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const uploadProgress = Math.round((e.loaded / e.total) * 80);
                        const totalProgress = 5 + uploadProgress; // Start after an initial 'preparing' phase
                        
                        progressBar.style.width = totalProgress + '%';
                        progressPercentage.textContent = totalProgress + '%';
                        progressText.textContent = `Uploading documents... (${Math.round(e.loaded / 1024)} KB / ${Math.round(e.total / 1024)} KB)`;
                    }
                });

                xhr.addEventListener('load', function() {
                    progressBar.style.width = '90%';
                    progressPercentage.textContent = '90%';
                    progressText.textContent = 'Processing & compressing images...';
                    
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            progressBar.style.width = '100%';
                            progressPercentage.textContent = '100%';
                            progressText.textContent = 'Success! Redirecting...';
                            setTimeout(() => { window.location.href = response.redirectUrl; }, 1200);
                        } else {
                            progressOverlay.style.display = 'none';
                            showAlert(response.error || 'An unknown error occurred.', 'error');
                            // NEW: Clear error styles in case a server-side error occurs after a valid submission attempt
                            requiredFields.forEach(field => field.wrapper.classList.remove('input-error'));
                        }
                    } catch (e) {
                        progressOverlay.style.display = 'none';
                        const errorDetails = xhr.responseText.substring(0, 300);
                        showAlert(`A server error occurred. Please try again. Details: ${errorDetails}`, 'error');
                        console.error("Could not parse JSON response:", xhr.responseText);
                    }
                });
                
                xhr.addEventListener('error', function() {
                    progressOverlay.style.display = 'none';
                    showAlert('A network error occurred. Please check your connection and try again.', 'error');
                });
                
                xhr.send(formData);
            });
        }

        // Display PHP errors passed via session on initial page load (fallback)
        <?php if ($error): ?>
        showAlert('<?= addslashes($error) ?>', 'error');
        <?php endif; ?>
    });
    </script>
</body>
</html>