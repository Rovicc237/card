<?php
// Get the current page filename to set the 'active' class on the correct link.
$current_page = basename($_SERVER['PHP_SELF']);
?>
 <aside class="sidebar">
            <div class="sidebar-header"><a href="dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php" class="<?= ($current_page == 'dashboard.php') ? 'active' : '' ?>"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="SudoCard/create_card.php" class="<?= ($current_page == 'create_card.php' || $current_page == 'payment_page.php' || $current_page == 'card_creation_status.php' || $current_page == 'card_payment_status.php') ? 'active' : '' ?>"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="deposit/deposit.php" class="<?= ($current_page == 'deposit.php') ? 'active' : '' ?>"><i class="fa-solid fa-money-bill-transfer"></i> Deposit</a></li>
                    <li><a href="deposit_history.php" class="<?= ($current_page == 'deposit_history.php') ? 'active' : '' ?>"><i class="fa-solid fa-clock-rotate-left"></i> Deposit History</a></li>
                    <li><a href="transactions.php" class="<?= ($current_page == 'transactions.php') ? 'active' : '' ?>"><i class="fa-solid fa-receipt"></i> Card Transactions</a></li>
                    <li><a href="/user/manual_withdraw.php" class="<?= ($current_page == 'manual_withdraw.php') ? 'active' : '' ?>"><i class="fa-solid fa-hand-holding-dollar"></i> Manual Withdraw</a></li>
                    <li><a href="international_transfers/international_transfers.php" class="<?= ($current_page == 'international_transfers.php') ? 'active' : '' ?>"><i class="fa-solid fa-globe"></i> International Transfers</a></li>
                    <li><a href="referral.php" class="<?= ($current_page == 'referral.php') ? 'active' : '' ?>"><i class="fa-solid fa-users"></i> Referrals</a></li>
                     <li><a href="/user/withdrawal_history.php" class="<?= ($current_page == 'withdrawal_history.php') ? 'active' : '' ?>"><i class="fa-solid fa-history"></i> Withdrawal History</a></li>
                    <li><a href="settings.php" class="<?= ($current_page == 'settings.php') ? 'active' : '' ?>"><i class="fa-solid fa-cog"></i> Settings</a></li>
                    
                    <li class="nav-divider"></li>
                    <li><a href="https://chat.whatsapp.com/FYeR3QeOUaW3KKHcAeppZ4" target="_blank" rel="noopener noreferrer"><i class="fab fa-whatsapp"></i> Community</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>
