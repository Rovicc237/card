<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

$stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt_user->execute([$user_id]);
$user = $stmt_user->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $mobile_money_number = filter_input(INPUT_POST, 'mobile_money_number', FILTER_SANITIZE_STRING);

    if (!$amount || $amount <= 0) {
        $message = "Please enter a valid withdrawal amount.";
        $message_type = 'danger';
    } elseif (empty($mobile_money_number)) {
        $message = "Please enter your mobile money number.";
        $message_type = 'danger';
    } elseif ($amount > $user['balance']) {
        $message = "Withdrawal amount cannot exceed your current balance.";
        $message_type = 'danger';
    } else {
        try {
            $pdo->beginTransaction();

            $stmt_debit = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt_debit->execute([$amount, $user_id]);

            $stmt_insert = $pdo->prepare("INSERT INTO manual_withdrawals (user_id, amount, mobile_money_number, status) VALUES (?, ?, ?, 'pending')");
            $stmt_insert->execute([$user_id, $amount, $mobile_money_number]);

            $pdo->commit();
            $message = "Your withdrawal request of $" . number_format($amount, 2) . " has been submitted and is pending approval.";
            $message_type = 'success';
            
            // Refresh user data to show updated balance
            $user['balance'] -= $amount;

        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "A database error occurred. Please try again.";
            $message_type = 'danger';
            error_log("Manual withdrawal error for user {$user_id}: " . $e->getMessage());
        }
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manual Withdraw - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        .withdraw-container { max-width: 500px; margin: 2rem auto; }
        .form-wrapper { background: var(--white); padding: 2.5rem; border-radius: var(--radius); box-shadow: 0 10px 25px rgba(13, 16, 34, 0.06); }
        .balance-box { background-color: var(--primary-light); border: 1px solid var(--primary); color: var(--primary); padding: 1rem; border-radius: var(--radius); text-align: center; margin-bottom: 1.5rem; }
        .balance-box .label { font-size: 0.9rem; opacity: 0.8; }
        .balance-box .amount { font-size: 2rem; font-weight: 700; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { font-weight: 500; margin-bottom: 0.5rem; display: block; }
        .input-group { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: var(--radius); transition: border-color 0.2s; }
        .input-group:focus-within { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(90, 84, 216, 0.1); }
        .input-group .icon { padding: 0 1rem; font-size: 1.2rem; color: var(--text-light); }
        .input-group input { border: none; outline: none; padding: 1rem; width: 100%; background: transparent; font-size: 1.1rem; }
        .btn-primary { background-color: var(--primary); color: var(--white); width: 100%; padding: 1rem; font-size: 1.1rem; font-weight: 600; border-radius: var(--radius); margin-top: 1.5rem; transition: background-color 0.2s; cursor: pointer; border: none; }
        .btn-primary:hover:not(:disabled) { background-color: #4540ae; }
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius); border: 1px solid transparent; }
        .alert-success { background-color: #d1fae5; color: #065f46; border-color: #6ee7b7; }
        .alert-danger { background-color: #fee2e2; color: #991b1b; border-color: #fca5a5; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'templates/sidebar.php'; ?>
        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title"><h1>Manual Withdrawal</h1><p>Request a withdrawal to your mobile money account.</p></div>
            </header>
            <div class="withdraw-container">
                <div class="form-wrapper">
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                    <div class="balance-box">
                        <div class="label">Available Balance</div>
                        <div class="amount">$<?= number_format($user['balance'] ?? 0.00, 2) ?></div>
                    </div>
                    <form action="manual_withdraw.php" method="POST">
                        <div class="form-group">
                            <label for="amount">Amount to Withdraw (USD)</label>
                            <div class="input-group">
                                <span class="icon">$</span>
                                <input type="number" id="amount" name="amount" placeholder="0.00" min="1.00" step="0.01" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="mobile_money_number">Mobile Money Number</label>
                            <div class="input-group">
                                <span class="icon"><i class="fa-solid fa-mobile-alt"></i></span>
                                <input type="text" id="mobile_money_number" name="mobile_money_number" placeholder="e.g., 676244204" required>
                            </div>
                        </div>
                        <button type="submit" class="btn-primary">Request Withdrawal</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script>
        document.getElementById('menu-toggle').addEventListener('click', () => {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>