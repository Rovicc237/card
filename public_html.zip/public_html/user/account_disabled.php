<?php
session_start();
// This page doesn't require a database connection but includes basic session handling
// in case you want to display the user's email or other non-sensitive info in the future.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Disabled - Rovicc</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/account-disabled.css">
</head>
<body>
    <main class="disabled-container">
        <div class="disabled-card">
            <div class="card-icon">
                <i class="fa-solid fa-user-lock"></i>
            </div>
            <h1>Account Access Suspended</h1>
            <p class="subtitle">Your access to this account has been temporarily disabled by an administrator.</p>
            
            <div class="contact-info">
                <p>If you believe this is an error or wish to appeal this decision, please contact our support team directly on WhatsApp.</p>
                <a href="https://wa.me/237676244204" class="whatsapp-button" target="_blank">
                    <i class="fa-brands fa-whatsapp"></i>
                    Contact Admin on WhatsApp
                </a>
                <p class="phone-number">676244204</p>
            </div>

            <div class="footer-link">
                <a href="login.php"><i class="fa-solid fa-arrow-left"></i> Back to Login Page</a>
            </div>
        </div>
    </main>
</body>
</html>