<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// Fetch user data for the header
$stmt_user = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt_user->execute([$user_id]);
$user = $stmt_user->fetch();
$firstName = htmlspecialchars($user['first_name'] ?? 'User');

// No installations needed. This uses built-in PHP cURL.

// ⚠️ Replace with your actual secret key if needed.
$secretKey = "FLWSECK-7ec";
$baseUrl = 'https://api.flutterwave.com/v3/';

//======================================================================
// SECTION 1: AJAX HANDLER FOR ACCOUNT RESOLUTION
//======================================================================
if (isset($_POST['action']) && $_POST['action'] == 'resolve_account') {
    header('Content-Type: application/json');

    $accountNumber = filter_input(INPUT_POST, 'account_number', FILTER_SANITIZE_STRING);
    $accountBank = filter_input(INPUT_POST, 'account_bank', FILTER_SANITIZE_STRING);

    if (!$accountNumber || !$accountBank) {
        echo json_encode(['status' => 'error', 'message' => 'Bank and Account Number are required.']);
        exit();
    }

    $payload = json_encode([
        "account_number" => $accountNumber,
        "account_bank" => $accountBank
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $baseUrl . 'accounts/resolve');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $secretKey
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    echo $response;
    exit();
}


//======================================================================
// SECTION 2: PHP FUNCTIONS & MAIN LOGIC
//======================================================================
function fetchDataWithCurl(string $endpoint, string $secretKey): array
{
    $url = 'https://api.flutterwave.com/v3/' . $endpoint;
    $headers = ['Authorization: Bearer ' . $secretKey];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) { return ['status' => 'error', 'message' => 'cURL Error: ' . $error]; }
    $result = json_decode($response, true);
    return ($result['status'] ?? 'error') === 'success' ? $result['data'] : [];
}

function initiateTransferWithCurl(array $transferData, string $secretKey): array
{
    $url = 'https://api.flutterwave.com/v3/transfers';
    $headers = ['Authorization: Bearer ' . $secretKey, 'Content-Type: application/json'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transferData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) { return ['status' => 'error', 'message' => 'cURL Error: ' . $error]; }
    return json_decode($response, true);
}

// --- Main Page Logic ---
$transferResult = null;
$banks = fetchDataWithCurl('banks/NG', $secretKey);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    // ... Main form submission logic remains the same
    $accountBank = filter_input(INPUT_POST, 'account_bank', FILTER_SANITIZE_STRING);
    $accountNumber = filter_input(INPUT_POST, 'account_number', FILTER_SANITIZE_STRING);
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $narration = filter_input(INPUT_POST, 'narration', FILTER_SANITIZE_STRING);

    if ($accountBank && $accountNumber && $amount && $narration) {
        $transferData = [
            'account_bank'      => $accountBank,
            'account_number'    => $accountNumber,
            'amount'            => $amount,
            'narration'         => $narration,
            'currency'          => 'NGN',
            'reference'         => 'NGN_transfer_' . uniqid(),
            'callback_url'      => 'https://your-website.com/callback.php',
            'debit_currency'    => 'NGN'
        ];
        $transferResult = initiateTransferWithCurl($transferData, $secretKey);
    } else {
        $transferResult = ['status' => 'error', 'message' => 'All fields are required.'];
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer to Nigeria - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        .form-container { max-width: 500px; margin: 2rem auto; background: var(--white); padding: 2.5rem; border-radius: var(--radius); box-shadow: 0 10px 25px rgba(13, 16, 34, 0.06); }
        h2 { text-align: center; color: var(--text-dark); margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1rem; position: relative; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; font-size: 0.9rem; }
        input, select { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 8px; box-sizing: border-box; font-size: 1rem; }
        input:focus, select:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(90, 84, 216, 0.1); }
        button { width: 100%; padding: 14px; background-color: var(--primary); color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: bold; cursor: pointer; margin-top: 1rem; transition: background-color 0.2s; }
        button:disabled { background-color: #ccc; cursor: not-allowed; }
        #bank_suggestions { display: none; position: absolute; border: 1px solid #ddd; border-top: none; z-index: 99; top: 100%; left: 0; right: 0; background-color: white; max-height: 150px; overflow-y: auto; }
        .suggestion-item { padding: 10px; cursor: pointer; }
        .suggestion-item:hover { background-color: #f1f1f1; }
        #account_name_display { padding: 10px; margin-top: 8px; border-radius: 8px; font-size: 0.9rem; font-weight: bold; text-align: center; min-height: 22px; }
        .account-success { background-color: #d1fae5; color: #065f46; }
        .account-error { background-color: #fee2e2; color: #991b1b; }
        .verifying { color: var(--text-light); font-style: italic; }
        .result { padding: 1rem; margin-bottom: 1rem; border-radius: 8px; color: #fff; text-align: center; }
        .result.success { background-color: var(--success); }
        .result.error { background-color: var(--danger); }
        pre { background: #f8f9fa; padding: 1rem; border-radius: 8px; white-space: pre-wrap; word-wrap: break-word; color: #333; font-size: 0.85rem; text-align: left; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include __DIR__ . '/../sidebar.php'; ?>

        <main class="main-content">
             <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Send Money to Nigeria 🇳🇬</h1>
                    <p>Complete the form to transfer funds.</p>
                </div>
                 <a href="international_transfers.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Selection</a>
            </header>
            
            <div class="form-container">
                <?php if ($transferResult): ?>
                    <div class="result <?php echo htmlspecialchars($transferResult['status']); ?>">
                        <p><strong><?php echo htmlspecialchars(strtoupper($transferResult['status'])); ?>:</strong> <?php echo htmlspecialchars($transferResult['message']); ?></p>
                        <?php if (!empty($transferResult['data'])): ?>
                            <pre><?php echo json_encode($transferResult['data'], JSON_PRETTY_PRINT); ?></pre>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div class="form-group">
                        <label for="bank_search">Select Bank</label>
                        <input type="text" id="bank_search" placeholder="Start typing a bank name..." autocomplete="off">
                        <input type="hidden" id="account_bank" name="account_bank">
                        <div id="bank_suggestions"></div>
                    </div>

                    <div class="form-group">
                        <label for="account_number">Account Number</label>
                        <input type="text" id="account_number" name="account_number" placeholder="Enter 10-digit account number" required maxlength="10">
                        <div id="account_name_display"></div>
                    </div>

                    <div class="form-group">
                        <label for="amount">Amount (NGN)</label>
                        <input type="number" id="amount" name="amount" placeholder="e.g., 5500" required>
                    </div>

                    <div class="form-group">
                        <label for="narration">Narration (Reason)</label>
                        <input type="text" id="narration" name="narration" placeholder="e.g., Payment for services" required>
                    </div>

                    <button type="submit" id="submit_button" disabled>Send Money</button>
                </form>
            </div>
        </main>
    </div>

<script>
    const allBanks = <?php echo json_encode($banks); ?>;

    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }
        
        const bankSearchInput = document.getElementById('bank_search');
        const hiddenBankInput = document.getElementById('account_bank');
        const suggestionsContainer = document.getElementById('bank_suggestions');
        const accountNumberInput = document.getElementById('account_number');
        const displayName = document.getElementById('account_name_display');
        const submitButton = document.getElementById('submit_button');

        bankSearchInput.addEventListener('input', () => {
            const query = bankSearchInput.value.toLowerCase();
            suggestionsContainer.innerHTML = '';
            hiddenBankInput.value = '';

            if (query.length > 1) {
                const filteredBanks = allBanks.filter(bank => bank.name.toLowerCase().includes(query));
                if(filteredBanks.length > 0) {
                    suggestionsContainer.style.display = 'block';
                    filteredBanks.forEach(bank => {
                        const item = document.createElement('div');
                        item.classList.add('suggestion-item');
                        item.textContent = bank.name;
                        item.setAttribute('data-code', bank.code);
                        item.setAttribute('data-name', bank.name);
                        suggestionsContainer.appendChild(item);
                    });
                } else {
                    suggestionsContainer.style.display = 'none';
                }
            } else {
                suggestionsContainer.style.display = 'none';
            }
        });

        suggestionsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('suggestion-item')) {
                bankSearchInput.value = e.target.getAttribute('data-name');
                hiddenBankInput.value = e.target.getAttribute('data-code');
                suggestionsContainer.style.display = 'none';
                verifyAccountDetails();
            }
        });

        document.addEventListener('click', (e) => {
            if (!bankSearchInput.contains(e.target)) {
                suggestionsContainer.style.display = 'none';
            }
        });

        let isVerifying = false;
        let verificationTimeout;

        async function verifyAccountDetails() {
            const bankCode = hiddenBankInput.value;
            const accountNumber = accountNumberInput.value;

            submitButton.disabled = true;
            displayName.innerHTML = '';
            displayName.className = '';

            if (bankCode && accountNumber.length === 10 && !isVerifying) {
                isVerifying = true;
                displayName.innerHTML = 'Verifying...';
                displayName.className = 'verifying';

                const formData = new URLSearchParams();
                formData.append('action', 'resolve_account');
                formData.append('account_bank', bankCode);
                formData.append('account_number', accountNumber);

                try {
                    const response = await fetch('', { method: 'POST', body: formData });
                    const data = await response.json();
                    if (data.status === 'success') {
                        displayName.innerHTML = `✅ ${data.data.account_name}`;
                        displayName.className = 'account-success';
                        submitButton.disabled = false;
                    } else {
                        displayName.innerHTML = `❌ ${data.message || 'Could not resolve account.'}`;
                        displayName.className = 'account-error';
                    }
                } catch (error) {
                    displayName.innerHTML = '❌ An error occurred.';
                    displayName.className = 'account-error';
                } finally {
                    isVerifying = false;
                }
            }
        }
        
        function debounce(func, delay) {
            return function(...args) {
                clearTimeout(verificationTimeout);
                verificationTimeout = setTimeout(() => func.apply(this, args), delay);
            };
        }

        accountNumberInput.addEventListener('input', debounce(verifyAccountDetails, 500));
    });
</script>

</body>
</html>
