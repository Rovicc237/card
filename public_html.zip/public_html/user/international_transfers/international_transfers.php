<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// Fetch user data for the header
$stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$firstName = htmlspecialchars($user['first_name'] ?? 'User');

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Transfer Destination - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        .selection-container {
            max-width: 800px;
            margin: 2rem auto;
        }
        .selection-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
        }
        .country-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 30px;
            text-align: center;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .country-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(13, 16, 34, 0.08);
            border-color: var(--primary);
        }
        .country-flag {
            font-size: 5rem;
            margin-bottom: 20px;
            line-height: 1;
        }
        .country-card h3 {
            font-size: 1.5rem;
            margin: 0 0 10px;
        }
        .country-card p {
            color: var(--text-light);
            font-size: 0.95rem;
            flex-grow: 1;
        }
        .btn-select {
            margin-top: 20px;
            background-color: var(--primary);
            color: white;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include __DIR__ . '/../sidebar.php'; ?>

        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>International Transfers</h1>
                    <p>Select a destination country to begin your transfer.</p>
                </div>
                 <a href="../dashboard.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <section class="selection-container">
                <div class="selection-grid">
                    <a href="cm.php" class="country-card">
                        <div class="country-flag">🇨🇲</div>
                        <h3>Send to Cameroon</h3>
                        <p>Transfer funds instantly to Mobile Money accounts in Cameroon.</p>
                        <div class="btn-select">Select Cameroon</div>
                    </a>
                    <a href="ng.php" class="country-card">
                        <div class="country-flag">🇳🇬</div>
                        <h3>Send to Nigeria</h3>
                        <p>Transfer funds directly to any bank account in Nigeria.</p>
                        <div class="btn-select">Select Nigeria</div>
                    </a>
                </div>
            </section>
        </main>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>
