<?php
session_start();
require_once __DIR__ . '/../../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer to Cameroon - Rovicc</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <?php include __DIR__ . '/../sidebar.php'; ?>

        <main class="main-content">
             <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>Send Money to Cameroon 🇨🇲</h1>
                    <p>This feature is coming soon.</p>
                </div>
                 <a href="international_transfers.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Selection</a>
            </header>
            
            <div style="text-align: center; padding: 50px; background: var(--white); border-radius: var(--radius); margin-top: 2rem;">
                <i class="fa-solid fa-person-digging" style="font-size: 4rem; color: var(--primary); margin-bottom: 1rem;"></i>
                <h2>Under Construction</h2>
                <p>Our team is working hard to bring you instant transfers to Cameroon. Please check back soon!</p>
            </div>
        </main>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>
