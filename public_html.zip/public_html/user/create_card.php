<?php
session_start();
// All necessary includes
require_once __DIR__ . '/../../database/db.php';

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$firstName = htmlspecialchars($user['first_name'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Virtual Card - Rovicc</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/create-card.css">
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <aside class="sidebar">
             <div class="sidebar-header">
                <a href="dashboard.php" class="logo">
                    <span class="logo-icon">R</span>
                    <span>ROVICC</span>
                </a>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="#" class="active"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="#"><i class="fa-solid fa-receipt"></i> Transactions</a></li>
                    <li><a href="referral.php"><i class="fa-solid fa-users"></i> Referrals</a></li>
                    <li><a href="#"><i class="fa-solid fa-chart-pie"></i> Analytics</a></li>
                    <li><a href="#"><i class="fa-solid fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                 <ul>
                    <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    
                </div>
                 <a href="dashboard.php" class="btn btn-secondary" style="text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <section class="card-selection-container">
                <a href="#" class="card-option visa-card">
                    <div>
                        <div class="card-brand">
                            <i class="fab fa-cc-visa"></i>
                            <span>Visa</span>
                        </div>
                        <p>Widely accepted, secure, and reliable for all your online purchases.</p>
                    </div>
                    <div>
                        <div class="card-details">
                            <div class="detail-item">
                                <span class="detail-label">Cost</span>
                                <span class="detail-value">$5</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Validity</span>
                                <span class="detail-value">3 Years</span>
                            </div>
                        </div>
                        <div class="card-select-button">
                            Create Visa Card <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </a>
                <a href="#" class="card-option mastercard-card">
                    <div>
                        <div class="card-brand">
                            <svg class="mastercard-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 78 48">
                                <circle fill="#EB001B" cx="24" cy="24" r="24"/>
                                <circle fill="#F79E1B" cx="54" cy="24" r="24" opacity=".95"/>
                            </svg>
                            <span>Mastercard</span>
                        </div>
                        <p>Globally recognized with robust security features for peace of mind.</p>
                    </div>
                    <div>
                        <div class="card-details">
                            <div class="detail-item">
                                <span class="detail-label">Cost</span>
                                <span class="detail-value">$5</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Validity</span>
                                <span class="detail-value">3 Years</span>
                            </div>
                        </div>
                         <div class="card-select-button">
                            Create Mastercard <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </a>
            </section>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Standard dashboard script for sidebar toggle
            const menuToggle = document.getElementById('menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (menuToggle && sidebar) {
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
            }
        });
    </script>
</body>
</html>