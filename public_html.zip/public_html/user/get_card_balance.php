<?php
/*
================================================================================
AJAX HELPER SCRIPT (get_card_balance.php)
================================================================================
This script is called by the main withdrawal page to fetch the balance
of a specific card without reloading the page.
*/

session_start();
require_once __DIR__ . '/../../database/db.php';

header('Content-Type: application/json');

// Security check: user must be logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$card_id = $_GET['card_id'] ?? null;

if (!$card_id) {
    echo json_encode(['success' => false, 'message' => 'Card ID is missing.']);
    exit();
}

// API Call Helper Function
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $ch = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 45, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_HTTPHEADER => $headers,
        ];
        if (($method === 'POST' || $method === 'PUT') && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($err) return null;
        return json_decode($response, true);
    }
}

try {
    // Verify this card belongs to the logged-in user
    $stmt = $pdo->prepare("SELECT account_id FROM virtual_cards WHERE card_id = ? AND user_id = ?");
    $stmt->execute([$card_id, $user_id]);
    $card = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$card || empty($card['account_id'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid or unauthorized card.']);
        exit();
    }

    // Fetch API settings
    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;

    if (!$sudo_api_key || !$sudo_base_url) {
        echo json_encode(['success' => false, 'message' => 'API settings are not configured.']);
        exit();
    }
    
    // Fetch balance from Sudo API
    $card_balance_url = rtrim($sudo_base_url, '/') . '/accounts/' . $card['account_id'] . '/balance';
    $response = callSudoApi('GET', $card_balance_url, $sudo_api_key);

    if (isset($response['data']['currentBalance'])) {
        echo json_encode(['success' => true, 'balance' => (float)$response['data']['currentBalance']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Could not retrieve card balance.']);
    }

} catch (PDOException $e) {
    error_log("AJAX get_card_balance DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'A server error occurred.']);
}
?>