<?php
session_start();
require_once __DIR__ . '/../../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_impersonating = isset($_SESSION['original_admin_id']);

// --- DATABASE QUERIES ---
try {
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();

    if (!$user) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
    
    $card_stmt = $pdo->prepare("SELECT * FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
    $card_stmt->execute([$user_id]);
    $card = $card_stmt->fetch();

    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;

} catch (PDOException $e) {
    die("A critical database error occurred. Please try again later.");
}

// --- Fetch All Transactions ---
$transactions = [];
$api_error_transactions = '';

if ($card && !empty($sudo_api_key) && !empty($sudo_base_url)) {
    $cardId_for_transactions = $card['card_id'];
    
    // --- FIX: Use precise date and time for a full two-year history ---
    $toDate = date('c'); // ISO 8601 format for current time, e.g., 2025-07-04T18:08:00+01:00
    $fromDate = date('c', strtotime('-2 years'));

    $page = 0;
    $limit = 1000; // A large limit to get all transactions

    $queryParams = http_build_query([
        'page' => $page,
        'limit' => $limit,
        'fromDate' => $fromDate,
        'toDate' => $toDate
    ]);
    $requestUrl = rtrim($sudo_base_url, '/') . '/cards/' . $cardId_for_transactions . '/transactions?' . $queryParams;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $requestUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $sudo_api_key,
        "Content-Type: application/json"
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        $api_error_transactions = "cURL Error: " . $curlError;
    } elseif ($httpCode != 200) {
        $api_error_transactions = "API Error: Received HTTP code " . $httpCode . ". Response: " . $response;
    } else {
        $response_data = json_decode($response, true);
        if (isset($response_data['data'])) {
            $transactions = $response_data['data'];
            
            // Sort transactions by date in descending order (newest first)
            usort($transactions, function($a, $b) {
                return strtotime($b['createdAt']) - strtotime($a['createdAt']);
            });
        }
    }
}

// Determine current page for active sidebar link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Transactions - Rovicc</title>
    <!-- Load Font Awesome first -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Then load custom stylesheets -->
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        .main-header .btn-back {
            text-decoration: none;
            background-color: var(--white);
            color: var(--text-dark);
            padding: 10px 18px;
            border-radius: 10px;
            font-weight: 500;
            border: 1px solid var(--border-color);
            transition: all 0.2s ease;
        }

        .main-header .btn-back:hover {
            background-color: var(--border-color);
        }

        /* --- Styles for the Status Pill --- */
        .status-pill {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            letter-spacing: 0.5px;
        }
        .status-capture {
            color: #383d41;
            background-color: #e2e3e5;
        }
        .status-refund {
            color: #155724;
            background-color: #d4edda;
        }
        .status-unknown { /* Fallback for any other status types */
            color: #856404;
            background-color: #fff3cd;
        }
    </style>
</head>
<body>

    <?php if ($is_impersonating): ?>
        <div class="impersonation-banner">
            You are currently impersonating <?= htmlspecialchars($user['first_name']) ?>.
            <a href="../admin/return_to_admin.php">Return to Admin Dashboard</a>
        </div>
    <?php endif; ?>

    <div class="dashboard-container">
       <?php include 'templates/sidebar.php'; ?>

        <main class="main-content" style="padding-top: <?= $is_impersonating ? '80px' : '30px' ?>;">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title">
                    <h1>All Transactions</h1>
                    <p>Showing transactions.</p>
                </div>
                 <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
            </header>

            <section class="transactions-section">
                 <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="amount-header">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($api_error_transactions)): ?>
                                <tr><td colspan="4" style="text-align: center; color: var(--danger);"><?= htmlspecialchars($api_error_transactions) ?></td></tr>
                            <?php elseif (empty($transactions)): ?>
                                <tr><td colspan="4" style="text-align: center;">No transactions found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($transactions as $transaction): ?>
                                    <?php
                                        $transactionName = $transaction['merchant']['name'] ?? 'N/A';
                                        // --- FIX: Use the exact amount from the API and handle formatting ---
                                        $amount = $transaction['amount'] ?? 0;
                                        $currency = $transaction['currency'] ?? '';
                                        $formattedAmount = number_format(abs($amount), 2);
                                        
                                        $utc_date = $transaction['createdAt'] ?? null;
                                        $formattedDate = 'N/A';
                                        if ($utc_date) {
                                            $date = new DateTime($utc_date);
                                            $date->setTimezone(new DateTimeZone('Africa/Douala')); // WAT timezone
                                            $formattedDate = $date->format('M j, Y, g:i A');
                                        }
                                        $status = $transaction['type'] ?? 'unknown';
                                        $statusClass = 'status-' . htmlspecialchars(strtolower($status));
                                        
                                        // --- FIX: Determine debit/credit and set visual indicators ---
                                        $isDebit = $amount < 0;
                                        $amountClass = $isDebit ? 'amount-debit' : 'amount-credit';
                                        $amountPrefix = $isDebit ? '-' : '+';
                                        $iconClass = $isDebit ? 'fa-arrow-down' : 'fa-arrow-up';
                                        $iconBgColor = $isDebit ? '#fddbde' : '#d1fae5';
                                        $iconColor = $isDebit ? '#f43f5e' : '#10b981';
                                    ?>
                                    <tr>
                                        <td data-label="Description">
                                            <div class="desc-cell">
                                                <div class="desc-icon" style="background-color: <?= $iconBgColor ?>; color: <?= $iconColor ?>;"><i class="fa-solid <?= $iconClass ?>"></i></div>
                                                <span><?= htmlspecialchars($transactionName) ?></span>
                                            </div>
                                        </td>
                                        <td data-label="Date"><?= htmlspecialchars($formattedDate) ?></td>
                                        <td data-label="Status"><span class="status-pill <?= $statusClass ?>"><?= htmlspecialchars(ucfirst($status)) ?></span></td>
                                        <td data-label="Amount" class="<?= $amountClass ?>"><?= $amountPrefix ?>$<?= $formattedAmount ?> <?= htmlspecialchars($currency) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }
    });
    </script>
</body>
</html>
