<?php
// (public_html/user/resend-verification.php)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../../vendor/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../config/smtp_config.php'; // Use the new centralized config

$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_EMAIL);

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['message'] = "Invalid email provided.";
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit();
}

try {
    // Find the user by email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION['message'] = "No account found with that email address.";
        $_SESSION['message_type'] = 'danger';
        header("Location: login.php");
        exit();
    }

    if ($user['is_verified'] == 1) {
        $_SESSION['message'] = "This account has already been verified. Please log in.";
        $_SESSION['message_type'] = 'success';
        header("Location: login.php");
        exit();
    }

    // --- User found and not verified, resend the email ---
    $firstName = $user['first_name'];
    $newVerificationToken = bin2hex(random_bytes(50));
    $newTokenExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Update the database with the new token and expiry
    $updateSql = "UPDATE users SET verification_token = ?, token_expiry = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateSql);
    $updateStmt->execute([$newVerificationToken, $newTokenExpiry, $user['id']]);

    // Send the new verification email
    $mail = get_mailer(); // Get the configured mailer
    try {
        //Recipients
        $mail->setFrom('mail@rovicc.com', 'Rovicc');
        $mail->addAddress($email, $firstName);

        //Content
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Rovicc Account (New Link)';
        $verificationLink = "https://rovicc.com/user/verify.php?token=" . $newVerificationToken;
        
        $emailTemplate = file_get_contents(__DIR__ . '/emails/modern_verification_template.html');
        $emailBody = str_replace(['{{NAME}}', '{{VERIFICATION_LINK}}'], [$firstName, $verificationLink], $emailTemplate);
        $mail->Body = $emailBody;

        $mail->send();

        // Set success message and redirect back to the check-email page
        $_SESSION['signup_email'] = $email; // Ensure the email is available on the next page
        $_SESSION['message'] = "A new verification link has been sent to your email address.";
        $_SESSION['message_type'] = 'success';
        header("Location: check-email.php");
        exit();

    } catch (Exception $e) {
        // Log the detailed mailer error and set a generic error message for the user
        error_log("Mailer Error on Resend: {$mail->ErrorInfo}");
        $_SESSION['signup_email'] = $email;
        $_SESSION['message'] = "Could not send a new verification email. Please contact support.";
        $_SESSION['message_type'] = 'danger';
        header("Location: check-email.php");
        exit();
    }

} catch (PDOException $e) {
    // General database error
    error_log($e->getMessage());
    $_SESSION['message'] = "A database error occurred. Please try again later.";
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit();
}
