<?php
session_start();
header('Content-Type: application/json');

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit();
}

require_once __DIR__ . '/../../database/db.php';

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate input
if (!isset($data['cardId']) || empty($data['cardId'])) {
    echo json_encode(['success' => false, 'message' => 'Card ID is required.']);
    exit();
}
if (!isset($data['status']) || !in_array($data['status'], ['active', 'inactive'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid status provided. Must be "active" or "inactive".']);
    exit();
}

$cardId = $data['cardId'];
$newStatus = $data['status'];
$user_id = $_SESSION['user_id'];

try {
    // Verify that the card belongs to the logged-in user
    $stmt_verify_card = $pdo->prepare("SELECT id, card_id, status FROM virtual_cards WHERE card_id = ? AND user_id = ? LIMIT 1");
    $stmt_verify_card->execute([$cardId, $user_id]);
    $card = $stmt_verify_card->fetch();

    if (!$card) {
        echo json_encode(['success' => false, 'message' => 'Card not found or does not belong to your account.']);
        exit();
    }

    // Fetch Sudo API key and base URL from admin settings
    $stmt_api = $pdo->query("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ('sudo_api_key', 'sudo_base_url')");
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;

    if (empty($sudo_api_key) || empty($sudo_base_url)) {
        echo json_encode(['success' => false, 'message' => 'API credentials are not configured by the administrator.']);
        exit();
    }

    // Prepare the API endpoint URL
    $url = rtrim($sudo_base_url, '/') . '/cards/' . $cardId;

    // Prepare the request body
    $requestBody = json_encode(['status' => $newStatus]);

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT'); // Set HTTP method to PUT
    curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody); // Set the JSON request body
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $sudo_api_key, // Use the fetched API key
        'Content-Length: ' . strlen($requestBody) // Set content length
    ]);

    // Execute cURL request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Get HTTP status code
    $curlError = curl_error($ch);

    // Close cURL session
    curl_close($ch);

    // Check for cURL errors
    if ($curlError) {
        error_log("Card Status Update cURL Error: " . $curlError);
        echo json_encode(['success' => false, 'message' => 'cURL Error: ' . $curlError]);
        exit();
    }

    // Decode the API response
    $apiResponse = json_decode($response, true);

    // Handle the API response based on HTTP status code
    if ($httpCode >= 200 && $httpCode < 300) {
        // API call successful, update local database
        $stmt_update_local = $pdo->prepare("UPDATE virtual_cards SET status = ? WHERE id = ?");
        $stmt_update_local->execute([$newStatus, $card['id']]);

        echo json_encode(['success' => true, 'message' => 'Card status updated successfully.']);
    } else {
        // Error from Sudo API
        $errorMessage = 'Unknown error from API.';
        if (is_array($apiResponse) && isset($apiResponse['message'])) {
            $errorMessage = $apiResponse['message'];
        } elseif (is_array($apiResponse) && isset($apiResponse['error'])) {
            $errorMessage = (is_array($apiResponse['error']) && isset($apiResponse['error']['message'])) ? $apiResponse['error']['message'] : json_encode($apiResponse['error']);
        } elseif (!empty($response)) {
            $errorMessage = $response; // Fallback to raw response if not a structured error
        }
        error_log("Sudo API Card Status Update Failed (HTTP {$httpCode}): " . $errorMessage);
        echo json_encode(['success' => false, 'message' => 'API Error: ' . $errorMessage]);
    }

} catch (PDOException $e) {
    error_log("Database Error in process_card_status_update.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error during card status update.']);
} catch (Exception $e) {
    error_log("General Error in process_card_status_update.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred: ' . $e->getMessage()]);
}
?>
