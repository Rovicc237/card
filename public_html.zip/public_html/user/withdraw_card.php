<?php
/*
================================================================================
SECURE CARD WITHDRAWAL SCRIPT (withdraw_card.php)
================================================================================
This is the main file for the user-facing withdrawal page.
It now includes JavaScript to handle dynamic card balance updates via AJAX
and sends email notifications upon successful withdrawal.
*/

session_start();
require_once __DIR__ . '/../../database/db.php';

// --- Security: Redirect if not logged in ---
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// --- Initialize variables ---
$message = '';
$message_type = '';
$user = null;
$card = null;
$card_current_balance = 'N/A';
$all_user_cards = [];
// Use the card_id from POST if form is submitted, otherwise from GET for initial page load
$selected_card_id = $_POST['card_id'] ?? $_GET['card_id'] ?? null;

// --- API Call Helper Function ---
if (!function_exists('callSudoApi')) {
    function callSudoApi($method, $url, $apiKey, $payload = null) {
        $ch = curl_init();
        $headers = ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"];
        $options = [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 45, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method), CURLOPT_HTTPHEADER => $headers,
        ];
        if (($method === 'POST' || $method === 'PUT') && $payload) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($err) {
            error_log("callSudoApi cURL Error: " . $err);
            return ['error' => "API communication error. Please try again later."];
        }
        return json_decode($response, true);
    }
}

try {
    // --- Fetch User, their cards, and all system settings ---
    $stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // If user not found, destroy session and redirect to login
        session_destroy();
        header("Location: ../login.php");
        exit();
    }

    // Fetch all cards belonging to the user
    $stmt_cards = $pdo->prepare("SELECT card_id, brand, last4, status, account_id FROM virtual_cards WHERE user_id = ? ORDER BY created_at DESC");
    $stmt_cards->execute([$user_id]);
    $all_user_cards = $stmt_cards->fetchAll(PDO::FETCH_ASSOC);

    // If no card was pre-selected, default to the first one in the list
    if (!$selected_card_id && !empty($all_user_cards)) {
        $selected_card_id = $all_user_cards[0]['card_id'];
    }

    // Find the full details of the selected card
    if ($selected_card_id) {
        foreach($all_user_cards as $c) {
            if ($c['card_id'] === $selected_card_id) {
                $card = $c;
                break;
            }
        }
    }
    
    // Fetch necessary API settings
    $setting_keys = ['sudo_api_key', 'sudo_base_url', 'sudo_account_id', 'site_name', 'support_email', 'notification_email'];
    $placeholders = implode(',', array_fill(0, count($setting_keys), '?'));
    $stmt_api = $pdo->prepare("SELECT setting_key, setting_value FROM api_settings WHERE setting_key IN ($placeholders)");
    $stmt_api->execute($setting_keys);
    $api_settings = $stmt_api->fetchAll(PDO::FETCH_KEY_PAIR);
    
    $sudo_api_key = $api_settings['sudo_api_key'] ?? null;
    $sudo_base_url = $api_settings['sudo_base_url'] ?? null;
    $sudo_account_id = $api_settings['sudo_account_id'] ?? null;
    $site_name = htmlspecialchars($api_settings['site_name'] ?? 'Rovicc');
    $support_email = htmlspecialchars($api_settings['support_email'] ?? 'support@rovicc.com');
    $admin_email_address = htmlspecialchars($api_settings['notification_email'] ?? '');


    // Fetch initial card balance from Sudo API for the default selected card
    if ($card && !empty($card['account_id']) && !empty($sudo_api_key) && !empty($sudo_base_url)) {
        $card_balance_url = rtrim($sudo_base_url, '/') . '/accounts/' . $card['account_id'] . '/balance';
        $card_balance_response = callSudoApi('GET', $card_balance_url, $sudo_api_key);

        if (isset($card_balance_response['data']['currentBalance'])) {
            $card_current_balance = (float)$card_balance_response['data']['currentBalance'];
        } else {
            $card_current_balance = 'Error';
        }
    }

} catch (PDOException $e) {
    $message = "A critical database error occurred. Please contact support.";
    $message_type = 'danger';
    // Log the detailed error for the admin, but show a generic message to the user.
    error_log("Withdraw Card Page Load DB Error: " . $e->getMessage());
}

// --- SECURE FORM SUBMISSION HANDLING (FOR THE ACTUAL WITHDRAWAL) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['amount']) && $user && $card) {
    $amount_to_withdraw = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);

    // Re-fetch card balance just before withdrawal for security
    $card_balance_url = rtrim($sudo_base_url, '/') . '/accounts/' . $card['account_id'] . '/balance';
    $card_balance_response = callSudoApi('GET', $card_balance_url, $sudo_api_key);
    $live_card_balance = isset($card_balance_response['data']['currentBalance']) ? (float)$card_balance_response['data']['currentBalance'] : 0;

    // --- Initial validation ---
    if (!$amount_to_withdraw || $amount_to_withdraw <= 0) {
        $message = "Please enter a valid positive amount to withdraw.";
        $message_type = 'danger';
    } elseif ($amount_to_withdraw > $live_card_balance) {
        $message = "Withdrawal amount exceeds your card balance of $" . number_format($live_card_balance, 2);
        $message_type = 'danger';
    } elseif (empty($sudo_api_key) || empty($sudo_base_url) || empty($sudo_account_id)) {
        $message = "Withdrawal service is currently unavailable. Please contact support.";
        $message_type = 'danger';
        error_log("Withdrawal failed: Sudo API settings are missing.");
    } else {
        $paymentReference = 'WITHDRAW-CARD-' . $user_id . '-' . time(); // Unique reference for this attempt.
        $transaction_id = null; // To hold the ID of our new transaction record.

        // --- CORE TRANSACTION LOGIC (LOG-FIRST, THEN EXECUTE) ---
        try {
            // 1. CREATE A 'PENDING' TRANSACTION RECORD FIRST
            $pdo->beginTransaction();
            $stmt_insert_tx = $pdo->prepare("INSERT INTO transactions (user_id, tx_ref, amount_usd, status, payment_gateway, type, description) VALUES (?, ?, ?, 'pending', 'Sudo Internal', 'card_withdrawal', ?)");
            $description = "Withdrawal from card ending in " . $card['last4'];
            $stmt_insert_tx->execute([$user_id, $paymentReference, $amount_to_withdraw, $description]);
            $transaction_id = $pdo->lastInsertId();
            $pdo->commit();

            // 2. CALL THE EXTERNAL API to move funds
            $apiUrl = rtrim($sudo_base_url, '/') . '/accounts/transfer';
            $payload = [
                'debitAccountId' => $card['account_id'], 'amount' => $amount_to_withdraw,
                'narration' => 'Withdrawal from card ' . $card['last4'], 'paymentReference' => $paymentReference,
                'creditAccountId' => $sudo_account_id,
            ];
            $response = callSudoApi('POST', $apiUrl, $sudo_api_key, $payload);

            // 3. HANDLE API RESPONSE
            if (isset($response['data']['_id'])) {
                // SUCCESS: API call worked. Now credit the user's balance.
                $pdo->beginTransaction();
                $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE")->execute([$user_id]);
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount_to_withdraw, $user_id]);
                $pdo->prepare("UPDATE transactions SET status = 'successful' WHERE id = ?")->execute([$transaction_id]);
                $pdo->commit();

                $message = "Successfully withdrew $" . number_format($amount_to_withdraw, 2) . " to your account balance.";
                $message_type = 'success';
                
                // Refresh balances for display
                $user['balance'] += $amount_to_withdraw;
                $card_current_balance = $live_card_balance - $amount_to_withdraw;

                // --- SEND USER AND ADMIN EMAILS ---
                $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: {$site_name} <{$support_email}>\r\n";

                // 1. To User Withdrawing from Card
                if(!empty($user['email'])) {
                    $subject_user = "✅ Card Withdrawal Successful";
                    $body_user = @file_get_contents(__DIR__ . '/email_templates/card_withdrawn_user.html');
                    if($body_user) {
                        $body_user = str_replace('{{user_name}}', htmlspecialchars($user['first_name']), $body_user);
                        $body_user = str_replace('{{amount_withdrawn}}', number_format($amount_to_withdraw, 2), $body_user);
                        $body_user = str_replace('{{card_details}}', strtoupper(htmlspecialchars($card['brand'])) . " **** " . htmlspecialchars($card['last4']), $body_user);
                        $body_user = str_replace('{{site_name}}', $site_name, $body_user);
                        $body_user = str_replace('{{year}}', date('Y'), $body_user);
                        @mail($user['email'], $subject_user, $body_user, $headers);
                    }
                }

                // 2. To Admin
                if (!empty($admin_email_address)) {
                    $subject_admin = "✅ Card Withdrawal: $" . number_format($amount_to_withdraw, 2);
                    $body_admin = @file_get_contents(__DIR__ . '/email_templates/card_withdrawn_admin.html');
                    if($body_admin) {
                        $body_admin = str_replace('{{user_full_name}}', htmlspecialchars($user['first_name'] . ' ' . $user['last_name']), $body_admin);
                        $body_admin = str_replace('{{user_id}}', $user_id, $body_admin);
                        $body_admin = str_replace('{{amount_withdrawn}}', number_format($amount_to_withdraw, 2), $body_admin);
                        $body_admin = str_replace('{{card_details}}', strtoupper(htmlspecialchars($card['brand'])) . " **** " . htmlspecialchars($card['last4']), $body_admin);
                        $body_admin = str_replace('{{tx_ref}}', $paymentReference, $body_admin);
                        $body_admin = str_replace('{{site_name}}', $site_name, $body_admin);
                        $body_admin = str_replace('{{year}}', date('Y'), $body_admin);
                        @mail($admin_email_address, $subject_admin, $body_admin, $headers);
                    }
                }

            } else {
                $error_detail = is_array($response['message'] ?? null) ? json_encode($response['message']) : ($response['message'] ?? 'Unknown API error');
                throw new Exception("Card withdrawal failed at the provider: " . $error_detail);
            }

        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($transaction_id) {
                $pdo->prepare("UPDATE transactions SET status = 'failed', description = CONCAT(description, ' - FAILED') WHERE id = ?")->execute([$transaction_id]);
            }
            $message = "An error occurred during withdrawal: " . $e->getMessage();
            $message_type = 'danger';
            error_log("Card Withdrawal Error for user {$user_id}, tx_ref {$paymentReference}: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw from Card - <?= htmlspecialchars($site_name) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/dashboard.css">
    <style>
        :root { --primary: #5A54D8; --primary-light: #f0f0ff; --white: #fff; --background: #f7f8fc; --border-color: #e9ecf2; --text-dark: #0D1022; --text-light: #6c757d; --radius: 12px; --success: #10b981; --danger: #ef4444; }
        body { font-family: 'Poppins', sans-serif; }
        .main-content { background-color: var(--background); }
        .withdraw-card-container { max-width: 500px; margin: 2rem auto; }
        .form-wrapper { background: var(--white); padding: 2.5rem; border-radius: var(--radius); box-shadow: 0 10px 25px rgba(13, 16, 34, 0.06); }
        .balance-box { background-color: var(--primary-light); border: 1px solid var(--primary); color: var(--primary); padding: 1rem; border-radius: var(--radius); text-align: center; margin-bottom: 1.5rem; }
        .balance-box .label { font-size: 0.9rem; opacity: 0.8; }
        .balance-box .amount { font-size: 2rem; font-weight: 700; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { font-weight: 500; margin-bottom: 0.5rem; display: block; }
        .input-group { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: var(--radius); transition: border-color 0.2s; }
        .input-group:focus-within { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(90, 84, 216, 0.1); }
        .input-group .icon { padding: 0 1rem; font-size: 1.2rem; color: var(--text-light); }
        .input-group input, .input-group select { border: none; outline: none; padding: 1rem; width: 100%; background: transparent; font-size: 1.1rem; appearance: none; -webkit-appearance: none; }
        .btn-primary { background-color: var(--primary); color: var(--white); width: 100%; padding: 1rem; font-size: 1.1rem; font-weight: 600; border-radius: var(--radius); margin-top: 1.5rem; transition: background-color 0.2s; cursor: pointer; border: none; }
        .btn-primary:hover:not(:disabled) { background-color: #4540ae; }
        .btn-primary:disabled { background-color: #a5a2e8; cursor: not-allowed; }
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: var(--radius); border: 1px solid transparent; }
        .alert-success { background-color: #d1fae5; color: #065f46; border-color: #6ee7b7; }
        .alert-danger { background-color: #fee2e2; color: #991b1b; border-color: #fca5a5; }
        .alert-info { background-color: #dbeafe; color: #1e40af; border-color: #93c5fd; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header"><a href="dashboard.php" class="logo"><span class="logo-icon">R</span><span>ROVICC</span></a></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fa-solid fa-table-columns"></i> Dashboard</a></li>
                    <li><a href="SudoCard/create_card.php"><i class="fa-solid fa-credit-card"></i> My Cards</a></li>
                    <li><a href="fund_card.php"><i class="fa-solid fa-dollar-sign"></i> Fund Card</a></li>
                    <li><a href="withdraw_card.php" class="active"><i class="fa-solid fa-arrow-up-from-bracket"></i> Withdraw Card</a></li>
                    <li><a href="transactions.php"><i class="fa-solid fa-receipt"></i> Transactions</a></li>
                    <li><a href="referral.php"><i class="fa-solid fa-users"></i> Referrals</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer"><ul><li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li></ul></div>
        </aside>

        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menu-toggle"><i class="fa-solid fa-bars"></i></button>
                <div class="header-title"><h1>Withdraw From Card</h1><p>Move funds from a virtual card to your main balance.</p></div>
            </header>

            <div class="withdraw-card-container">
                <div class="form-wrapper">
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>

                    <?php if (!empty($all_user_cards) && $user): ?>
                        <div class="balance-box">
                            <div class="label">Your Main Account Balance</div>
                            <div class="amount">$<?= number_format($user['balance'] ?? 0.00, 2) ?></div>
                        </div>

                        <form action="withdraw_card.php" method="POST" id="withdrawal-form">
                            <div class="form-group">
                                <label for="card_id">Select Card to Withdraw From</label>
                                <div class="input-group">
                                    <span class="icon"><i class="fa-solid fa-credit-card"></i></span>
                                    <select name="card_id" id="card_id">
                                        <?php foreach ($all_user_cards as $c): ?>
                                            <option value="<?= htmlspecialchars($c['card_id']) ?>" <?= ($c['card_id'] == $selected_card_id) ? 'selected' : '' ?>>
                                                <?= strtoupper(htmlspecialchars($c['brand'])) ?> **** <?= htmlspecialchars($c['last4']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div id="card-balance-section">
                                <div class="balance-box" style="background-color: #f0fdf4; border-color: #4ade80;">
                                    <div class="label">Selected Card Balance</div>
                                    <div class="amount" id="card-balance-amount" style="color: #15803d;">
                                        $<?= number_format(is_numeric($card_current_balance) ? $card_current_balance : 0.00, 2) ?>
                                    </div>
                                </div>
                            </div>

                            <div id="withdrawal-fields">
                                <?php if (is_numeric($card_current_balance) && $card_current_balance > 0): ?>
                                    <div class="form-group">
                                        <label for="amount">Amount to Withdraw (USD)</label>
                                        <div class="input-group">
                                            <span class="icon">$</span>
                                            <input type="number" id="amount" name="amount" placeholder="0.00" min="0.01" step="0.01" max="<?= htmlspecialchars($card_current_balance) ?>" required>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn-primary" id="submit-button">Withdraw Funds</button>
                                <?php else: ?>
                                    <div class="alert alert-info">This card has no funds to withdraw.</div>
                                <?php endif; ?>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-info">You do not have any active cards to withdraw from. Please <a href="SudoCard/create_card.php">create a card</a> first.</div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
        }

        const cardSelect = document.getElementById('card_id');
        const cardBalanceAmount = document.getElementById('card-balance-amount');
        const withdrawalFields = document.getElementById('withdrawal-fields');
        const form = document.getElementById('withdrawal-form');

        if (cardSelect) {
            cardSelect.addEventListener('change', function() {
                const cardId = this.value;
                
                // Show loading state
                cardBalanceAmount.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
                withdrawalFields.innerHTML = '';

                // Fetch new card balance
                fetch(`get_card_balance.php?card_id=${cardId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const balance = data.balance;
                            cardBalanceAmount.textContent = '$' + balance.toFixed(2);

                            if (balance > 0) {
                                // Re-create the withdrawal form fields
                                withdrawalFields.innerHTML = `
                                    <div class="form-group">
                                        <label for="amount">Amount to Withdraw (USD)</label>
                                        <div class="input-group">
                                            <span class="icon">$</span>
                                            <input type="number" id="amount" name="amount" placeholder="0.00" min="0.01" step="0.01" max="${balance}" required>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn-primary" id="submit-button">Withdraw Funds</button>
                                `;
                            } else {
                                withdrawalFields.innerHTML = '<div class="alert alert-info">This card has no funds to withdraw.</div>';
                            }
                        } else {
                            cardBalanceAmount.textContent = 'Error';
                            withdrawalFields.innerHTML = `<div class="alert alert-danger">${data.message || 'Could not fetch balance.'}</div>`;
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching card balance:', error);
                        cardBalanceAmount.textContent = 'Error';
                        withdrawalFields.innerHTML = '<div class="alert alert-danger">An error occurred while updating balance.</div>';
                    });
            });
        }

        if (form) {
            form.addEventListener('submit', function() {
                const submitButton = document.getElementById('submit-button');
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.textContent = 'Processing...';
                }
            });
        }
    });
    </script>
</body>
</html>