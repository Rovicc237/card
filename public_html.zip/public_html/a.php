<?php
/**
 * FILENAME: ShowCard_Details.php
 *
 * DESCRIPTION:
 * This script provides a form to enter a Sudo Card ID. On submission, it
 * generates a secure token via a server-side API call, displays that token,
 * and then uses the token with a client-side JavaScript library to display
 * the card number within a secure iframe for a LIVE/PRODUCTION environment.
 */

// --- CONFIGURATION (PRODUCTION) ---
// The API key is stored securely on the server and is never exposed to the user's browser.
define('API_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjJmYTVmMGQyMzZlNGE2ZmY1OWFkZjciLCJlbWFpbEFkZHJlc3MiOiJ0Y2hpbmRhcm9tYXJpYzYwQGdtYWlsLmNvbSIsImp0aSI6IjY3MzI1YzRkNjA0MWEzNzYyYjBkMmFlYiIsIm1lbWJlcnNoaXAiOnsiX2lkIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGZhIiwiYnVzaW5lc3MiOnsiX2lkIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGY1IiwibmFtZSI6IlJvdmljYyIsImlzQXBwcm92ZWQiOnRydWV9LCJ1c2VyIjoiNjYyZmE1ZjBkMjM2ZTRhNmZmNTlhZGY3Iiwicm9sZSI6IkFQSUtleSJ9LCJpYXQiOjE3MzEzNTM2NzcsImV4cCI6MTc2MjkxMTI3N30.jjdOojt0J5AYaWIut2U7Izbb3DEVaRmMGo75QH4qmro');
define('API_URL', 'https://api.sudo.africa/cards/');

// Initialize variables
$cardId = '';
$cardToken = ''; // This will hold the token for JavaScript
$error_message = '';

// --- SERVER-SIDE LOGIC ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cardId = htmlspecialchars(trim($_POST['cardId'] ?? ''));

    if (empty($cardId)) {
        $error_message = "Please enter a Card ID.";
    } else {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => API_URL . $cardId . "/token",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "Authorization: " . API_KEY,
                "Accept: application/json"
            ],
        ]);

        $response_body = curl_exec($curl);
        $curl_error = curl_error($curl);
        curl_close($curl);

        if ($curl_error) {
            $error_message = "A system error occurred: " . $curl_error;
        } else {
            $response_data = json_decode($response_body, true);
            if (isset($response_data['statusCode']) && $response_data['statusCode'] == 200 && isset($response_data['data']['token'])) {
                // Successfully got the token, store it for the JS part
                $cardToken = $response_data['data']['token'];
            } else {
                // Handle API errors (e.g., card not found, invalid API key)
                $error_message = "API Error: " . ($response_data['message'] ?? 'Could not retrieve token.');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sudo Card Details Viewer (Production)</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 2em; background-color: #f8f9fa; color: #212529; }
        .container { background-color: #fff; border: 1px solid #dee2e6; padding: 30px; border-radius: 8px; max-width: 600px; margin: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .input-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; }
        input[type="text"] { width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #ced4da; border-radius: 6px; font-size: 16px; }
        button { width: 100%; padding: 12px 15px; border: none; background-color: #007bff; color: white; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; }
        button:hover { background-color: #0056b3; }
        .response-box { margin-top: 25px; border-top: 1px solid #eee; padding-top: 20px; }
        h3 { margin-bottom: 15px; }
        .error { color: #721c24; background-color: #f8d7da; padding: 12px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #f5c6cb; }
        iframe { height: 25px; border: 1px solid #ced4da; border-radius: 6px; padding: 5px; width: 100%; box-sizing: border-box; }
        .card-detail { font-weight: 600; margin-bottom: 20px; }
        .token-display { padding: 10px; background-color: #e9ecef; border: 1px solid #ced4da; border-radius: 6px; font-family: monospace; word-wrap: break-word; font-size: 14px; }
    </style>
</head>
<body>

<div class="container">
    <h2>Sudo Card Details Viewer (Production)</h2>
    <p>Enter a Card ID to generate a token and display the card number.</p>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <div class="input-group">
            <label for="cardId">Card ID:</label>
            <input type="text" id="cardId" name="cardId" value="<?php echo htmlspecialchars($cardId); ?>" required>
        </div>
        <button type="submit">Get Card Details</button>
    </form>

    <?php if ($error_message): ?>
        <p class="error"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <?php if ($cardToken): ?>
        <div class="response-box">
            <!-- Display the generated card token -->
            <h3>Generated Card Token:</h3>
            <div class="token-display">
                <?php echo htmlspecialchars($cardToken); ?>
            </div>
            
            <hr style="margin: 25px 0;">

            <!-- Display the card number using the token -->
            <h3>Card Number:</h3>
            <div class="card-detail">
                <div id="cardNumber"></div>
            </div>
        </div>

        <script type="text/javascript" src="https://js.securepro.xyz/sudo-show/1.1/ACiWvWF9tYAez4M498DHs.min.js"></script>
        <script type="text/javascript">
            (function() {
                try {
                    const cardId = <?php echo json_encode($cardId); ?>;
                    const cardToken = <?php echo json_encode($cardToken); ?>;

                    if (cardId && cardToken) {
                        if (typeof SecureProxy === 'undefined') {
                            console.error("SecureProxy library is not loaded.");
                            document.querySelector('.response-box').innerHTML = '<p class="error">Error: Required script could not be loaded.</p>';
                            return;
                        }

                        // --- PRODUCTION: Use the LIVE Vault ID ---
                        const show = SecureProxy.create('vdl2xefo5');
                        const bearerToken = "Bearer " + cardToken;

                        // --- Request and Render Card Number ---
                        const cardNumberIframe = show.request({
                            name: 'pan-text',
                            method: 'GET',
                            path: '/cards/' + cardId + '/secure-data/number',
                            headers: { "Authorization": bearerToken },
                            htmlWrapper: 'text',
                            jsonPathSelector: 'data.number',
                            serializers: [
                                show.SERIALIZERS.replace(
                                    '(\\d{4})(\\d{4})(\\d{4})(\\d{4})',
                                    '$1 $2 $3 $4 '
                                ),
                            ]
                        });
                        cardNumberIframe.render('#cardNumber');
                    }
                } catch (error) {
                    console.error("An unhandled error occurred in the card display script:", error);
                    const responseBox = document.querySelector('.response-box');
                    if (responseBox) {
                        responseBox.innerHTML = '<p class="error">A critical script error occurred. Please check the browser console for details.</p>';
                    }
                }
            })();
        </script>
    <?php endif; ?>
</div>

</body>
</html>
